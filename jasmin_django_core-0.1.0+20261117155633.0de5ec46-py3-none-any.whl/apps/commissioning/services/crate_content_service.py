"""Shared logic for crate-content viewsets.

Three viewsets (:class:`CrateOrderContentViewSet`,
:class:`CrateDeliveryNoteContentViewSet`,
:class:`CrateContentInvoiceResellerViewSet`) all maintain crate quantities the
same way: they sum ``amount`` over a scoped queryset, compute the delta to a
desired new total, and either adjust an existing row, delete it if it zeroes
out, or create a new one for the difference. A row's note is the office's
own text: the service leaves it as it is, and a new row takes the one
``update_fields`` or ``create_kwargs`` carry.

This service centralises that algorithm so the viewsets only need to declare
the scope, the adjustment-row scope, and the FK kwargs for new rows.
"""

from __future__ import annotations

from typing import Any

from django.db import transaction
from django.db.models import QuerySet, Sum

from core.db_locks import acquire_advisory_xact_lock


class CrateContentService:
    @staticmethod
    def write_rows(rows: QuerySet, fields: dict[str, Any]) -> None:
        """Set ``fields`` on every row of ``rows``, one ``save()`` per row, so
        the audit log records each change: a ``QuerySet.update()`` would
        write past it. ``crate_type`` comes along for the entry's
        ``object_repr``."""
        if not fields:
            return
        for row in rows.select_related("crate_type").select_for_update(of=("self",)):
            for field, value in fields.items():
                setattr(row, field, value)
            row.save(update_fields=list(fields))

    @staticmethod
    @transaction.atomic
    def apply_total_amount_change(
        *,
        scope_qs: QuerySet,
        adjustment_qs: QuerySet | None,
        new_total_amount: int,
        update_fields: dict[str, Any],
        create_kwargs: dict[str, Any],
        model_class: type,
        lock_key: str,
    ) -> None:
        """Force ``Sum('amount')`` over ``scope_qs`` to equal ``new_total_amount``.

        Steps:
        1. Acquire a Postgres advisory lock keyed by ``lock_key`` so
           concurrent writers on the same parent (Invoice / DeliveryNote +
           crate_type) serialise. Without this, two simultaneous edits
           both read the same ``current_total``, both compute the same
           delta, and both create offsetting adjustment rows — silently
           doubling the correction. No UNIQUE constraint catches that.
        2. Write ``update_fields`` (the price, rabatt, tax rate and note the
           caller sends) on every row in ``scope_qs`` (:meth:`write_rows`).
        3. Re-aggregate ``Sum('amount')`` and compute the delta.
        4. If delta is zero, return.
        5. Otherwise look up an existing row to adjust in ``adjustment_qs``
           (defaults to ``scope_qs``):
           - if found: add the delta. If the row reaches 0, delete it; else save.
           - if not found: create a new row with ``create_kwargs`` + delta + update_fields.

        ``create_kwargs`` should carry the FKs (e.g. ``order=order, crate_type=crate_type``).
        ``lock_key`` should uniquely identify the parent scope, e.g.
        ``f"crate_totals:InvoiceReseller:{invoice.id}:{crate_type.id}"``.
        Caller wraps in its own transaction if needed (this method already opens one).
        """
        acquire_advisory_xact_lock(lock_key)

        CrateContentService.write_rows(scope_qs, update_fields)

        current_total = scope_qs.aggregate(total=Sum("amount"))["total"] or 0
        difference = int(new_total_amount) - int(current_total)
        if difference == 0:
            return

        adjustment = (
            (adjustment_qs if adjustment_qs is not None else scope_qs)
            .select_for_update()
            .first()
        )
        if adjustment is not None:
            adjustment.amount += difference
            if adjustment.amount == 0:
                adjustment.delete()
                return
            for field, value in update_fields.items():
                setattr(adjustment, field, value)
            adjustment.save()
            return

        model_class.objects.create(
            **create_kwargs,
            amount=difference,
            **update_fields,
        )
