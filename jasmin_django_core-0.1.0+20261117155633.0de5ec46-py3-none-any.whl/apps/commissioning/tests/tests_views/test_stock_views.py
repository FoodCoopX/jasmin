"""Tests for stock_views.py — CurrentStockComparisonView, StorageLoggingView, bulk ops."""

from __future__ import annotations

import datetime
from decimal import Decimal

import pytest
import time_machine
from django.urls import reverse
from django.utils import timezone
from rest_framework import status

from apps.commissioning.models import MovementShareArticle
from apps.commissioning.models.choices import MovementTypeOptions
from apps.commissioning.services.snapshot_service import SnapshotService
from apps.commissioning.tests.factories import (
    HarvestFactory,
    MovementShareArticleFactory,
    ShareArticleFactory,
    StorageFactory,
)
from apps.commissioning.utils import build_composite_id

URL_STOCK = reverse("current_stock_comparison")
URL_BULK_FINALIZE = reverse("bulk_finalize_current_stock")
URL_BULK_EXPECTED = reverse("bulk_set_as_expected_current_stock")
URL_BULK_ZERO = reverse("bulk_set_to_zero_current_stock")
URL_STORAGE_LOGGING = reverse("storage_logging")


@pytest.fixture(autouse=True)
def _frozen_clock():
    # The writes go to week 15 of 2026, which the documentation and stock
    # count endpoints refuse once it lies more than a week back; on Monday of
    # week 15 it is the current week.
    with time_machine.travel(datetime.datetime(2026, 4, 6, 12, 0), tick=False):
        yield


def _make_composite_id(article, unit, size, storage, year=2026, week=15, day_number=1):
    return build_composite_id(
        str(article.id), unit, size, str(storage.id), year, week, day_number
    )


def _seed_theoretical_stock(article, storage, amount):
    """A real HARVEST movement dated well before the queried week, so the entity
    has a theoretical_current_stock of ``amount`` for the bulk actions to act on."""
    harvest = HarvestFactory(share_article=article, storage=storage)
    return MovementShareArticleFactory(
        share_article=article,
        storage=storage,
        harvest=harvest,
        unit="KG",
        size="M",
        movement_type=MovementTypeOptions.HARVEST,
        amount=Decimal(str(amount)),
        date=datetime.datetime(2026, 1, 5, 12, tzinfo=datetime.UTC),
    )


def _inventory_for(article, storage):
    return MovementShareArticle.objects.get(
        movement_type=MovementTypeOptions.INVENTORY,
        share_article=article,
        storage=storage,
        unit="KG",
        size="M",
    )


def _balance(article, storage):
    """Projected running balance after a bulk action (well after the inventory)."""
    return SnapshotService.compute_balance(
        str(article.id),
        "KG",
        "M",
        str(storage.id),
        up_to=datetime.datetime(2026, 12, 31, tzinfo=datetime.UTC),
    )


# ---------------------------------------------------------------------------
# CurrentStockComparisonView — GET
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestCurrentStockComparisonGet:
    def test_returns_stock_data(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        harvest = HarvestFactory(share_article=article, storage=storage)
        MovementShareArticleFactory(
            share_article=article,
            storage=storage,
            harvest=harvest,
            unit="KG",
            size="M",
            amount=Decimal("50"),
        )

        resp = api_client.get(
            URL_STOCK, {"year": 2026, "delivery_week": 15, "day_number": 1}
        )
        assert resp.status_code == status.HTTP_200_OK
        assert isinstance(resp.data, list)

    def test_empty_for_no_movements(self, api_client, tenant):
        resp = api_client.get(
            URL_STOCK, {"year": 2026, "delivery_week": 15, "day_number": 1}
        )
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == []

    def test_missing_params_returns_400(self, api_client, tenant):
        resp = api_client.get(URL_STOCK, {"year": 2026})
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_filters_by_storage(self, api_client, tenant):
        article = ShareArticleFactory()
        s1 = StorageFactory()
        s2 = StorageFactory()
        h1 = HarvestFactory(share_article=article, storage=s1)
        h2 = HarvestFactory(share_article=article, storage=s2)
        MovementShareArticleFactory(
            share_article=article,
            storage=s1,
            harvest=h1,
            unit="KG",
            size="M",
            amount=Decimal("30"),
        )
        MovementShareArticleFactory(
            share_article=article,
            storage=s2,
            harvest=h2,
            unit="KG",
            size="M",
            amount=Decimal("20"),
        )

        resp = api_client.get(
            URL_STOCK,
            {"year": 2026, "delivery_week": 15, "day_number": 1, "storage": str(s1.id)},
        )
        assert resp.status_code == status.HTTP_200_OK


# ---------------------------------------------------------------------------
# CurrentStockComparisonView — PATCH (create/update inventory)
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestCurrentStockComparisonPatch:
    def test_creates_inventory(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        resp = api_client.patch(url, {"amount": 100}, format="json")
        assert resp.status_code == status.HTTP_201_CREATED
        assert resp.data["amount"] == 100

    def test_updates_existing_inventory(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        # Create first
        resp1 = api_client.patch(url, {"amount": 50}, format="json")
        assert resp1.status_code == status.HTTP_201_CREATED

        # Update
        resp2 = api_client.patch(url, {"amount": 75}, format="json")
        assert resp2.status_code == status.HTTP_200_OK
        assert resp2.data["amount"] == 75

    def test_lost_inventory_race_converges_to_update(
        self, api_client, tenant, monkeypatch
    ):
        """When the existing-lookup misses but the INSERT then loses the
        one-inventory-per-entity-day race (a concurrent writer created the row
        first), the PATCH converges to an update of the winner (200 + our count)
        instead of returning a bare 409 that discards the office's count."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        # The "concurrent winner": a real INVENTORY row that already committed.
        assert (
            api_client.patch(url, {"amount": 40}, format="json").status_code
            == status.HTTP_201_CREATED
        )

        # Force the NEXT existing-lookup to miss (as if our SELECT ran before the
        # concurrent INSERT committed), so the view retries via the create branch
        # and hits the REAL unique constraint — exercising the lost-race path.
        real_select_for_update = MovementShareArticle.objects.select_for_update
        state = {"miss_next": True}

        class _MissOnce:
            def __init__(self, queryset):
                self._queryset = queryset

            def filter(self, *args, **kwargs):
                return _MissOnce(self._queryset.filter(*args, **kwargs))

            def order_by(self, *args, **kwargs):
                return _MissOnce(self._queryset.order_by(*args, **kwargs))

            def first(self):
                if state["miss_next"]:
                    state["miss_next"] = False
                    return None
                return self._queryset.first()

        monkeypatch.setattr(
            MovementShareArticle.objects,
            "select_for_update",
            lambda *args, **kwargs: _MissOnce(real_select_for_update(*args, **kwargs)),
        )

        resp = api_client.patch(url, {"amount": 100}, format="json")
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["amount"] == 100
        # Exactly one INVENTORY row survives — the winner, converged to our count.
        assert _inventory_for(article, storage).counted_amount == Decimal("100.000")

    def test_invalid_composite_id_returns_400(self, api_client, tenant):
        url = reverse("current_stock_comparison_detail", args=["bad_id"])
        resp = api_client.patch(url, {"amount": 1}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_negative_amount_returns_400(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        resp = api_client.patch(url, {"amount": -5}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    @pytest.mark.parametrize("bad_amount", ["NaN", "nan", "Infinity", "-Infinity"])
    def test_non_finite_amount_returns_400(self, api_client, tenant, bad_amount):
        """``Decimal("NaN")`` and ``Decimal("Infinity")`` construct without
        raising, so the parse guard passes them through; the ``< 0`` comparison
        that follows then raises InvalidOperation on a NaN. Both are refused as
        "not a number", and no movement is written."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        resp = api_client.patch(url, {"amount": bad_amount}, format="json")

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "stock.amount_not_number"
        assert not MovementShareArticle.objects.filter(
            movement_type=MovementTypeOptions.INVENTORY, share_article=article
        ).exists()

    def test_metadata_only_patch_preserves_theoretical_stock(self, api_client, tenant):
        """A PATCH with only a flag (no ``amount``) on an entity that has
        theoretical stock and no prior count must NOT zero it (a
        ``0 − theoretical`` correction would make stock read 0). It records a
        metadata-only row (counted_amount=None, zero delta)."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        resp = api_client.patch(url, {"washed": True}, format="json")
        assert resp.status_code == status.HTTP_201_CREATED
        assert resp.data["amount"] is None  # no phantom count in the response
        assert resp.data["washed"] is True

        inv = _inventory_for(article, storage)
        assert inv.counted_amount is None  # "not counted yet"
        assert inv.amount == Decimal("0")  # zero delta — theoretical intact
        assert inv.washed is True
        # The theoretical stock is preserved (50), not zeroed.
        assert _balance(article, storage) == Decimal("50")

    def test_amount_patch_still_corrects_stock(self, api_client, tenant):
        """A PATCH WITH an amount still nets counted − theoretical."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        resp = api_client.patch(url, {"amount": 30}, format="json")
        assert resp.status_code == status.HTTP_201_CREATED
        assert resp.data["amount"] == 30

        inv = _inventory_for(article, storage)
        assert inv.counted_amount == Decimal("30.000")
        assert inv.amount == Decimal("-20.000")  # 30 − 50
        assert _balance(article, storage) == Decimal("30")

    def test_metadata_only_patch_keeps_existing_count(self, api_client, tenant):
        """A flag-only PATCH on an already-counted entity toggles the flag but
        leaves the count and balance untouched."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        assert (
            api_client.patch(url, {"amount": 40}, format="json").status_code
            == status.HTTP_201_CREATED
        )
        resp = api_client.patch(url, {"washed": True}, format="json")
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["amount"] == 40  # existing count still reported
        assert resp.data["washed"] is True

        inv = _inventory_for(article, storage)
        assert inv.counted_amount == Decimal("40.000")  # count preserved
        assert inv.washed is True
        assert _balance(article, storage) == Decimal("40")


# ---------------------------------------------------------------------------
# CurrentStockComparisonView — DELETE
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestCurrentStockComparisonDelete:
    def test_deletes_inventory(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        # Create first
        api_client.patch(url, {"amount": 50}, format="json")
        # Delete
        resp = api_client.delete(url)
        assert resp.status_code == status.HTTP_204_NO_CONTENT

    def test_delete_nonexistent_returns_404(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        cid = _make_composite_id(article, "KG", "M", storage)
        url = reverse("current_stock_comparison_detail", args=[cid])

        resp = api_client.delete(url)
        assert resp.status_code == status.HTTP_404_NOT_FOUND


# ---------------------------------------------------------------------------
# Bulk stock operations
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestBulkInventoryRejectsNonStringIds:
    @pytest.mark.parametrize(
        "url", [URL_BULK_FINALIZE, URL_BULK_EXPECTED, URL_BULK_ZERO]
    )
    @pytest.mark.parametrize("bad_id", [123, None, "", {"id": "x"}])
    def test_non_string_id_returns_400(self, api_client, tenant, url, bad_id):
        """A non-string composite id is refused before it reaches ``.split``."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        valid_id = _make_composite_id(article, "KG", "M", storage)

        resp = api_client.post(url, {"ids": [valid_id, bad_id]}, format="json")

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "bulk.ids_invalid"
        assert resp.data["field"] == "ids"
        assert not MovementShareArticle.objects.filter(
            movement_type=MovementTypeOptions.INVENTORY, share_article=article
        ).exists()


@pytest.mark.django_db
class TestBulkFinalizeCurrentStock:
    def test_no_ids_returns_400(self, api_client, tenant):
        resp = api_client.post(URL_BULK_FINALIZE, {"ids": []}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_finalizes_stock(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        # Seed theoretical stock so finalize actually succeeds (empty errors): an
        # all-success bulk stays HTTP 200 (only partial failure escalates to 207).
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)

        resp = api_client.post(URL_BULK_FINALIZE, {"ids": [cid]}, format="json")
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["errors"] == []
        assert "updated" in resp.data or "created" in resp.data

    def test_finalizing_an_uncounted_entry_records_the_theoretical_count(
        self, api_client, tenant
    ):
        # Finalizing a metadata-only row means "the theoretical amount IS the
        # count" — it is finalized WITH that count, not as a permanent blank.
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        detail_url = reverse("current_stock_comparison_detail", args=[cid])
        api_client.patch(detail_url, {"washed": True}, format="json")

        resp = api_client.post(URL_BULK_FINALIZE, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == {"updated": 1, "created": 0, "errors": []}
        inventory = _inventory_for(article, storage)
        assert inventory.is_finalized is True
        assert inventory.counted_amount == Decimal("50.000")
        assert inventory.amount == Decimal("0.000")
        assert _balance(article, storage) == Decimal("50")

    def test_finalizing_a_negative_stock_keeps_it_negative(self, api_client, tenant):
        """An over-allocated article really holds less than nothing. Lifting the
        count to 0 would write a correction that forces the ledger to zero and
        erase the over-allocation the office needs to see."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, -12.5)
        cid = _make_composite_id(article, "KG", "M", storage)
        detail_url = reverse("current_stock_comparison_detail", args=[cid])
        api_client.patch(detail_url, {"washed": True}, format="json")

        resp = api_client.post(URL_BULK_FINALIZE, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == {"updated": 1, "created": 0, "errors": []}
        inventory = _inventory_for(article, storage)
        assert inventory.is_finalized is True
        assert inventory.counted_amount == Decimal("-12.500")
        assert inventory.amount == Decimal("0.000")
        assert _balance(article, storage) == Decimal("-12.5")

    def test_finalizing_keeps_the_correction_an_uncounted_row_stores(
        self, api_client, tenant
    ):
        """A NULL-counted row can carry a correction of its own — the cascade
        refuses to touch those. Finalizing records the stock the row reports as
        its count and leaves the delta alone, so no balance moves."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        detail_url = reverse("current_stock_comparison_detail", args=[cid])
        api_client.patch(detail_url, {"washed": True}, format="json")
        inventory = _inventory_for(article, storage)
        # A legacy correction: a stored delta with no count beside it.
        MovementShareArticle.objects.filter(pk=inventory.pk).update(
            amount=Decimal("-20")
        )
        SnapshotService.delete_snapshots_for_entity(
            str(article.id), "KG", "M", str(storage.id)
        )
        assert _balance(article, storage) == Decimal("30")

        resp = api_client.post(URL_BULK_FINALIZE, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        inventory.refresh_from_db()
        assert inventory.is_finalized is True
        assert inventory.amount == Decimal("-20.000")
        assert inventory.counted_amount == Decimal("30.000")
        assert _balance(article, storage) == Decimal("30")

    def test_refinalizing_an_entry_is_reported_not_rewritten(self, api_client, tenant):
        """A second click on an already-locked day must not re-derive the row's
        correction behind the office's back — the skip comes back per id."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        detail_url = reverse("current_stock_comparison_detail", args=[cid])
        api_client.patch(detail_url, {"washed": True}, format="json")
        first = api_client.post(URL_BULK_FINALIZE, {"ids": [cid]}, format="json")
        assert first.status_code == status.HTTP_200_OK

        resp = api_client.post(URL_BULK_FINALIZE, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["updated"] == 0
        assert resp.data["created"] == 0
        assert "already finalized" in resp.data["errors"][0]["error"]
        inventory = _inventory_for(article, storage)
        assert inventory.counted_amount == Decimal("50.000")
        assert inventory.amount == Decimal("0.000")
        assert _balance(article, storage) == Decimal("50")


@pytest.mark.django_db
class TestBulkSetAsExpectedCurrentStock:
    def test_no_ids_returns_400(self, api_client, tenant):
        resp = api_client.post(URL_BULK_EXPECTED, {"ids": []}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_creates_inventory_at_theoretical_and_balance_holds(
        self, api_client, tenant
    ):
        # The office confirms the theoretical stock (50) is the real count: an
        # INVENTORY of 50 is recorded with a zero correction, balance unchanged.
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)

        resp = api_client.post(URL_BULK_EXPECTED, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == {"updated": 0, "created": 1, "errors": []}
        inv = _inventory_for(article, storage)
        assert inv.counted_amount == Decimal("50.000")
        assert inv.amount == Decimal("0.000")  # counted == theoretical -> no delta
        assert _balance(article, storage) == Decimal("50")

    def test_a_negative_expected_stock_is_recorded_as_it_stands(
        self, api_client, tenant
    ):
        """The expected value is what the grid shows, negative included — an
        over-allocated article is below zero, and recording 0 instead would be a
        count nobody took plus a correction lifting the ledger."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, -12.5)
        cid = _make_composite_id(article, "KG", "M", storage)

        resp = api_client.post(URL_BULK_EXPECTED, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == {"updated": 0, "created": 1, "errors": []}
        inv = _inventory_for(article, storage)
        assert inv.counted_amount == Decimal("-12.500")
        assert inv.amount == Decimal("0.000")
        assert _balance(article, storage) == Decimal("-12.5")

    def test_missing_theoretical_stock_is_per_item_error(self, api_client, tenant):
        # Unlike set-to-zero, set-as-expected needs a theoretical value; an item
        # with no movements isn't in the theoretical map -> a per-item error.
        article = ShareArticleFactory()
        storage = StorageFactory()
        cid = _make_composite_id(article, "KG", "M", storage)

        resp = api_client.post(URL_BULK_EXPECTED, {"ids": [cid]}, format="json")

        # A per-item error escalates the bulk response to 207.
        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["created"] == 0
        assert resp.data["updated"] == 0
        assert len(resp.data["errors"]) == 1
        assert "not found" in resp.data["errors"][0]["error"].lower()
        assert not MovementShareArticle.objects.filter(
            movement_type=MovementTypeOptions.INVENTORY, share_article=article
        ).exists()

    def test_existing_real_count_is_reported_not_overwritten(self, api_client, tenant):
        # set-as-expected fills entries nobody counted; a real prior count (70)
        # survives, and the skip comes back per id instead of as a silent
        # updated=0/created=0 success.
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        detail_url = reverse("current_stock_comparison_detail", args=[cid])
        api_client.patch(detail_url, {"amount": 70}, format="json")  # real count

        resp = api_client.post(URL_BULK_EXPECTED, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["updated"] == 0
        assert resp.data["created"] == 0
        assert resp.data["errors"][0]["id"] == cid
        assert "already counted" in resp.data["errors"][0]["error"]
        assert _inventory_for(article, storage).counted_amount == Decimal("70.000")
        assert _balance(article, storage) == Decimal("70")

    def test_uncounted_existing_entry_is_set_to_theoretical(self, api_client, tenant):
        # A metadata-only row (a flag PATCH: counted_amount NULL, zero delta) is
        # the "not counted yet" case this action exists for. Keying the branch
        # on ``amount`` — never NULL — made it skip every existing row.
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        detail_url = reverse("current_stock_comparison_detail", args=[cid])
        api_client.patch(detail_url, {"washed": True}, format="json")

        resp = api_client.post(URL_BULK_EXPECTED, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == {"updated": 1, "created": 0, "errors": []}
        inventory = _inventory_for(article, storage)
        assert inventory.counted_amount == Decimal("50.000")
        assert inventory.amount == Decimal("0.000")  # counted == theoretical
        assert inventory.washed is True  # the flag it was created with survives
        assert _balance(article, storage) == Decimal("50")

    def test_finalized_entry_is_refused(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        detail_url = reverse("current_stock_comparison_detail", args=[cid])
        api_client.patch(detail_url, {"washed": True}, format="json")
        MovementShareArticle.objects.filter(
            pk=_inventory_for(article, storage).pk
        ).update(is_finalized=True)

        resp = api_client.post(URL_BULK_EXPECTED, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["updated"] == 0
        assert "finalized" in resp.data["errors"][0]["error"]
        assert _inventory_for(article, storage).counted_amount is None

    def test_multiple_entities_each_set_to_its_own_theoretical(
        self, api_client, tenant
    ):
        storage = StorageFactory()
        art1 = ShareArticleFactory()
        art2 = ShareArticleFactory()
        _seed_theoretical_stock(art1, storage, 12)
        _seed_theoretical_stock(art2, storage, 8)
        ids = [
            _make_composite_id(art1, "KG", "M", storage),
            _make_composite_id(art2, "KG", "M", storage),
        ]

        resp = api_client.post(URL_BULK_EXPECTED, {"ids": ids}, format="json")

        assert resp.data["created"] == 2
        assert resp.data["errors"] == []
        assert _inventory_for(art1, storage).counted_amount == Decimal("12.000")
        assert _inventory_for(art2, storage).counted_amount == Decimal("8.000")
        assert _balance(art1, storage) == Decimal("12")
        assert _balance(art2, storage) == Decimal("8")


@pytest.mark.django_db
class TestBulkSetToZeroCurrentStock:
    def test_no_ids_returns_400(self, api_client, tenant):
        resp = api_client.post(URL_BULK_ZERO, {"ids": []}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_creates_zero_inventory_and_balance_drops_to_zero(self, api_client, tenant):
        # The office found nothing on hand for an item that theoretically has 50.
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)

        resp = api_client.post(URL_BULK_ZERO, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == {"updated": 0, "created": 1, "errors": []}
        inv = _inventory_for(article, storage)
        assert inv.counted_amount == Decimal("0")
        assert inv.amount == Decimal("-50.000")  # correction delta: 0 - 50
        assert _balance(article, storage) == Decimal("0")

    def test_works_without_theoretical_stock(self, api_client, tenant):
        # set-to-zero does NOT need a theoretical value (unlike set-as-expected):
        # an item with no movements just gets a 0-count inventory.
        article = ShareArticleFactory()
        storage = StorageFactory()
        cid = _make_composite_id(article, "KG", "M", storage)

        resp = api_client.post(URL_BULK_ZERO, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["created"] == 1
        assert _inventory_for(article, storage).counted_amount == Decimal("0")
        assert _balance(article, storage) == Decimal("0")

    def test_multiple_entities_all_zeroed(self, api_client, tenant):
        storage = StorageFactory()
        art1 = ShareArticleFactory()
        art2 = ShareArticleFactory()
        _seed_theoretical_stock(art1, storage, 30)
        _seed_theoretical_stock(art2, storage, 20)
        ids = [
            _make_composite_id(art1, "KG", "M", storage),
            _make_composite_id(art2, "KG", "M", storage),
        ]

        resp = api_client.post(URL_BULK_ZERO, {"ids": ids}, format="json")

        assert resp.data["created"] == 2
        assert resp.data["errors"] == []
        assert _balance(art1, storage) == Decimal("0")
        assert _balance(art2, storage) == Decimal("0")

    def test_rerun_reports_the_existing_count_and_adds_no_row(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 40)
        cid = _make_composite_id(article, "KG", "M", storage)

        first = api_client.post(URL_BULK_ZERO, {"ids": [cid]}, format="json")
        assert first.data["created"] == 1
        second = api_client.post(URL_BULK_ZERO, {"ids": [cid]}, format="json")

        # The day's inventory already carries a count, so the second call
        # neither creates nor updates — and says so per id instead of
        # reporting an all-clear. Still just the one row.
        assert second.status_code == status.HTTP_207_MULTI_STATUS
        assert second.data["updated"] == 0
        assert second.data["created"] == 0
        assert "already counted" in second.data["errors"][0]["error"]
        assert (
            MovementShareArticle.objects.filter(
                movement_type=MovementTypeOptions.INVENTORY, share_article=article
            ).count()
            == 1
        )
        assert _balance(article, storage) == Decimal("0")

    def test_uncounted_existing_entry_is_zeroed(self, api_client, tenant):
        # A metadata-only row (flag PATCH) is the "not counted yet" case: the
        # count becomes 0 and the correction delta cancels the theoretical 50.
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 50)
        cid = _make_composite_id(article, "KG", "M", storage)
        detail_url = reverse("current_stock_comparison_detail", args=[cid])
        api_client.patch(detail_url, {"washed": True}, format="json")

        resp = api_client.post(URL_BULK_ZERO, {"ids": [cid]}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == {"updated": 1, "created": 0, "errors": []}
        inventory = _inventory_for(article, storage)
        assert inventory.counted_amount == Decimal("0")
        assert inventory.amount == Decimal("-50.000")
        assert _balance(article, storage) == Decimal("0")

    def test_invalid_id_collected_in_errors_others_succeed(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        _seed_theoretical_stock(article, storage, 10)
        good = _make_composite_id(article, "KG", "M", storage)

        resp = api_client.post(
            URL_BULK_ZERO, {"ids": [good, "not-a-valid-id"]}, format="json"
        )

        # One valid + one invalid → partial failure → 207.
        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["created"] == 1  # the good one still went through
        assert len(resp.data["errors"]) == 1
        assert resp.data["errors"][0]["id"] == "not-a-valid-id"


# ---------------------------------------------------------------------------
# StorageLoggingView
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestStorageLoggingView:
    def test_returns_events(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory()
        harvest = HarvestFactory(share_article=article, storage=storage)
        MovementShareArticleFactory(
            share_article=article,
            storage=storage,
            harvest=harvest,
            unit="KG",
            size="M",
            amount=Decimal("10"),
        )

        resp = api_client.get(URL_STORAGE_LOGGING, {"storage": str(storage.id)})
        assert resp.status_code == status.HTTP_200_OK
        assert isinstance(resp.data, list)
        assert len(resp.data) >= 1

    def test_missing_storage_returns_error(self, api_client, tenant):
        resp = api_client.get(URL_STORAGE_LOGGING)
        # Storage param is required — the view returns 404 for missing storage
        assert resp.status_code in (
            status.HTTP_400_BAD_REQUEST,
            status.HTTP_404_NOT_FOUND,
        )

    def test_filters_by_share_article(self, api_client, tenant):
        a1 = ShareArticleFactory()
        a2 = ShareArticleFactory()
        storage = StorageFactory()
        h1 = HarvestFactory(share_article=a1, storage=storage)
        h2 = HarvestFactory(share_article=a2, storage=storage)
        MovementShareArticleFactory(
            share_article=a1,
            storage=storage,
            harvest=h1,
            unit="KG",
            size="M",
            amount=Decimal("10"),
        )
        MovementShareArticleFactory(
            share_article=a2,
            storage=storage,
            harvest=h2,
            unit="KG",
            size="M",
            amount=Decimal("20"),
        )

        resp = api_client.get(
            URL_STORAGE_LOGGING,
            {"storage": str(storage.id), "share_article": str(a1.id)},
        )
        assert resp.status_code == status.HTTP_200_OK
        article_ids = {item["share_article"] for item in resp.data}
        assert str(a2.id) not in article_ids

    def test_filters_by_date_range(self, api_client, tenant):
        storage = StorageFactory()
        resp = api_client.get(
            URL_STORAGE_LOGGING,
            {
                "storage": str(storage.id),
                "start_date": "2026-01-01",
                "end_date": "2026-12-31",
            },
        )
        assert resp.status_code == status.HTTP_200_OK

    def test_invalid_date_returns_400(self, api_client, tenant):
        storage = StorageFactory()
        resp = api_client.get(
            URL_STORAGE_LOGGING,
            {"storage": str(storage.id), "start_date": "bad-date"},
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_inverted_date_range_returns_400(self, api_client, tenant):
        """The ledger filters ``>= start`` AND ``<= end``, so a swapped pair can
        only return an empty ledger — indistinguishable from a quiet storage."""
        storage = StorageFactory()
        resp = api_client.get(
            URL_STORAGE_LOGGING,
            {
                "storage": str(storage.id),
                "start_date": "2026-12-31",
                "end_date": "2026-01-01",
            },
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "query.invalid_param"
        assert resp.data["field"] == "start_date"

    def test_nonexistent_storage_returns_404(self, api_client, tenant):
        resp = api_client.get(
            URL_STORAGE_LOGGING,
            {"storage": "00000000-0000-0000-0000-000000000000"},
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND

    def test_running_balance_accumulates_exactly(self, api_client, tenant):
        # The running balance must accumulate in Decimal end-to-end (amounts are
        # DecimalField); float() only at the per-row wire boundary. This locks
        # the cumulative math for a multi-movement ledger (the other tests assert
        # only status/shape, never the running_balance value).
        article = ShareArticleFactory()
        storage = StorageFactory()
        harvest = HarvestFactory(share_article=article, storage=storage)
        movements = [
            (datetime.datetime(2026, 3, 2, 12, tzinfo=datetime.UTC), Decimal("10.500")),
            (datetime.datetime(2026, 3, 3, 12, tzinfo=datetime.UTC), Decimal("0.200")),
            (datetime.datetime(2026, 3, 4, 12, tzinfo=datetime.UTC), Decimal("0.300")),
        ]
        for when, amount in movements:
            MovementShareArticleFactory(
                share_article=article,
                storage=storage,
                harvest=harvest,
                unit="KG",
                size="M",
                movement_type=MovementTypeOptions.HARVEST,
                amount=amount,
                date=when,
            )

        resp = api_client.get(
            URL_STORAGE_LOGGING,
            {
                "storage": str(storage.id),
                "share_article": str(article.id),
                "start_date": "2026-01-01",
                "end_date": "2026-12-31",
            },
        )
        assert resp.status_code == status.HTTP_200_OK
        # Newest-first; ascending running balance was 10.5 -> 10.7 -> 11.0.
        assert [row["running_balance"] for row in resp.data] == [11.0, 10.7, 10.5]
        # amount stays a JSON number on the wire (floated only at the boundary).
        assert [row["amount"] for row in resp.data] == [0.3, 0.2, 10.5]

    def test_the_running_balance_starts_from_the_movements_before_the_window(
        self, api_client, tenant
    ):
        """Each group's balance carries what its movements before the window add
        up to, an inventory correction included; a movement at the window's first
        instant counts once, and other sizes and storages don't reach it."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        other_storage = StorageFactory()
        harvest = HarvestFactory(share_article=article, storage=storage)
        before = datetime.datetime(2026, 1, 5, 12, tzinfo=datetime.UTC)
        window_start = timezone.make_aware(datetime.datetime(2026, 3, 1))
        for size, amount, when in (
            ("M", Decimal("10"), before),
            ("L", Decimal("5"), before),
            ("M", Decimal("2"), window_start),
            ("L", Decimal("1"), datetime.datetime(2026, 3, 2, 12, tzinfo=datetime.UTC)),
        ):
            MovementShareArticleFactory(
                share_article=article,
                storage=storage,
                harvest=harvest,
                unit="KG",
                size=size,
                amount=amount,
                date=when,
            )
        # A count of 8 against the 10 harvested.
        MovementShareArticleFactory(
            share_article=article,
            storage=storage,
            movement_type=MovementTypeOptions.INVENTORY,
            unit="KG",
            size="M",
            amount=Decimal("-2"),
            date=datetime.datetime(2026, 1, 12, 22, tzinfo=datetime.UTC),
        )
        MovementShareArticleFactory(
            share_article=article,
            storage=other_storage,
            harvest=HarvestFactory(share_article=article, storage=other_storage),
            unit="KG",
            size="M",
            amount=Decimal("100"),
            date=before,
        )

        resp = api_client.get(
            URL_STORAGE_LOGGING,
            {
                "storage": str(storage.id),
                "start_date": "2026-03-01",
                "end_date": "2026-12-31",
            },
        )

        assert resp.status_code == status.HTTP_200_OK
        assert {row["size"]: row["running_balance"] for row in resp.data} == {
            "M": 10.0,
            "L": 6.0,
        }

    def test_the_default_window_starts_from_the_older_movements_too(
        self, api_client, tenant
    ):
        """Without a start date the ledger shows the last two weeks, and its
        balance still counts what came before them."""
        article = ShareArticleFactory()
        storage = StorageFactory()
        harvest = HarvestFactory(share_article=article, storage=storage)
        for amount, when in (
            (Decimal("10"), datetime.datetime(2026, 3, 2, 12, tzinfo=datetime.UTC)),
            (Decimal("4"), datetime.datetime(2026, 4, 1, 12, tzinfo=datetime.UTC)),
        ):
            MovementShareArticleFactory(
                share_article=article,
                storage=storage,
                harvest=harvest,
                unit="KG",
                size="M",
                amount=amount,
                date=when,
            )

        resp = api_client.get(URL_STORAGE_LOGGING, {"storage": str(storage.id)})

        assert resp.status_code == status.HTTP_200_OK
        assert [(row["amount"], row["running_balance"]) for row in resp.data] == [
            (4.0, 14.0)
        ]


# ---------------------------------------------------------------------------
# Finalized INVENTORY entries
# ---------------------------------------------------------------------------
def _counted_entry(api_client, amount=20):
    """A counted INVENTORY entry plus its detail URL."""
    article = ShareArticleFactory()
    storage = StorageFactory()
    _seed_theoretical_stock(article, storage, 50)
    composite_id = _make_composite_id(article, "KG", "M", storage)
    detail_url = reverse("current_stock_comparison_detail", args=[composite_id])
    api_client.patch(detail_url, {"amount": amount}, format="json")
    return article, storage, detail_url


def _finalize(article, storage):
    MovementShareArticle.objects.filter(pk=_inventory_for(article, storage).pk).update(
        is_finalized=True
    )


@pytest.mark.django_db
class TestCurrentStockComparisonFinalizedEntry:
    def test_count_change_is_refused(self, api_client, tenant):
        article, storage, detail_url = _counted_entry(api_client)
        _finalize(article, storage)

        resp = api_client.patch(detail_url, {"amount": 99}, format="json")

        assert resp.status_code == status.HTTP_409_CONFLICT
        assert resp.data["code"] == "stock.inventory_finalized"
        assert _inventory_for(article, storage).counted_amount == Decimal("20.000")

    def test_flags_and_note_stay_editable(self, api_client, tenant):
        article, storage, detail_url = _counted_entry(api_client)
        _finalize(article, storage)

        resp = api_client.patch(
            detail_url, {"washed": True, "note": "second shelf"}, format="json"
        )

        assert resp.status_code == status.HTTP_200_OK
        entry = _inventory_for(article, storage)
        assert entry.washed is True
        assert entry.note == "second shelf"
        assert entry.counted_amount == Decimal("20.000")

    @pytest.mark.parametrize("echoed_amount", [20, 20.0, "20"])
    def test_unchanged_count_alongside_a_flag_edit_is_accepted(
        self, api_client, tenant, echoed_amount
    ):
        """The grid echoes the whole row on save, so a flag edit re-sends the
        stored count — that is not a recount."""
        article, storage, detail_url = _counted_entry(api_client)
        _finalize(article, storage)

        resp = api_client.patch(
            detail_url,
            {"amount": echoed_amount, "washed": True, "note": "second shelf"},
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK, resp.data
        entry = _inventory_for(article, storage)
        assert entry.washed is True
        assert entry.note == "second shelf"
        assert entry.counted_amount == Decimal("20.000")

    def test_delete_is_refused(self, api_client, tenant):
        article, storage, detail_url = _counted_entry(api_client)
        _finalize(article, storage)

        resp = api_client.delete(detail_url)

        assert resp.status_code == status.HTTP_409_CONFLICT
        assert resp.data["code"] == "stock.inventory_finalized"
        assert _inventory_for(article, storage).counted_amount == Decimal("20.000")

    def test_delete_of_an_unfinalized_entry_still_works(self, api_client, tenant):
        article, storage, detail_url = _counted_entry(api_client)

        resp = api_client.delete(detail_url)

        assert resp.status_code == status.HTTP_204_NO_CONTENT
        assert not MovementShareArticle.objects.filter(
            movement_type=MovementTypeOptions.INVENTORY, share_article=article
        ).exists()


# ---------------------------------------------------------------------------
# PATCH body validation on the inventory detail endpoint
# ---------------------------------------------------------------------------
def _fresh_detail_url():
    article = ShareArticleFactory()
    storage = StorageFactory()
    composite_id = _make_composite_id(article, "KG", "M", storage)
    return (
        article,
        storage,
        reverse("current_stock_comparison_detail", args=[composite_id]),
    )


@pytest.mark.django_db
class TestCurrentStockComparisonPatchBody:
    def test_non_boolean_flag_is_refused_and_writes_nothing(self, api_client, tenant):
        article, _storage, detail_url = _fresh_detail_url()

        resp = api_client.patch(detail_url, {"washed": "perhaps"}, format="json")

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert not MovementShareArticle.objects.filter(
            movement_type=MovementTypeOptions.INVENTORY, share_article=article
        ).exists()

    def test_over_long_note_is_refused(self, api_client, tenant):
        article, _storage, detail_url = _fresh_detail_url()

        resp = api_client.patch(detail_url, {"note": "x" * 501}, format="json")

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert not MovementShareArticle.objects.filter(
            movement_type=MovementTypeOptions.INVENTORY, share_article=article
        ).exists()

    def test_string_booleans_from_the_client_are_accepted(self, api_client, tenant):
        article, storage, detail_url = _fresh_detail_url()

        resp = api_client.patch(
            detail_url, {"washed": "true", "for_shares": "false"}, format="json"
        )

        assert resp.status_code == status.HTTP_201_CREATED
        entry = _inventory_for(article, storage)
        assert entry.washed is True
        assert entry.for_shares is False

    def test_null_note_is_accepted(self, api_client, tenant):
        article, storage, detail_url = _fresh_detail_url()

        resp = api_client.patch(detail_url, {"note": None}, format="json")

        assert resp.status_code == status.HTTP_201_CREATED
        assert _inventory_for(article, storage).note is None

    def test_amount_keeps_its_own_error_code(self, api_client, tenant):
        _article, _storage, detail_url = _fresh_detail_url()

        resp = api_client.patch(detail_url, {"amount": "abc"}, format="json")

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "stock.amount_not_number"


class TestInventoryMetadataSerializerLocation:
    """The PATCH body serializer is owned by the serializers package."""

    def test_the_view_uses_the_packaged_serializer(self):
        from apps.commissioning.serializers import InventoryMetadataSerializer
        from apps.commissioning.views import stock_views

        assert (
            InventoryMetadataSerializer.__module__
            == "apps.commissioning.serializers.logs_serializer"
        )
        assert stock_views.InventoryMetadataSerializer is InventoryMetadataSerializer
