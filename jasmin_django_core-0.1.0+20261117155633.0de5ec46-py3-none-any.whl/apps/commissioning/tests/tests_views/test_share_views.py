"""Tests for share_views.py — granularity, variation totals, planning amounts."""

from __future__ import annotations

import datetime

import pytest
import time_machine
from django.urls import reverse
from rest_framework import status

from apps.commissioning.tests.factories import (
    DeliveryStationDayFactory,
    DeliveryStationFactory,
    ShareArticleFactory,
    ShareContentFactory,
    ShareFactory,
    SharesDeliveryDayFactory,
    ShareTypeVariationFactory,
)

URL_GRANULARITY = reverse("granularity")
URL_VARIATION_TOTALS = reverse("share_type_variations_totals")
URL_PLANNING = reverse("share_type_variation_amounts_for_planning")


# ---------------------------------------------------------------------------
# ShareContentGranularityView
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestShareContentGranularityView:
    def test_empty_data_returns_ok(self, api_client, tenant):
        resp = api_client.get(URL_GRANULARITY, {"year": 2026, "delivery_week": 15})
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["days_ok"] is True
        assert resp.data["tours_ok"] is True

    def test_missing_params_returns_400(self, api_client, tenant):
        resp = api_client.get(URL_GRANULARITY, {"year": 2026})
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_consistent_data_returns_true(self, api_client, tenant):
        variation = ShareTypeVariationFactory()
        dd = SharesDeliveryDayFactory(day_number=1)
        share = ShareFactory(
            year=2026,
            delivery_week=15,
            share_type_variation=variation,
            delivery_day=dd,
        )
        ShareContentFactory(share=share, amount=10, unit="KG", size="M")

        resp = api_client.get(URL_GRANULARITY, {"year": 2026, "delivery_week": 15})
        assert resp.status_code == status.HTTP_200_OK

    @time_machine.travel(datetime.datetime(2026, 11, 4, 12, 0), tick=False)
    def test_reads_each_station_on_its_tour_of_that_week(self, api_client, tenant):
        day = SharesDeliveryDayFactory(day_number=1)
        moving = DeliveryStationFactory()
        # The later row first, so a lookup that ignores the week ends on the
        # earlier one.
        DeliveryStationDayFactory(
            delivery_station=moving,
            delivery_day=day,
            tour_number=2,
            valid_from=datetime.date(2026, 12, 28),
            valid_until=datetime.date(2027, 6, 27),
        )
        DeliveryStationDayFactory(
            delivery_station=moving,
            delivery_day=day,
            tour_number=1,
            valid_until=datetime.date(2026, 12, 27),
        )
        tour_two = DeliveryStationDayFactory(delivery_day=day, tour_number=2)
        tour_one = DeliveryStationDayFactory(delivery_day=day, tour_number=1)
        share = ShareFactory(
            year=2027,
            delivery_week=1,
            share_type_variation=ShareTypeVariationFactory(),
            delivery_day=day,
        )
        article = ShareArticleFactory()
        for station, amount in (
            (moving, 5),
            (tour_two.delivery_station, 5),
            (tour_one.delivery_station, 7),
        ):
            ShareContentFactory(
                share=share,
                share_article=article,
                delivery_station=station,
                amount=amount,
                unit="KG",
                size="M",
            )

        resp = api_client.get(URL_GRANULARITY, {"year": 2027, "delivery_week": 1})

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["tours_ok"] is True

    def test_day_number_scopes_to_one_delivery_day(self, api_client, tenant):
        # day_number scopes the consistency check to a single delivery day: a day
        # whose stations agree reads days_ok=True even when ANOTHER delivery day
        # the same week diverges (which makes the global, unscoped check False).
        # The global result (no day_number) is kept for PlanningShareContentBase.
        variation = ShareTypeVariationFactory()
        article = ShareArticleFactory()

        def _two_stations(delivery_day, amount_a, amount_b):
            # One Share per (delivery_day, variation) — unique — with two
            # ShareContents at different stations (the consistency axis).
            share = ShareFactory(
                year=2026,
                delivery_week=15,
                share_type_variation=variation,
                delivery_day=delivery_day,
            )
            for amount in (amount_a, amount_b):
                station = DeliveryStationDayFactory(delivery_day=delivery_day)
                ShareContentFactory(
                    share=share,
                    share_article=article,
                    delivery_station=station.delivery_station,
                    amount=amount,
                    unit="KG",
                    size="M",
                )

        # Delivery day 1: stations agree. Delivery day 2: stations diverge.
        _two_stations(SharesDeliveryDayFactory(day_number=1), 10, 10)
        _two_stations(SharesDeliveryDayFactory(day_number=2), 10, 3)

        base = {"year": 2026, "delivery_week": 15}
        # Global (no day_number): divergent day 2 makes it False.
        assert api_client.get(URL_GRANULARITY, base).data["days_ok"] is False
        # Scoped to the consistent day: True.
        assert (
            api_client.get(URL_GRANULARITY, {**base, "day_number": 1}).data["days_ok"]
            is True
        )
        # Scoped to the divergent day: False.
        assert (
            api_client.get(URL_GRANULARITY, {**base, "day_number": 2}).data["days_ok"]
            is False
        )


# ---------------------------------------------------------------------------
# ShareTypeVariationsTotalsView
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestShareTypeVariationsTotalsView:
    def test_missing_delivery_day_returns_400(self, api_client, tenant):
        resp = api_client.get(URL_VARIATION_TOTALS, {"year": 2026, "delivery_week": 15})
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_returns_variations(self, api_client, tenant):
        dd = SharesDeliveryDayFactory(day_number=1)

        resp = api_client.get(
            URL_VARIATION_TOTALS,
            {"year": 2026, "delivery_week": 15, "delivery_day": str(dd.id)},
        )
        assert resp.status_code == status.HTTP_200_OK
        assert "variations" in resp.data

    def test_missing_year_returns_400(self, api_client, tenant):
        resp = api_client.get(
            URL_VARIATION_TOTALS, {"delivery_week": 15, "delivery_day": "x"}
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST


# ---------------------------------------------------------------------------
# ShareTypeVariationAmountsForPlanningView
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestShareTypeVariationAmountsForPlanningView:
    def test_missing_share_option_returns_400(self, api_client, tenant):
        resp = api_client.get(URL_PLANNING, {"year": 2026, "delivery_week": 15})
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_returns_planning_data(self, api_client, tenant):
        resp = api_client.get(
            URL_PLANNING,
            {
                "year": 2026,
                "delivery_week": 15,
                "share_option": "HARVEST_SHARE",
            },
        )
        assert resp.status_code == status.HTTP_200_OK
        # Bare object matching the declared schema, not a one-element array.
        assert isinstance(resp.data, dict)

    def test_missing_year_returns_400(self, api_client, tenant):
        resp = api_client.get(
            URL_PLANNING,
            {"delivery_week": 15, "share_option": "HARVEST_SHARE"},
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
