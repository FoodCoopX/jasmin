"""Tests for OrderContentService."""

from __future__ import annotations

import datetime
from decimal import Decimal
from unittest.mock import patch

import pytest
from django.utils import timezone

from apps.commissioning.errors import OrderContentOfferChangeRefused, OrderDayMissing
from apps.commissioning.models import (
    CrateContentInvoiceReseller,
    CrateDeliveryNoteContent,
    CrateOrderContent,
    Offer,
    Order,
    OrderContent,
)
from apps.commissioning.services.crate_order_content_service import (
    CrateOrderContentService,
)
from apps.commissioning.services.order_content_rows import serialize_order_content
from apps.commissioning.services.order_content_service import OrderContentService
from apps.commissioning.tests.factories import (
    CrateFactory,
    CrateNetPriceFactory,
    DeliveryNoteResellerFactory,
    InvoiceResellerFactory,
    OfferFactory,
    OrderContentFactory,
    OrderFactory,
    OrdersDeliveryDayFactory,
    ResellerFactory,
    ShareArticleFactory,
)
from apps.shared.tenants.models import TenantSettings
from core.errors import JasminError


def _noop_theoretical(*a, **kw):
    """Stub for create_all_theoretical_objects — avoids heavy setup."""
    return {"harvests": [], "purchases": [], "washes": [], "cleans": []}


def _noop_movements(*a, **kw):
    """Stub for create_movements — avoids StockService dependency."""
    return []


# ---------------------------------------------------------------------------
# create_order_with_content_and_crates
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestCreateOrderWithContentAndCrates:
    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_creates_order_and_content(self, _mock_theo, _mock_mv, tenant):
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("100"),
            unit="KG",
            size="M",
        )

        result = OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
            offer=offer,
            amount=Decimal("10"),
        )

        assert result["offer"] == offer.pk
        assert result["amount"] == Decimal("10")
        assert Order.objects.filter(
            reseller=reseller, year=2026, delivery_week=15, day_number=2
        ).exists()

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_reuses_existing_order(self, _mock_theo, _mock_mv, tenant):
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        _order = OrderFactory(
            reseller=reseller, year=2026, delivery_week=15, day_number=2
        )
        offer = OfferFactory(
            share_article=article, amount=Decimal("100"), unit="KG", size="M"
        )

        OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
            offer=offer,
            amount=Decimal("5"),
        )

        assert (
            Order.objects.filter(
                reseller=reseller, year=2026, delivery_week=15, day_number=2
            ).count()
            == 1
        )

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_creates_crate_order_content(self, _mock_theo, _mock_mv, tenant):
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        crate = CrateFactory()
        CrateNetPriceFactory(crate=crate, price=Decimal("3.00"))
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("100"),
            unit="KG",
            size="M",
            used_crate=crate,
        )

        OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
            offer=offer,
            amount=Decimal("10"),
        )

        assert CrateOrderContent.objects.count() == 1
        coc = CrateOrderContent.objects.first()
        assert coc.crate_type == crate

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_no_crate_order_content_when_crates_off_documents(
        self, _mock_theo, _mock_mv, tenant
    ):
        """When the tenant keeps crates OFF documents, ordering an article whose
        offer carries a crate creates NO CrateOrderContent — so nothing cascades
        onto delivery notes / invoices (the root gate the whole feature hangs
        off). Contrast ``test_creates_crate_order_content`` (default → 1)."""
        TenantSettings.objects.create(
            tenant=tenant,
            valid_from=timezone.now() - datetime.timedelta(seconds=1),
            crates_should_be_on_documents=False,
        )
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        crate = CrateFactory()
        CrateNetPriceFactory(crate=crate, price=Decimal("3.00"))
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("100"),
            unit="KG",
            size="M",
            used_crate=crate,
        )

        OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
            offer=offer,
            amount=Decimal("10"),
        )

        assert CrateOrderContent.objects.count() == 0

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_zero_amount_creates_no_crate_order_content(
        self, _mock_theo, _mock_mv, tenant
    ):
        """A zero-amount line must NOT spawn a crate row on create — the
        create path mirrors the update path's ``amount > 0`` guard, so the
        two leave identical crate artefacts (no dead amount-0 crate row + stray
        empty VAT bucket downstream)."""
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        crate = CrateFactory()
        CrateNetPriceFactory(crate=crate, price=Decimal("3.00"))
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("100"),
            unit="KG",
            size="M",
            used_crate=crate,
        )

        OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
            offer=offer,
            amount=Decimal("0"),
        )

        assert CrateOrderContent.objects.count() == 0

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_crate_amount_rounds_up(self, _mock_theo, _mock_mv, tenant):
        """Crate count = ceil(order amount / amount_per_pu): a partial crate
        still needs a whole physical crate (10 / 3 = 3.33 → 4), not the
        implicit int()-truncation (→ 3) of a bare division."""
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        crate = CrateFactory()
        CrateNetPriceFactory(crate=crate, price=Decimal("3.00"))
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("100"),
            unit="KG",
            size="M",
            used_crate=crate,
            amount_per_pu=Decimal("3"),
        )

        OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
            offer=offer,
            amount=Decimal("10"),
        )

        coc = CrateOrderContent.objects.get(crate_type=crate)
        assert coc.amount == 4

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_updates_offer_available_amount(self, _mock_theo, _mock_mv, tenant):
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("50"),
            unit="KG",
            size="M",
        )

        OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
            offer=offer,
            amount=Decimal("10"),
        )

        offer.refresh_from_db()
        assert offer.amount == Decimal("40")

    def test_raises_if_not_enough_stock(self, tenant):
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("5"),
            unit="KG",
            size="M",
        )

        with pytest.raises(JasminError, match="Not enough stock"):
            OrderContentService.create_order_with_content_and_crates(
                reseller=reseller,
                year=2026,
                delivery_week=15,
                day_number=2,
                offer=offer,
                amount=Decimal("100"),
            )

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_populates_day_fields_from_defaults(self, _mock_theo, _mock_mv, tenant):
        OrdersDeliveryDayFactory(
            day_number=2,
            default_harvesting_day=1,
            default_packing_day=2,
        )
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article, amount=Decimal("100"), unit="KG", size="M"
        )

        OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
            offer=offer,
            amount=Decimal("10"),
        )

        order = Order.objects.get(
            reseller=reseller, year=2026, delivery_week=15, day_number=2
        )
        assert order.harvesting_day == 1
        assert order.packing_day == 2

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_day_sent_empty_without_a_default_is_refused(
        self, _mock_theo, _mock_mv, tenant
    ):
        OrdersDeliveryDayFactory(
            day_number=2,
            default_harvesting_day=1,
            default_packing_day=2,
            default_washing_day=1,
            default_cleaning_day=None,
        )
        reseller = ResellerFactory()
        offer = OfferFactory(amount=Decimal("100"), unit="KG", size="M")

        with pytest.raises(OrderDayMissing) as refusal:
            OrderContentService.create_order_with_content_and_crates(
                reseller=reseller,
                year=2026,
                delivery_week=15,
                day_number=2,
                offer=offer,
                amount=Decimal("10"),
                harvesting_day=None,
                packing_day=None,
                washing_day=None,
                cleaning_day=None,
            )

        assert refusal.value.code == "order.day_missing"
        assert refusal.value.details == {"context": "cleaning_day", "day_number": 2}
        assert not Order.objects.filter(reseller=reseller).exists()

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_days_left_out_without_defaults_stay_empty(
        self, _mock_theo, _mock_mv, tenant
    ):
        reseller = ResellerFactory()
        offer = OfferFactory(amount=Decimal("100"), unit="KG", size="M")

        OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=4,
            offer=offer,
            amount=Decimal("10"),
        )

        order = Order.objects.get(reseller=reseller)
        assert order.harvesting_day is None
        assert order.cleaning_day is None

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_day_sent_empty_on_an_existing_order_keeps_its_day(
        self, _mock_theo, _mock_mv, tenant
    ):
        reseller = ResellerFactory()
        order = OrderFactory(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=4,
            harvesting_day=1,
        )
        offer = OfferFactory(amount=Decimal("100"), unit="KG", size="M")

        OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=4,
            offer=offer,
            amount=Decimal("10"),
            harvesting_day=None,
        )

        order.refresh_from_db()
        assert order.harvesting_day == 1


# ---------------------------------------------------------------------------
# update_order_content
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestUpdateOrderContent:
    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_a_change_of_offer_is_refused(self, _mock_theo, _mock_mv, tenant):
        article = ShareArticleFactory()
        offer = OfferFactory(share_article=article, amount=Decimal("90"))
        other_offer = OfferFactory(share_article=article, amount=Decimal("50"))
        oc = OrderContentFactory(offer=offer, share_article=None, amount=Decimal("10"))

        with pytest.raises(OrderContentOfferChangeRefused):
            OrderContentService.update_order_content(
                order_content_id=oc.pk, amount=Decimal("10"), offer=other_offer
            )

        oc.refresh_from_db()
        offer.refresh_from_db()
        other_offer.refresh_from_db()
        assert oc.offer_id == offer.pk
        assert (offer.amount, other_offer.amount) == (Decimal("90"), Decimal("50"))

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_the_grids_save_reports_the_offers_stock_after_it(
        self, _mock_theo, _mock_mv, tenant
    ):
        # The grid sends the line's own offer, read before the save took stock.
        offer = OfferFactory(amount=Decimal("90"))
        oc = OrderContentFactory(offer=offer, share_article=None, amount=Decimal("10"))
        stale_offer = Offer.objects.get(pk=offer.pk)

        result = OrderContentService.update_order_content(
            order_content_id=oc.pk, amount=Decimal("15"), offer=stale_offer
        )

        assert result["offer_available_amount"] == Decimal("85")

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_updates_amount(self, _mock_theo, _mock_mv, tenant):
        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article, amount=Decimal("90"), unit="KG", size="M"
        )
        oc = OrderContentFactory(offer=offer, share_article=None, amount=Decimal("10"))

        result = OrderContentService.update_order_content(
            order_content_id=oc.pk,
            amount=Decimal("15"),
        )

        assert result["amount"] == Decimal("15")
        offer.refresh_from_db()
        # offer amount should decrease by the difference (5)
        assert offer.amount == Decimal("85")

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_server_owned_fields_are_not_applied(
        self, _mock_theo, _mock_mv, tenant, user
    ):
        """Only line fields are written from ``kwargs``: the parent order and
        the finalization stamps are server-owned, whoever the caller is."""
        offer = OfferFactory(amount=Decimal("90"))
        oc = OrderContentFactory(offer=offer, share_article=None, amount=Decimal("10"))
        original_order_id = oc.order_id

        OrderContentService.update_order_content(
            order_content_id=oc.pk,
            amount=Decimal("10"),
            order=OrderFactory(),
            finalized_by=user,
            finalized_at=timezone.now(),
            note="applied",
        )

        oc.refresh_from_db()
        assert oc.order_id == original_order_id
        assert oc.finalized_by_id is None
        assert oc.finalized_at is None
        assert oc.note == "applied"

    def test_raises_if_finalized(self, tenant):
        # Build without save (FinalizedProtectedMixin blocks save of finalized objects)
        oc = OrderContentFactory(amount=Decimal("10"))
        OrderContent.objects.filter(pk=oc.pk).update(is_finalized=True)
        oc.refresh_from_db()

        with pytest.raises(JasminError, match="finalized"):
            OrderContentService.update_order_content(
                order_content_id=oc.pk,
                amount=Decimal("20"),
            )

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_recreates_crate_order_content_with_tax_rate(
        self, _mock_theo, _mock_mv, tenant
    ):
        """update_order_content must pass tax_rate when it recreates the
        CrateOrderContent: omitting it violates the NOT NULL constraint on
        `commissioning_crateordercontent.tax_rate`, which surfaces to the API
        as a 409 "Database integrity error".

        Path: offer has a used_crate → on update, the service deletes the
        existing CrateOrderContent and creates a fresh one for the new
        amount. The fresh-create has to mirror what the CREATE path does
        (resolve via crate pricing → tenant default → constant fallback).
        """
        article = ShareArticleFactory()
        crate = CrateFactory()
        CrateNetPriceFactory(crate=crate, price=Decimal("3.00"))
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("90"),
            unit="KG",
            size="M",
            used_crate=crate,
        )
        oc = OrderContentFactory(offer=offer, share_article=None, amount=Decimal("10"))
        # Pre-existing CrateOrderContent (mirrors what CREATE would have
        # produced). Delete any factory-built one so the count assertion
        # is unambiguous.
        CrateOrderContent.objects.filter(order_content=oc).delete()
        CrateOrderContent.objects.create(
            order_content=oc,
            crate_type=crate,
            amount=Decimal("1"),
            price_per_unit=Decimal("3.00"),
            tax_rate=Decimal("19"),
        )

        OrderContentService.update_order_content(
            order_content_id=oc.pk,
            amount=Decimal("15"),
        )

        # The old crate row is replaced and the new one has a non-null
        # tax_rate (resolved through the same chain as the CREATE path).
        crates = CrateOrderContent.objects.filter(order_content=oc)
        assert crates.count() == 1
        new_crate = crates.first()
        assert new_crate.tax_rate is not None
        assert new_crate.amount == Decimal("15")  # new_amount / pu_divisor(=1)


# ---------------------------------------------------------------------------
# delete_order_content
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestDeleteOrderContent:
    def test_deletes_and_restores_offer_amount(self, tenant):
        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article, amount=Decimal("40"), unit="KG", size="M"
        )
        order = OrderFactory()
        oc = OrderContentFactory(
            order=order, offer=offer, share_article=None, amount=Decimal("10")
        )

        _result = OrderContentService.delete_order_content(oc.pk)

        offer.refresh_from_db()
        assert offer.amount == Decimal("50")
        assert not OrderContent.objects.filter(pk=oc.pk).exists()

    def test_restores_offer_amount_in_pu_when_amount_per_pu_not_one(self, tenant):

        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("40"),
            amount_per_pu=Decimal("5"),
            unit="KG",
            size="M",
        )
        order = OrderFactory()
        oc = OrderContentFactory(
            order=order, offer=offer, share_article=None, amount=Decimal("10")
        )

        OrderContentService.delete_order_content(oc.pk)

        offer.refresh_from_db()
        assert offer.amount == Decimal("42")  # 40 + 10/5, not 40 + 10

    def test_deletes_empty_order(self, tenant):
        order = OrderFactory()
        oc = OrderContentFactory(order=order, amount=Decimal("10"))

        result = OrderContentService.delete_order_content(oc.pk)

        assert result["order_deleted"] is True
        assert not Order.objects.filter(pk=order.pk).exists()

    def test_keeps_order_with_remaining_content(self, tenant):
        order = OrderFactory()
        oc1 = OrderContentFactory(order=order, amount=Decimal("10"))
        _oc2 = OrderContentFactory(order=order, amount=Decimal("5"))

        result = OrderContentService.delete_order_content(oc1.pk)

        assert result["order_deleted"] is False
        assert Order.objects.filter(pk=order.pk).exists()

    def test_raises_for_not_found(self, tenant):
        with pytest.raises(JasminError, match="not found"):
            OrderContentService.delete_order_content(999999)


# ---------------------------------------------------------------------------
# Wiring: every mutation path must trigger ``recompute_order_contents``
# ---------------------------------------------------------------------------
# These tests verify the single-entry-point invariant that mirrors the
# ShareContent side (``recompute_shares``). The mutation methods MUST go
# through the public ``recompute_order_contents`` helper so any other
# code path (management commands, backfills, future callers) gets the
# same wipe + rebuild behaviour for free.
#
# We patch ``recompute_order_contents`` at the module path where the
# service imports it (the deferred import in
# ``order_content_service.py``). The service does ``from .recompute
# import recompute_order_contents`` inside the function body, so the
# patch target is the recompute MODULE's symbol — that's what the
# service binds to at call time.
@pytest.mark.django_db
class TestRecomputeOrderContentsWiring:
    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    @patch("apps.commissioning.services.recompute.recompute_order_contents")
    def test_create_path_triggers_recompute(
        self, mock_recompute, _mock_theo, _mock_mv, tenant
    ):
        reseller = ResellerFactory()
        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article,
            amount=Decimal("100"),
            unit="KG",
            size="M",
        )

        result = OrderContentService.create_order_with_content_and_crates(
            offer=offer,
            amount=Decimal("10"),
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
        )

        # The newly-created OrderContent id is what gets passed to recompute.
        mock_recompute.assert_called_once_with([result["id"]])

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    @patch("apps.commissioning.services.recompute.recompute_order_contents")
    def test_update_path_triggers_recompute(
        self, mock_recompute, _mock_theo, _mock_mv, tenant
    ):
        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article, amount=Decimal("90"), unit="KG", size="M"
        )
        oc = OrderContentFactory(offer=offer, share_article=None, amount=Decimal("10"))

        OrderContentService.update_order_content(
            order_content_id=oc.pk,
            amount=Decimal("15"),
        )

        mock_recompute.assert_called_once_with([oc.pk])

    @patch("apps.commissioning.services.recompute.recompute_order_contents")
    def test_delete_path_does_not_call_recompute(self, mock_recompute, tenant):
        """Delete is the exception: the OrderContent is gone, so there's
        no id to recompute. Cleanup of theoreticals happens via FK CASCADE
        and snapshots are fixed up by ``SnapshotService.cascade_for_movements``
        on the captured movement list (see ``delete_order_content``).

        This test pins the asymmetry so a future "let's call recompute
        everywhere for symmetry" refactor doesn't silently make this path
        a no-op call.
        """
        article = ShareArticleFactory()
        offer = OfferFactory(
            share_article=article, amount=Decimal("40"), unit="KG", size="M"
        )
        order = OrderFactory()
        oc = OrderContentFactory(
            order=order, offer=offer, share_article=None, amount=Decimal("10")
        )

        OrderContentService.delete_order_content(oc.pk)

        mock_recompute.assert_not_called()


# ---------------------------------------------------------------------------
# get_offers_and_order_content — top-level ``order`` block (crates-only orders)
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestGetOffersAndOrderContentOrderBlock:
    def test_crates_only_order_surfaces_top_level_order(self, tenant):
        """A crates-only order (zero OrderContent rows) still exposes its
        identity via the top-level ``order`` block, so the Orders page can
        render and progress it instead of treating the period as orderless."""
        reseller = ResellerFactory()
        crate = CrateFactory()

        created = CrateOrderContentService.create_crate_order_content(
            crate_type_id=crate.id,
            amount=3,
            year=2026,
            delivery_week=15,
            day_number=2,
            reseller=reseller.id,
        )

        result = OrderContentService.get_offers_and_order_content(
            reseller.id, 2026, 15, 2
        )

        # No share-article content rows, but the order IS surfaced.
        assert result["items"] == []
        assert result["order"] is not None
        assert result["order"]["order_id"] == created["order_id"]
        assert result["order"]["order_is_finalized"] is False
        assert result["order"]["has_invoice"] is False
        assert result["order"]["delivery_note_id"] is None

    def test_period_without_order_returns_null_order(self, tenant):
        reseller = ResellerFactory()

        result = OrderContentService.get_offers_and_order_content(
            reseller.id, 2026, 16, 3
        )

        assert result["order"] is None
        assert result["items"] == []


@pytest.mark.django_db
class TestGetOffersAndOrderContentCrateInvoiceLines:
    """``CrateContentInvoiceReseller.invoice`` is nullable, unlike the article
    line's ``invoice``. A crate invoice line that reaches the delivery-note
    lookup without an invoice must read as "no invoice", not crash."""

    def _order_with_crate_line(self, *, invoice):
        order = OrderFactory()
        OrderContentFactory(order=order, offer=None, amount=Decimal("5"))
        delivery_note = DeliveryNoteResellerFactory(order=order)
        crate = CrateFactory()
        crate_delivery_note_line = CrateDeliveryNoteContent.objects.create(
            delivery_note=delivery_note,
            crate_type=crate,
            amount=2,
            tax_rate=Decimal("19.00"),
        )
        crate_invoice_line = CrateContentInvoiceReseller.objects.create(
            invoice=invoice,
            crate_type=crate,
            amount=2,
            tax_rate=Decimal("19.00"),
        )
        crate_invoice_line.crate_delivery_note_contents.add(crate_delivery_note_line)
        return order, delivery_note

    def test_crate_line_without_invoice_reads_as_no_invoice(self, tenant):
        order, delivery_note = self._order_with_crate_line(invoice=None)

        result = OrderContentService.get_offers_and_order_content(
            order.reseller_id, order.year, order.delivery_week, order.day_number
        )

        [row] = result["items"]
        assert row["delivery_note_id"] == delivery_note.id
        assert row["invoice_id"] is None
        assert row["has_invoice"] is False
        assert row["has_finalized_invoice"] is False
        assert result["order"]["invoice_id"] is None
        assert result["order"]["has_invoice"] is False

    def test_crate_line_with_invoice_surfaces_it(self, tenant):
        invoice = InvoiceResellerFactory()
        order, _ = self._order_with_crate_line(invoice=invoice)

        result = OrderContentService.get_offers_and_order_content(
            order.reseller_id, order.year, order.delivery_week, order.day_number
        )

        [row] = result["items"]
        assert row["invoice_id"] == invoice.id
        assert row["has_invoice"] is True
        assert result["order"]["invoice_id"] == invoice.id

    # Both id orders, so the orphan line comes first in one of them whichever
    # order the database returns the lines in.
    @pytest.mark.parametrize(
        ("orphan_id", "invoiced_id"),
        [("222222222222", "zzzzzzzzzzzz"), ("zzzzzzzzzzzz", "222222222222")],
        ids=["orphan-id-first", "orphan-id-last"],
    )
    def test_crate_line_without_invoice_never_hides_the_invoiced_one(
        self, tenant, orphan_id, invoiced_id
    ):
        invoice = InvoiceResellerFactory()
        order = OrderFactory()
        OrderContentFactory(order=order, offer=None, amount=Decimal("5"))
        delivery_note = DeliveryNoteResellerFactory(order=order)
        crate = CrateFactory()
        crate_delivery_note_line = CrateDeliveryNoteContent.objects.create(
            delivery_note=delivery_note,
            crate_type=crate,
            amount=2,
            tax_rate=Decimal("19.00"),
        )
        for line_id, line_invoice in ((orphan_id, None), (invoiced_id, invoice)):
            crate_invoice_line = CrateContentInvoiceReseller.objects.create(
                id=line_id,
                invoice=line_invoice,
                crate_type=crate,
                amount=2,
                tax_rate=Decimal("19.00"),
            )
            crate_invoice_line.crate_delivery_note_contents.add(
                crate_delivery_note_line
            )

        result = OrderContentService.get_offers_and_order_content(
            order.reseller_id, order.year, order.delivery_week, order.day_number
        )

        [row] = result["items"]
        assert row["invoice_id"] == invoice.id
        assert row["has_invoice"] is True
        assert result["order"]["invoice_id"] == invoice.id


# ---------------------------------------------------------------------------
# amount=None on the CREATE path
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestCreateWithNullAmount:
    """``OrderContent.amount`` is ``null=True``, so the ModelSerializer marks it
    ``required=False, allow_null=True`` and a create body may legitimately omit
    it. The create path divides it by ``pu_divisor``, so it must normalise
    ``None`` to ``Decimal("0")`` for both its arithmetic and its persisted value,
    as the UPDATE path does — ``None / Decimal`` would kill the request with an
    unhandled TypeError (HTTP 500, no error code).
    """

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_omitted_amount_creates_a_zero_line_instead_of_crashing(
        self, _mock_theo, _mock_mv, tenant
    ):
        reseller = ResellerFactory()
        offer = OfferFactory(
            share_article=ShareArticleFactory(),
            amount=Decimal("100"),
            unit="KG",
            size="M",
        )

        result = OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=15,
            day_number=2,
            offer=offer,
            # amount deliberately omitted — exactly what the serializer allows.
        )

        assert result["amount"] == Decimal("0")
        content = OrderContent.objects.get(pk=result["id"])
        # Persisted as 0, matching what the update path would have stored.
        assert content.amount == Decimal("0")

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_explicit_none_amount_is_also_accepted(self, _mock_theo, _mock_mv, tenant):
        """``{"amount": null}`` on the wire, not just an absent key."""
        reseller = ResellerFactory()
        offer = OfferFactory(
            share_article=ShareArticleFactory(),
            amount=Decimal("100"),
            unit="KG",
            size="M",
        )

        result = OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=16,
            day_number=2,
            offer=offer,
            amount=None,
        )

        assert result["amount"] == Decimal("0")

    @patch.object(OrderContentService, "create_movements", side_effect=_noop_movements)
    @patch.object(
        OrderContentService,
        "create_all_theoretical_objects",
        side_effect=_noop_theoretical,
    )
    def test_a_zero_line_reserves_no_stock_and_makes_no_crate(
        self, _mock_theo, _mock_mv, tenant
    ):
        """Normalising to zero must not quietly consume offer stock or emit a
        crate row — the existing ``if amount and amount > 0`` gates cover that,
        and this pins it."""
        reseller = ResellerFactory()
        offer = OfferFactory(
            share_article=ShareArticleFactory(),
            amount=Decimal("100"),
            unit="KG",
            size="M",
        )

        result = OrderContentService.create_order_with_content_and_crates(
            reseller=reseller,
            year=2026,
            delivery_week=17,
            day_number=2,
            offer=offer,
            amount=None,
        )

        offer.refresh_from_db()
        assert offer.amount == Decimal("100"), "zero line must not consume stock"
        assert not CrateOrderContent.objects.filter(
            order_content_id=result["id"]
        ).exists()


@pytest.mark.django_db
class TestLegacyNullAmountRowIsReadable:
    """A NULL ``amount`` row must not break the LIST endpoint.

    ``serialize_order_content`` divides ``amount`` to derive
    ``ordered_amount`` and runs once per row on the list path, so a single
    NULL row would 500 the whole orders grid for that reseller/week/day —
    not just its own line. The create path doesn't write NULL, but a row
    from an import, the shell or a migration must still be readable.
    """

    def test_serialize_tolerates_a_null_amount(self, tenant):
        reseller = ResellerFactory()
        order = OrderFactory(reseller=reseller, year=2026, delivery_week=18)
        # Bypass the service to write the state it refuses to create.
        content = OrderContentFactory(order=order, amount=None)
        assert content.amount is None

        data = serialize_order_content(content)

        assert data["amount"] is None, "the raw value is reported as-is"
        assert data["ordered_amount"] == Decimal("0"), "derived value degrades to 0"
