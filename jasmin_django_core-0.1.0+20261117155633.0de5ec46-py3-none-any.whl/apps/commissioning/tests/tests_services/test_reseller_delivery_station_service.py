"""Tests for ResellerAndDeliveryStationService."""

from __future__ import annotations

import pytest
from django.db import IntegrityError, transaction

from apps.commissioning.errors import RequiredFieldMissing
from apps.commissioning.models import (
    ContactEntity,
    DeliveryStation,
    OfferGroup,
    Reseller,
)
from apps.commissioning.services.reseller_and_delivery_station_service import (
    ResellerAndDeliveryStationService,
)
from apps.commissioning.tests.factories import (
    ContactEntityFactory,
    DeliveryStationFactory,
    OfferGroupFactory,
    ResellerFactory,
)


@pytest.fixture()
def svc():
    return ResellerAndDeliveryStationService()


def _contact_data(**overrides):
    """Build valid contact data for create/update methods."""
    defaults = {
        "company_name": "Test GmbH",
        "address": "Street 1",
        "zip_code": "12345",
        "city": "Berlin",
    }
    defaults.update(overrides)
    return defaults


# ---------------------------------------------------------------------------
# create_reseller
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestCreateReseller:
    def test_creates_reseller_with_contact(self, tenant, svc):
        data = {
            "is_reseller": True,
            "is_seller": False,
            "is_also_delivery_station": False,
            **_contact_data(),
        }
        reseller = svc.create_reseller(data)

        assert reseller.pk is not None
        assert reseller.contact is not None
        assert reseller.contact.city == "Berlin"

    def test_also_creates_delivery_station(self, tenant, svc):
        data = {
            "is_reseller": True,
            "is_seller": False,
            "is_also_delivery_station": True,
            **_contact_data(),
        }
        reseller = svc.create_reseller(data)

        assert DeliveryStation.objects.filter(contact=reseller.contact).exists()
        ds = DeliveryStation.objects.get(contact=reseller.contact)
        assert ds.linked_reseller == reseller

    def test_raises_on_missing_contact_fields(self, tenant, svc):
        data = {
            "is_reseller": True,
            "is_seller": False,
            "is_also_delivery_station": False,
            "company_name": "Test",
            # Missing address, zip_code, city
        }
        with pytest.raises(RequiredFieldMissing, match="Missing required contact"):
            svc.create_reseller(data)


# ---------------------------------------------------------------------------
# offer group of a new reseller
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestNewResellerOfferGroup:
    """A reseller created without an offer group gets the tenant's default one,
    the group the office grid pre-selects, so it sees offers from the start."""

    def _reseller_data(self, **overrides):
        return {
            "is_reseller": True,
            "is_seller": False,
            "is_also_delivery_station": False,
            **_contact_data(),
            **overrides,
        }

    def test_without_an_offer_group_the_default_is_assigned(self, tenant, svc):
        reseller = svc.create_reseller(self._reseller_data())

        assert reseller.offer_group_id == OfferGroup.get_default().pk

    def test_an_explicit_offer_group_is_kept(self, tenant, svc):
        chosen = OfferGroupFactory()

        reseller = svc.create_reseller(self._reseller_data(offer_group=chosen))

        assert reseller.offer_group_id == chosen.pk

    def test_without_a_default_offer_group_the_reseller_has_none(self, tenant, svc):
        OfferGroup.objects.filter(is_default=True).update(is_default=False)

        reseller = svc.create_reseller(self._reseller_data())

        assert reseller.offer_group is None

    def test_a_reseller_created_by_a_new_station_gets_the_default(self, tenant, svc):
        station = svc.create_delivery_station(
            {
                "is_also_reseller": True,
                "is_also_seller": False,
                "is_active": True,
                **_contact_data(),
            }
        )

        assert station.linked_reseller.offer_group_id == OfferGroup.get_default().pk

    def test_a_reseller_created_by_a_station_update_gets_the_default(self, tenant, svc):
        contact = ContactEntityFactory(address="St", zip_code="55555", city="City")
        station = DeliveryStationFactory(contact=contact)

        svc.update_delivery_station(
            station, {"is_also_reseller": True, "is_also_seller": False}
        )

        reseller = Reseller.objects.get(contact=contact)
        assert reseller.offer_group_id == OfferGroup.get_default().pk

    def test_a_station_update_leaves_an_existing_resellers_group_alone(
        self, tenant, svc
    ):
        contact = ContactEntityFactory(address="St", zip_code="66666", city="City")
        reseller = ResellerFactory(contact=contact, is_reseller=True, offer_group=None)
        station = DeliveryStationFactory(contact=contact)

        svc.update_delivery_station(
            station, {"is_also_reseller": True, "is_also_seller": False}
        )

        reseller.refresh_from_db()
        assert reseller.offer_group is None


# ---------------------------------------------------------------------------
# create_delivery_station
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestCreateDeliveryStation:
    def test_creates_station_with_contact(self, tenant, svc):
        data = {
            "is_also_reseller": False,
            "is_also_seller": False,
            "is_active": True,
            **_contact_data(),
        }
        station = svc.create_delivery_station(data)

        assert station.pk is not None
        assert station.contact is not None

    def test_also_creates_reseller(self, tenant, svc):
        data = {
            "is_also_reseller": True,
            "is_also_seller": False,
            "is_active": True,
            **_contact_data(),
        }
        station = svc.create_delivery_station(data)

        assert Reseller.objects.filter(contact=station.contact).exists()
        assert station.linked_reseller is not None
        assert station.linked_reseller.is_reseller


# ---------------------------------------------------------------------------
# update_reseller
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestUpdateReseller:
    def test_updates_reseller_fields(self, tenant, svc):
        contact = ContactEntityFactory(address="Old St", zip_code="11111", city="Old")
        reseller = ResellerFactory(contact=contact, is_reseller=True)

        updated = svc.update_reseller(
            reseller,
            {"is_seller": True, "is_also_delivery_station": False},
        )
        assert updated.is_seller

    def test_creates_ds_when_is_also_delivery_station(self, tenant, svc):
        contact = ContactEntityFactory(address="Street", zip_code="22222", city="City")
        reseller = ResellerFactory(contact=contact, is_reseller=True)

        svc.update_reseller(
            reseller,
            {"is_also_delivery_station": True},
        )
        assert DeliveryStation.objects.filter(contact=contact).exists()


# ---------------------------------------------------------------------------
# update_delivery_station
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestUpdateDeliveryStation:
    def test_updates_station_fields(self, tenant, svc):
        contact = ContactEntityFactory(address="St", zip_code="33333", city="City")
        station = DeliveryStationFactory(contact=contact)

        updated = svc.update_delivery_station(
            station,
            {"is_also_reseller": False, "is_also_seller": False},
        )
        assert updated.pk is not None

    def test_creates_reseller_when_flags_set(self, tenant, svc):
        contact = ContactEntityFactory(address="St", zip_code="44444", city="City")
        station = DeliveryStationFactory(contact=contact)

        svc.update_delivery_station(
            station,
            {"is_also_reseller": True, "is_also_seller": False},
        )
        assert Reseller.objects.filter(contact=contact).exists()


# ---------------------------------------------------------------------------
# delete_reseller
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestDeleteReseller:
    def test_delete_seller_keeps_reseller(self, tenant, svc):
        reseller = ResellerFactory(is_reseller=True, is_seller=True)
        svc.delete_reseller(reseller, delete_context="sellers")

        reseller.refresh_from_db()
        assert reseller.is_reseller
        assert not reseller.is_seller

    def test_delete_reseller_keeps_seller(self, tenant, svc):
        reseller = ResellerFactory(is_reseller=True, is_seller=True)
        svc.delete_reseller(reseller, delete_context="resellers")

        reseller.refresh_from_db()
        assert not reseller.is_reseller
        assert reseller.is_seller

    def test_fully_deletes_when_only_role(self, tenant, svc):
        reseller = ResellerFactory(is_reseller=False, is_seller=True)
        pk = reseller.pk
        svc.delete_reseller(reseller, delete_context="sellers")
        assert not Reseller.objects.filter(pk=pk).exists()

    def test_unknown_context_is_refused_rather_than_ignored(self, tenant, svc):
        """Neither branch matches, and doing nothing would report a successful
        delete to a caller whose row is still there. The endpoint validates the
        value against the catalogue, so reaching this is a programmer error."""
        reseller = ResellerFactory(is_reseller=True, is_seller=True)

        with pytest.raises(ValueError):
            svc.delete_reseller(reseller, delete_context="typo")

        assert Reseller.objects.filter(pk=reseller.pk).exists()


# ---------------------------------------------------------------------------
# delete_delivery_station
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestDeleteDeliveryStation:
    def test_deletes_and_unlinks_reseller(self, tenant, svc):
        contact = ContactEntityFactory(address="St", zip_code="55555", city="City")
        reseller = ResellerFactory(contact=contact)
        station = DeliveryStationFactory(contact=contact, linked_reseller=reseller)

        svc.delete_delivery_station(station)

        reseller.refresh_from_db()
        # ``linked_delivery_station`` is the reverse OneToOne; if the station
        # is gone the reverse accessor raises, so use ``hasattr`` to check.
        assert not hasattr(reseller, "linked_delivery_station")

    def test_deletes_orphaned_contact(self, tenant, svc):
        contact = ContactEntityFactory(address="St", zip_code="66666", city="City")
        station = DeliveryStationFactory(contact=contact)
        contact_pk = contact.pk

        svc.delete_delivery_station(station)

        assert not ContactEntity.objects.filter(pk=contact_pk).exists()

    def test_delete_refused_when_station_has_deliveries(self, tenant, svc):
        # A station whose pickup days carry ShareDeliveries must NOT be
        # deletable — the CASCADE would silently wipe the billing basis.
        from apps.commissioning.errors import DeliveryStationInUse
        from apps.commissioning.tests.factories import (
            DeliveryStationDayFactory,
            ShareDeliveryFactory,
            ShareFactory,
            SharesDeliveryDayFactory,
        )

        station = DeliveryStationFactory()
        delivery_day = SharesDeliveryDayFactory(day_number=2)
        dsd = DeliveryStationDayFactory(
            delivery_station=station, delivery_day=delivery_day
        )
        ShareDeliveryFactory(
            share=ShareFactory(delivery_day=delivery_day),
            delivery_station_day=dsd,
        )

        with pytest.raises(DeliveryStationInUse):
            svc.delete_delivery_station(station)
        assert DeliveryStation.objects.filter(pk=station.pk).exists()


# ---------------------------------------------------------------------------
# Contact uniqueness
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestContactUniqueness:
    """Reseller / DeliveryStation are 1:1 with a ContactEntity, so the
    ``get_or_create(contact=…)`` / ``.get(contact=…)`` callers can rely on at
    most one row per contact. The partial unique constraint enforces it on
    non-null contacts — and a concurrent ``get_or_create`` race becomes a
    catchable IntegrityError (re-fetched) instead of two rows that later blow up
    ``.get(contact=…)`` with MultipleObjectsReturned."""

    def test_duplicate_reseller_contact_rejected(self, tenant):
        contact = ContactEntityFactory()
        ResellerFactory(contact=contact)
        with pytest.raises(IntegrityError):
            with transaction.atomic():
                ResellerFactory(contact=contact)

    def test_duplicate_delivery_station_contact_rejected(self, tenant):
        contact = ContactEntityFactory()
        DeliveryStationFactory(contact=contact)
        with pytest.raises(IntegrityError):
            with transaction.atomic():
                DeliveryStationFactory(contact=contact)

    def test_get_or_create_contact_is_idempotent(self, tenant):
        contact = ContactEntityFactory()
        first, created_first = Reseller.objects.get_or_create(contact=contact)
        second, created_second = Reseller.objects.get_or_create(contact=contact)
        assert created_first is True
        assert created_second is False
        assert first.pk == second.pk

    def test_reseller_contact_is_required(self, tenant):
        # ``Reseller.contact`` is a required FK — a contactless reseller is
        # rejected at the DB level (its address / e-mail / name live there).
        with pytest.raises(IntegrityError):
            with transaction.atomic():
                ResellerFactory(contact=None)

    def test_multiple_null_contacts_allowed_for_delivery_station(self, tenant):
        # DeliveryStation.contact stays nullable, and the unique constraint is
        # partial (``contact IS NOT NULL``), so contactless stations are
        # unconstrained (they can carry inline contact_name / contact_phone).
        DeliveryStationFactory(contact=None)
        DeliveryStationFactory(contact=None)
        assert DeliveryStation.objects.filter(contact__isnull=True).count() >= 2
