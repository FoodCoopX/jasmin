from django.db import models

from .base import JasminModel
from .mixin import CreatedMixin


class OfferSending(JasminModel, CreatedMixin):
    """One row per bulk-send of an OfferGroup × (year, delivery_week)
    to a reseller.

    The unit of work for a "send offers" action is the WHOLE OfferGroup
    for a specific (year, delivery_week) — not a single Offer. Within
    that group there are many Offer rows (one per share article); the
    outgoing email packs them all into one table. So the composite key
    ``(offer_group, year, delivery_week, reseller)`` is the right
    identity for "we sent THIS particular thing to this reseller".

    The unique constraint enforces idempotency at the DB layer: a
    second send to the same composite key will raise IntegrityError
    instead of silently creating a duplicate audit row. The service
    pre-checks with ``.exists()`` to give a clean per-reseller skip
    in the bulk-send response; the DB constraint catches everything
    else (raw SQL, future contributors, races).
    """

    offer_group = models.ForeignKey(
        "OfferGroup",
        on_delete=models.CASCADE,
        related_name="+",
    )
    year = models.PositiveSmallIntegerField()
    delivery_week = models.PositiveSmallIntegerField()
    reseller = models.ForeignKey(
        "Reseller",
        on_delete=models.CASCADE,
        related_name="+",
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["offer_group", "year", "delivery_week", "reseller"],
                name="offersending_unique_composite_key",
            ),
        ]


class ReminderSending(JasminModel, CreatedMixin):
    """Idempotency + audit record: one row per ``(invoice, day)`` that a bulk
    payment reminder covered.

    The bulk reminder send is consolidated per reseller (one email listing
    their ticked overdue invoices). Without a dedup record, a retry after a
    'failed' job — or a re-click — re-sends dunning for every invoice already
    reminded. The composite-unique ``(invoice, sent_on)`` makes a same-day
    re-run leave those invoices out (the service pre-checks for a clean skip;
    the DB constraint catches races / raw SQL), while another invoice of the
    same reseller is still reminded that day. A genuinely new reminder on a
    later day has a different ``sent_on`` and is allowed.

    ``invoice`` may be null: such a row records only the reseller and the day,
    and the send counts it for every invoice of that reseller that day.
    ``sent_on`` is a DATE (not ``created_at``): a unique on the full timestamp
    would never collide and so provide no dedup at all.
    """

    reseller = models.ForeignKey(
        "Reseller",
        on_delete=models.CASCADE,
        related_name="+",
    )
    invoice = models.ForeignKey(
        "InvoiceReseller",
        on_delete=models.CASCADE,
        related_name="+",
        blank=True,
        null=True,
    )
    sent_on = models.DateField()

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["invoice", "sent_on"],
                name="remindersending_unique_invoice_day",
            ),
        ]
