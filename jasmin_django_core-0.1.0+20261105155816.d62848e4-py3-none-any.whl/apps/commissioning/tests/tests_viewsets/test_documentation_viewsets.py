"""Tests for documentation_viewsets.py — Plot, Forecast, Waste, Purchase, Harvest."""

from __future__ import annotations

import datetime
from decimal import Decimal
from unittest.mock import patch

import pytest
import time_machine
from django.urls import reverse
from rest_framework import status

from apps.commissioning.constants import PURCHASE_DAY
from apps.commissioning.models import (
    AdditionalTheoreticalPurchase,
    Forecast,
    ForecastOfferGroup,
    ForecastShareTypeVariation,
    Harvest,
    MovementShareArticle,
    Purchase,
    Waste,
)
from apps.commissioning.tests.factories import (
    ForecastFactory,
    ForecastShareTypeVariationFactory,
    HarvestFactory,
    MovementShareArticleFactory,
    OfferGroupFactory,
    PlotFactory,
    PurchaseFactory,
    ResellerFactory,
    ShareArticleFactory,
    ShareTypeVariationFactory,
    StorageFactory,
    WasteFactory,
)


@pytest.fixture(autouse=True)
def _frozen_clock():
    # The writes go to weeks 15, 16 and 28 of 2026, which the documentation
    # endpoints refuse once they lie more than a week back; on Monday of week 15
    # none of them does.
    with time_machine.travel(datetime.datetime(2026, 4, 6, 12, 0), tick=False):
        yield


# ---------------------------------------------------------------------------
# PlotViewSet
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestPlotViewSet:
    URL = reverse("plots-list")

    def test_list_empty(self, api_client, tenant):
        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_200_OK

    def test_list_returns_plots(self, api_client, tenant):
        PlotFactory()
        resp = api_client.get(self.URL)
        assert len(resp.data) >= 1

    def test_filter_is_active(self, api_client, tenant):
        PlotFactory(is_active=True)
        PlotFactory(is_active=False)
        resp = api_client.get(self.URL, {"is_active": "true"})
        for p in resp.data:
            assert p["is_active"] is True

    def test_create_plot(self, api_client, tenant):
        resp = api_client.post(
            self.URL, {"name": "Field A", "is_active": True}, format="json"
        )
        assert resp.status_code == status.HTTP_201_CREATED

    def test_retrieve_plot(self, api_client, tenant):
        plot = PlotFactory()
        url = reverse("plots-detail", kwargs={"pk": plot.pk})
        resp = api_client.get(url)
        assert resp.status_code == status.HTTP_200_OK

    def test_delete_plot(self, api_client, tenant):
        plot = PlotFactory()
        url = reverse("plots-detail", kwargs={"pk": plot.pk})
        resp = api_client.delete(url)
        assert resp.status_code == status.HTTP_204_NO_CONTENT


# ---------------------------------------------------------------------------
# WasteViewSet
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestWasteViewSet:
    URL = reverse("waste-list")

    def test_list_empty(self, api_client, tenant):
        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_200_OK

    def test_list_returns_waste(self, api_client, tenant):
        WasteFactory()
        resp = api_client.get(self.URL)
        assert len(resp.data) >= 1

    def test_create_with_page_level_storage(self, api_client, tenant):
        """A waste create carries the page-level storage as the plain `storage`
        FK (the shape DocumentationWaste sends). The row lands
        on that storage."""
        storage = StorageFactory(is_short_term_harvest_storage=True)
        article = ShareArticleFactory()
        resp = api_client.post(
            self.URL,
            {
                "year": 2026,
                "delivery_week": 28,
                "day_number": 1,
                "share_article": str(article.id),
                "unit": "KG",
                "size": "M",
                "amount": "3",
                "storage": str(storage.id),
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        waste = Waste.objects.get(id=resp.data["id"])
        assert waste.storage_id == storage.id

    def test_create_without_plain_storage_is_rejected(self, api_client, tenant):
        """The ``storage_<id>`` flag alone does NOT satisfy the required
        ``storage`` FK — the client must send the resolved plain ``storage``."""
        storage = StorageFactory(is_short_term_harvest_storage=True)
        article = ShareArticleFactory()
        resp = api_client.post(
            self.URL,
            {
                "year": 2026,
                "delivery_week": 28,
                "day_number": 1,
                "share_article": str(article.id),
                "unit": "KG",
                "size": "M",
                "amount": "3",
                f"storage_{storage.id}": True,
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert "storage" in resp.data["details"]

    def _post_waste(self, api_client, article, storage):
        return api_client.post(
            self.URL,
            {
                "year": 2026,
                "delivery_week": 28,
                "day_number": 1,
                "share_article": str(article.id),
                "unit": "KG",
                "size": "M",
                "amount": "3",
                "storage": str(storage.id),
            },
            format="json",
        )

    def test_same_article_on_the_same_day_in_another_storage_is_recorded(
        self, api_client, tenant
    ):
        """The page lists one storage's waste, so a waste of the same article,
        unit and size thrown away from another storage that day is its own
        row."""
        article = ShareArticleFactory()
        WasteFactory(
            year=2026,
            delivery_week=28,
            day_number=1,
            share_article=article,
            unit="KG",
            size="M",
            storage=StorageFactory(is_short_term_harvest_storage=True),
        )
        other_storage = StorageFactory()

        resp = self._post_waste(api_client, article, other_storage)

        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert Waste.objects.filter(share_article=article).count() == 2

    def test_same_article_on_the_same_day_in_the_same_storage_is_refused(
        self, api_client, tenant
    ):
        article = ShareArticleFactory()
        storage = StorageFactory(is_short_term_harvest_storage=True)
        WasteFactory(
            year=2026,
            delivery_week=28,
            day_number=1,
            share_article=article,
            unit="KG",
            size="M",
            storage=storage,
        )

        resp = self._post_waste(api_client, article, storage)

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "waste.already_documented"
        assert "non_field_errors" in resp.data["details"]
        assert Waste.objects.filter(share_article=article).count() == 1

    def test_moving_a_waste_onto_a_documented_one_is_refused(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory(is_short_term_harvest_storage=True)
        key = {
            "year": 2026,
            "delivery_week": 28,
            "day_number": 1,
            "share_article": article,
            "unit": "KG",
            "size": "M",
        }
        WasteFactory(**key, storage=storage)
        other = WasteFactory(**key, storage=StorageFactory())

        resp = api_client.patch(
            reverse("waste-detail", args=[other.pk]),
            {"storage": str(storage.id)},
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "waste.already_documented"

    def test_saving_a_waste_unchanged_is_not_a_duplicate_of_itself(
        self, api_client, tenant
    ):
        waste = WasteFactory(
            year=2026,
            delivery_week=28,
            day_number=1,
            unit="KG",
            size="M",
            storage=StorageFactory(is_short_term_harvest_storage=True),
        )

        resp = api_client.patch(
            reverse("waste-detail", args=[waste.pk]),
            {"amount": "4", "storage": str(waste.storage_id)},
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK, resp.data


# ---------------------------------------------------------------------------
# HarvestViewSet
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestHarvestViewSet:
    URL = reverse("harvest-list")

    def test_list_empty(self, api_client, tenant):
        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_200_OK

    def test_list_returns_harvests(self, api_client, tenant):
        HarvestFactory()
        resp = api_client.get(self.URL)
        assert len(resp.data) >= 1

    KEY = {
        "year": 2026,
        "delivery_week": 28,
        "day_number": 1,
        "unit": "KG",
        "size": "M",
    }

    def _post_harvest(self, api_client, article, storage):
        return api_client.post(
            self.URL,
            {
                **self.KEY,
                "share_article": str(article.id),
                "amount": "3",
                "storage": str(storage.id),
            },
            format="json",
        )

    def test_same_article_on_the_same_day_in_the_same_storage_is_refused(
        self, api_client, tenant
    ):
        article = ShareArticleFactory()
        storage = StorageFactory(is_short_term_harvest_storage=True)
        HarvestFactory(**self.KEY, share_article=article, storage=storage)

        resp = self._post_harvest(api_client, article, storage)

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "harvest.already_documented"
        assert "non_field_errors" in resp.data["details"]
        assert Harvest.objects.filter(share_article=article).count() == 1

    def test_same_article_on_the_same_day_in_another_storage_is_recorded(
        self, api_client, tenant
    ):
        article = ShareArticleFactory()
        HarvestFactory(
            **self.KEY,
            share_article=article,
            storage=StorageFactory(is_short_term_harvest_storage=True),
        )

        resp = self._post_harvest(api_client, article, StorageFactory())

        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert Harvest.objects.filter(share_article=article).count() == 2

    def test_moving_a_harvest_onto_a_documented_one_is_refused(
        self, api_client, tenant
    ):
        article = ShareArticleFactory()
        storage = StorageFactory(is_short_term_harvest_storage=True)
        HarvestFactory(**self.KEY, share_article=article, storage=storage)
        other = HarvestFactory(
            **self.KEY, share_article=article, storage=StorageFactory()
        )

        resp = api_client.patch(
            reverse("harvest-detail", args=[other.pk]),
            {"storage": str(storage.id)},
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "harvest.already_documented"
        other.refresh_from_db()
        assert other.storage_id != storage.id

    def test_saving_a_harvest_unchanged_is_not_a_duplicate_of_itself(
        self, api_client, tenant
    ):
        harvest = HarvestFactory(
            **self.KEY, storage=StorageFactory(is_short_term_harvest_storage=True)
        )

        resp = api_client.patch(
            reverse("harvest-detail", args=[harvest.pk]),
            {"amount": "4", "storage": str(harvest.storage_id)},
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK, resp.data


# ---------------------------------------------------------------------------
# PurchaseViewSet
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestPurchaseViewSet:
    URL = reverse("purchase-list")

    def test_list_empty(self, api_client, tenant):
        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_200_OK

    def test_list_returns_purchases(self, api_client, tenant):
        PurchaseFactory()
        resp = api_client.get(self.URL)
        assert len(resp.data) >= 1

    def test_create_with_page_level_storage(self, api_client, tenant):
        """A new-row create carries the page-level storage as the plain `storage`
        FK (the shape DocumentationPurchase sends, mirroring
        DocumentationHarvest). The row lands on that storage."""
        storage = StorageFactory(is_short_term_harvest_storage=True)
        article = ShareArticleFactory(is_purchased=True)
        resp = api_client.post(
            self.URL,
            {
                "year": 2026,
                "delivery_week": 28,
                "share_article": str(article.id),
                "unit": "KG",
                "size": "M",
                "amount": "5",
                "storage": str(storage.id),
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        purchase = Purchase.objects.get(id=resp.data["id"])
        assert purchase.storage_id == storage.id

    KEY = {"year": 2026, "delivery_week": 28, "unit": "KG", "size": "M"}

    def _post_purchase(self, api_client, article, storage, **extra):
        return api_client.post(
            self.URL,
            {
                **self.KEY,
                "share_article": str(article.id),
                "amount": "5",
                "storage": str(storage.id),
                **extra,
            },
            format="json",
        )

    def test_same_article_from_the_same_seller_in_the_same_storage_is_refused(
        self, api_client, tenant
    ):
        """The page sends no day; the purchase lands on the purchase day, where
        the supplier's documented row already is."""
        article = ShareArticleFactory(is_purchased=True)
        seller = ResellerFactory()
        storage = StorageFactory()
        PurchaseFactory(
            **self.KEY,
            day_number=PURCHASE_DAY,
            share_article=article,
            seller=seller,
            storage=storage,
            amount=Decimal("3"),
        )

        resp = self._post_purchase(api_client, article, storage, seller=str(seller.id))

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "purchase.already_documented"
        assert "non_field_errors" in resp.data["details"]
        assert Purchase.objects.filter(share_article=article).count() == 1

    def test_same_article_from_the_same_seller_in_another_storage_is_recorded(
        self, api_client, tenant
    ):
        article = ShareArticleFactory(is_purchased=True)
        seller = ResellerFactory()
        PurchaseFactory(
            **self.KEY,
            day_number=PURCHASE_DAY,
            share_article=article,
            seller=seller,
            storage=StorageFactory(),
        )

        resp = self._post_purchase(
            api_client, article, StorageFactory(), seller=str(seller.id)
        )

        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert Purchase.objects.filter(share_article=article).count() == 2

    def test_same_article_from_another_seller_is_recorded(self, api_client, tenant):
        article = ShareArticleFactory(is_purchased=True)
        storage = StorageFactory()
        PurchaseFactory(
            **self.KEY,
            day_number=1,
            share_article=article,
            seller=ResellerFactory(),
            storage=storage,
        )

        resp = self._post_purchase(
            api_client,
            article,
            storage,
            day_number=1,
            seller=str(ResellerFactory().id),
        )

        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert Purchase.objects.filter(share_article=article).count() == 2

    def test_same_article_without_a_seller_in_the_same_storage_is_refused(
        self, api_client, tenant
    ):
        """The page sends no day; the purchase lands on the purchase day, where
        the no-seller row already is."""
        article = ShareArticleFactory(is_purchased=True)
        storage = StorageFactory()
        PurchaseFactory(
            **self.KEY,
            day_number=PURCHASE_DAY,
            share_article=article,
            seller=None,
            storage=storage,
            amount=Decimal("3"),
        )

        resp = self._post_purchase(api_client, article, storage)

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "purchase.already_documented_without_seller"
        assert Purchase.objects.filter(share_article=article).count() == 1

    def test_same_article_without_a_seller_in_another_storage_is_recorded(
        self, api_client, tenant
    ):
        article = ShareArticleFactory(is_purchased=True)
        PurchaseFactory(
            **self.KEY,
            day_number=None,
            share_article=article,
            seller=None,
            storage=StorageFactory(),
        )

        resp = self._post_purchase(api_client, article, StorageFactory())

        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert Purchase.objects.filter(share_article=article).count() == 2

    def test_moving_a_purchase_onto_a_documented_one_is_refused(
        self, api_client, tenant
    ):
        article = ShareArticleFactory(is_purchased=True)
        seller = ResellerFactory()
        storage = StorageFactory()
        PurchaseFactory(
            **self.KEY,
            day_number=1,
            share_article=article,
            seller=seller,
            storage=storage,
        )
        other = PurchaseFactory(
            **self.KEY,
            day_number=1,
            share_article=article,
            seller=ResellerFactory(),
            storage=storage,
        )

        resp = api_client.patch(
            reverse("purchase-detail", args=[other.pk]),
            {"seller": str(seller.id)},
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "purchase.already_documented"
        other.refresh_from_db()
        assert other.seller_id != seller.id

    def test_saving_a_purchase_unchanged_is_not_a_duplicate_of_itself(
        self, api_client, tenant
    ):
        purchase = PurchaseFactory(
            **self.KEY, day_number=None, seller=None, storage=StorageFactory()
        )

        resp = api_client.patch(
            reverse("purchase-detail", args=[purchase.pk]),
            {"amount": "6", "storage": str(purchase.storage_id)},
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK, resp.data


# ---------------------------------------------------------------------------
# ForecastViewSet
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestForecastViewSet:
    URL = reverse("forecast-list")

    def test_list_requires_year_and_week(self, api_client, tenant):
        # year + delivery_week are required query params (matches the schema);
        # omitting them must not fall through to an unprefetched list of all
        # forecasts.
        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_list_empty_for_week_without_forecasts(self, api_client, tenant):
        resp = api_client.get(self.URL, {"year": 2099, "delivery_week": 1})
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == []

    def test_list_returns_forecasts(self, api_client, tenant):
        ForecastFactory(year=2026, delivery_week=15)
        resp = api_client.get(self.URL, {"year": 2026, "delivery_week": 15})
        assert resp.status_code == status.HTTP_200_OK
        assert len(resp.data) >= 1

    def test_filter_by_year_and_week(self, api_client, tenant):
        _fc = ForecastFactory(year=2026, delivery_week=15)
        resp = api_client.get(self.URL, {"year": 2026, "delivery_week": 15})
        assert resp.status_code == status.HTTP_200_OK


# ---------------------------------------------------------------------------
# ForecastViewSet — bad variation_<id> key → 404 (not a 500)
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestForecastInvalidVariation:
    """A non-existent ``variation_<id>`` key must surface as a stable 404
    (``share_type_variation.not_found``), not an opaque 500."""

    URL = reverse("forecast-list")

    def test_create_with_unknown_variation_returns_404(self, api_client, tenant):
        article = ShareArticleFactory()
        resp = api_client.post(
            self.URL,
            {
                "year": 2026,
                "delivery_week": 15,
                "share_article": str(article.id),
                "unit": "KG",
                "size": "M",
                # explicit-id path, not the "for all" bulk-add branch
                "for_all_harvest_shares": False,
                "for_all_harvest_shares_fruit": False,
                "variation_nonexistent-id": True,
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND
        assert resp.data["code"] == "share_type_variation.not_found"

    def test_update_with_unknown_variation_returns_404(self, api_client, tenant):
        forecast = ForecastFactory(year=2026, delivery_week=15)
        url = reverse("forecast-detail", kwargs={"pk": forecast.pk})
        resp = api_client.patch(
            url,
            {
                "for_all_harvest_shares": False,
                "for_all_harvest_shares_fruit": False,
                "variation_nonexistent-id": True,
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND
        assert resp.data["code"] == "share_type_variation.not_found"


# ---------------------------------------------------------------------------
# ForecastViewSet — a PATCH that names only the changed fields
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestForecastPartialUpdate:
    """A PATCH carries only what changed: the week, unit, size and the
    variation / offer-group selection it leaves out are the stored ones."""

    def _patch(self, api_client, forecast, payload):
        url = reverse("forecast-detail", kwargs={"pk": forecast.pk})
        return api_client.patch(url, payload, format="json")

    def test_amount_only_updates_the_amount(self, api_client, tenant):
        forecast = ForecastFactory(year=2026, delivery_week=15, amount=3)

        resp = self._patch(api_client, forecast, {"amount": "7"})

        assert resp.status_code == status.HTTP_200_OK, resp.data
        forecast.refresh_from_db()
        assert forecast.amount == Decimal("7")
        assert (forecast.year, forecast.delivery_week) == (2026, 15)

    def test_note_only_updates_the_note(self, api_client, tenant):
        forecast = ForecastFactory(year=2026, delivery_week=15)

        resp = self._patch(api_client, forecast, {"note": "late frost"})

        assert resp.status_code == status.HTTP_200_OK, resp.data
        forecast.refresh_from_db()
        assert forecast.note == "late frost"

    def test_amount_only_keeps_the_variations_and_offer_groups(
        self, api_client, tenant
    ):
        forecast = ForecastFactory(
            year=2026, delivery_week=15, amount=3, for_all_harvest_shares=False
        )
        variation = ShareTypeVariationFactory()
        ForecastShareTypeVariationFactory(
            forecast=forecast, share_type_variation=variation
        )
        offer_group = OfferGroupFactory()
        ForecastOfferGroup.objects.create(forecast=forecast, offer_group=offer_group)

        resp = self._patch(api_client, forecast, {"amount": "7"})

        assert resp.status_code == status.HTTP_200_OK, resp.data
        assert resp.data[f"variation_{variation.pk}"] is True
        assert resp.data[f"offer_group_{offer_group.pk}"] is True
        assert ForecastShareTypeVariation.objects.filter(
            forecast=forecast, share_type_variation=variation
        ).exists()
        assert ForecastOfferGroup.objects.filter(
            forecast=forecast, offer_group=offer_group
        ).exists()

    def test_a_flag_set_to_false_still_removes_its_variation(self, api_client, tenant):
        forecast = ForecastFactory(
            year=2026, delivery_week=15, for_all_harvest_shares=False
        )
        variation = ShareTypeVariationFactory()
        ForecastShareTypeVariationFactory(
            forecast=forecast, share_type_variation=variation
        )

        resp = self._patch(
            api_client, forecast, {"amount": "7", f"variation_{variation.pk}": False}
        )

        assert resp.status_code == status.HTTP_200_OK, resp.data
        assert not ForecastShareTypeVariation.objects.filter(forecast=forecast).exists()


# ---------------------------------------------------------------------------
# ForecastViewSet — bulk_copy_to_next_week @action
# ---------------------------------------------------------------------------
URL_FORECAST_BULK_COPY = reverse("forecast-bulk-copy-to-next-week")


@pytest.mark.django_db
class TestForecastBulkCopyToNextWeek:
    def test_empty_ids_returns_400(self, api_client, tenant):
        resp = api_client.post(URL_FORECAST_BULK_COPY, {"ids": []}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_unknown_ids_returns_404(self, api_client, tenant):
        resp = api_client.post(
            URL_FORECAST_BULK_COPY,
            {"ids": ["nonexistent-id"]},
            format="json",
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND

    def test_copies_existing_forecast(self, api_client, tenant):
        fc = ForecastFactory(year=2026, delivery_week=15)
        resp = api_client.post(
            URL_FORECAST_BULK_COPY,
            {"ids": [str(fc.id)]},
            format="json",
        )
        assert resp.status_code == status.HTTP_201_CREATED
        assert resp.data == {"success": True, "errors": []}

    def test_partial_selection_copies_the_rest_and_names_the_missing_ids(
        self, api_client, tenant
    ):
        """One unknown id must not silently shrink the batch: the known
        forecasts are copied and the skipped ones are reported."""
        fc = ForecastFactory(year=2026, delivery_week=15)

        resp = api_client.post(
            URL_FORECAST_BULK_COPY,
            {"ids": [str(fc.id), "nonexistent-id"]},
            format="json",
        )

        assert resp.status_code == status.HTTP_201_CREATED
        assert resp.data["success"] is True
        assert resp.data["errors"] == [
            {"id": "nonexistent-id", "error": "Forecast not found"}
        ]
        assert Forecast.objects.filter(
            share_article=fc.share_article, year=2026, delivery_week=16
        ).exists()

    def test_already_planned_forecast_is_named_in_errors(self, api_client, tenant):
        """A forecast the next week already plans is a no-op in the service, so
        it is reported instead of being counted as a copy."""
        fc = ForecastFactory(year=2026, delivery_week=15)
        ForecastFactory(
            year=2026,
            delivery_week=16,
            share_article=fc.share_article,
            unit=fc.unit,
            size=fc.size,
        )

        resp = api_client.post(
            URL_FORECAST_BULK_COPY,
            {"ids": [str(fc.id)]},
            format="json",
        )

        assert resp.status_code == status.HTTP_201_CREATED
        assert resp.data["errors"] == [
            {"id": str(fc.id), "error": "Already planned for the next week"}
        ]
        assert (
            Forecast.objects.filter(
                share_article=fc.share_article, year=2026, delivery_week=16
            ).count()
            == 1
        )

    def test_mixed_batch_names_every_skip_in_request_order(self, api_client, tenant):
        """An unknown id and an already-planned forecast are both reported,
        ordered by the request, while the copyable forecast is copied."""
        copyable = ForecastFactory(year=2026, delivery_week=15)
        already_planned = ForecastFactory(year=2026, delivery_week=15)
        ForecastFactory(
            year=2026,
            delivery_week=16,
            share_article=already_planned.share_article,
            unit=already_planned.unit,
            size=already_planned.size,
        )

        resp = api_client.post(
            URL_FORECAST_BULK_COPY,
            {"ids": [str(copyable.id), str(already_planned.id), "nonexistent-id"]},
            format="json",
        )

        assert resp.status_code == status.HTTP_201_CREATED
        assert resp.data["success"] is True
        assert resp.data["errors"] == [
            {
                "id": str(already_planned.id),
                "error": "Already planned for the next week",
            },
            {"id": "nonexistent-id", "error": "Forecast not found"},
        ]
        assert Forecast.objects.filter(
            share_article=copyable.share_article, year=2026, delivery_week=16
        ).exists()


# ---------------------------------------------------------------------------
# PurchaseViewSet / HarvestViewSet — bulk_set_as_expected + export_csv @actions
# ---------------------------------------------------------------------------
URL_PURCHASE_BULK_SET_EXPECTED = reverse("purchase-bulk-set-as-expected")
URL_PURCHASE_EXPORT_CSV = reverse("purchase-export-csv")
URL_HARVEST_BULK_SET_EXPECTED = reverse("harvest-bulk-set-as-expected")
URL_HARVEST_EXPORT_CSV = reverse("harvest-export-csv")


@pytest.mark.django_db
class TestPurchaseExportCsv:
    def test_missing_dates_returns_400(self, api_client, tenant):
        """``_csv_export_response`` validates date_from / date_to params."""
        resp = api_client.get(URL_PURCHASE_EXPORT_CSV)
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "query.invalid_param"
        assert resp.data["field"] == "date_from"

    def test_malformed_date_returns_400(self, api_client, tenant):
        """The pair is parsed by the catalogue's ``date`` kind, which takes
        YYYY-MM-DD only — a compact or week-date spelling is refused, naming
        the parameter, instead of reaching the export."""
        resp = api_client.get(
            URL_PURCHASE_EXPORT_CSV,
            {"date_from": "20990101", "date_to": "2099-01-31"},
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "query.invalid_param"
        assert resp.data["field"] == "date_from"

    def test_empty_range_returns_csv(self, api_client, tenant):
        resp = api_client.get(
            URL_PURCHASE_EXPORT_CSV,
            {"date_from": "2099-01-01", "date_to": "2099-01-31"},
        )
        assert resp.status_code == status.HTTP_200_OK
        assert "text/csv" in resp["Content-Type"]

    def test_week_scoped_purchase_included_and_labels_localized(
        self, api_client, tenant
    ):
        """A week-scoped purchase (no day_number) must appear whenever its
        delivery WEEK overlaps the range — not only when the week's Monday sits
        inside it — and the unit/size codes render as
        localized labels, not raw ``PCS`` / ``M``."""
        from decimal import Decimal

        from apps.commissioning.services.documentation_export_service import (
            DocumentationExportService,
        )
        from apps.commissioning.tests.factories import ResellerFactory

        article = ShareArticleFactory(is_purchased=True, name="Möhren")
        storage = StorageFactory(is_short_term_harvest_storage=True)
        # A seller exercises the seller-name path (Reseller has no ``.name`` —
        # it's on ``seller.contact``).
        seller = ResellerFactory()
        PurchaseFactory(
            year=2026,
            delivery_week=15,
            day_number=None,
            share_article=article,
            unit="PCS",
            size="M",
            amount=Decimal("7"),
            storage=storage,
            seller=seller,
            organic_status="organic",
        )
        # ISO week 15/2026 = Mon 2026-04-06 .. Sun 2026-04-12; start on Tuesday so
        # a Monday-anchored filter would drop the row.
        resp = api_client.get(
            URL_PURCHASE_EXPORT_CSV,
            {"date_from": "2026-04-07", "date_to": "2026-04-12"},
        )
        assert resp.status_code == status.HTTP_200_OK
        body = b"".join(resp.streaming_content).decode("utf-8")
        assert "Möhren" in body
        lang = DocumentationExportService._resolve_csv_language()
        assert {"de": "Stk", "en": "pcs"}[lang] in body
        assert {"de": "mittel", "en": "medium"}[lang] in body
        assert "PCS" not in body
        # Organic status renders localized on the data row (checked on the row,
        # not the whole body, since "Bio"/"Organic" also appear in the header).
        data_line = next(line for line in body.splitlines() if "Möhren" in line)
        assert {"de": "Bio", "en": "Organic"}[lang] in data_line
        # The seller's display name (from seller.contact, not seller.name) renders.
        assert seller.contact.name in data_line


@pytest.mark.django_db
class TestHarvestExportCsv:
    def test_empty_range_returns_csv(self, api_client, tenant):
        resp = api_client.get(
            URL_HARVEST_EXPORT_CSV,
            {"date_from": "2099-01-01", "date_to": "2099-01-31"},
        )
        assert resp.status_code == status.HTTP_200_OK
        assert "text/csv" in resp["Content-Type"]
        # The download name still carries the requested range, now rendered
        # from the parsed dates.
        assert "2099-01-01_2099-01-31" in resp["Content-Disposition"]

    def test_harvest_export_localizes_day_and_labels(self, api_client, tenant):
        """Harvest rows render the weekday + unit/size in the tenant CSV
        language, not the model's English ``get_day_number_display`` / raw
        codes."""
        from decimal import Decimal

        from apps.commissioning.services.documentation_export_service import (
            DocumentationExportService,
        )

        article = ShareArticleFactory(name="Zucchini")
        storage = StorageFactory(is_short_term_harvest_storage=True)
        HarvestFactory(
            year=2026,
            delivery_week=15,
            day_number=0,  # Monday 2026-04-06
            share_article=article,
            unit="PCS",
            size="M",
            amount=Decimal("3"),
            storage=storage,
        )
        resp = api_client.get(
            URL_HARVEST_EXPORT_CSV,
            {"date_from": "2026-04-06", "date_to": "2026-04-12"},
        )
        assert resp.status_code == status.HTTP_200_OK
        body = b"".join(resp.streaming_content).decode("utf-8")
        assert "Zucchini" in body
        lang = DocumentationExportService._resolve_csv_language()
        if lang == "de":
            assert "Montag" in body
            assert "Monday" not in body  # no untranslated English weekday
            assert "Stk" in body
        else:
            assert "Monday" in body


@pytest.mark.django_db
class TestBulkSetAsExpected:
    def test_purchase_empty_body_does_not_500(self, api_client, tenant):
        """Service tolerates empty payload (no theoretical rows to flip)."""
        resp = api_client.post(
            URL_PURCHASE_BULK_SET_EXPECTED, {"ids": []}, format="json"
        )
        # Service may return 204 (no content) or 200, but not 500.
        assert resp.status_code < 500

    def test_harvest_empty_body_does_not_500(self, api_client, tenant):
        resp = api_client.post(
            URL_HARVEST_BULK_SET_EXPECTED, {"ids": []}, format="json"
        )
        assert resp.status_code < 500

    def test_harvest_valid_payload_creates_harvest(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory(is_short_term_harvest_storage=True)
        payload = {
            "selectedData": [
                {
                    "id": str(article.id),
                    "year": 2026,
                    "delivery_week": 15,
                    "day_number": 1,
                    "theoretical_harvest_amount": 12.5,
                    "theoretical_harvest_unit": "KG",
                    "theoretical_harvest_size": "M",
                    "storage": str(storage.id),
                }
            ],
        }
        resp = api_client.post(URL_HARVEST_BULK_SET_EXPECTED, payload, format="json")
        assert resp.status_code == status.HTTP_204_NO_CONTENT
        harvest = Harvest.objects.get(
            year=2026,
            delivery_week=15,
            day_number=1,
            share_article_id=article.id,
            unit="KG",
            size="M",
            storage=storage,
        )
        assert float(harvest.amount) == 12.5

    def test_purchase_valid_payload_creates_purchase(self, api_client, tenant):
        article = ShareArticleFactory()
        storage = StorageFactory(is_short_term_harvest_storage=True)
        payload = {
            "selectedData": [
                {
                    "id": str(article.id),
                    "year": 2026,
                    "delivery_week": 15,
                    "theoretical_purchase_amount": 8.0,
                    "theoretical_purchase_unit": "KG",
                    "theoretical_purchase_size": "M",
                    "storage": str(storage.id),
                }
            ],
        }
        resp = api_client.post(URL_PURCHASE_BULK_SET_EXPECTED, payload, format="json")
        assert resp.status_code == status.HTTP_204_NO_CONTENT
        purchase = Purchase.objects.get(
            year=2026,
            delivery_week=15,
            share_article_id=article.id,
            unit="KG",
            size="M",
            storage=storage,
        )
        assert float(purchase.amount) == 8.0

    def test_harvest_malformed_item_returns_400(self, api_client, tenant):
        # Non-numeric amount → serializer.is_valid rejects the
        # request before the service runs.
        bad = {
            "selectedData": [
                {
                    "id": "x",
                    "year": 2026,
                    "delivery_week": 15,
                    "day_number": 1,
                    "theoretical_harvest_amount": "not-a-number",
                    "theoretical_harvest_unit": "KG",
                    "theoretical_harvest_size": "M",
                    "storage": "y",
                }
            ],
        }
        resp = api_client.post(URL_HARVEST_BULK_SET_EXPECTED, bad, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_purchase_malformed_item_returns_400(self, api_client, tenant):
        bad = {
            "selectedData": [
                {
                    "id": "x",
                    "year": 2026,
                    "delivery_week": 15,
                    "theoretical_purchase_amount": "abc",
                    "theoretical_purchase_unit": "KG",
                    "theoretical_purchase_size": "M",
                    "storage": "y",
                }
            ],
        }
        resp = api_client.post(URL_PURCHASE_BULK_SET_EXPECTED, bad, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST


# ---------------------------------------------------------------------------
# DocumentationSummaryViewSet — summary / add_additional / update_additional
# ---------------------------------------------------------------------------
URL_DS_SUMMARY = reverse("documentation_summary-summary")
URL_DS_ADD_ADDITIONAL = reverse(
    "documentation_summary-add-additional-theoretical-amount"
)


@pytest.mark.django_db
class TestDocumentationSummaryAction:
    def test_returns_empty_for_unused_week(self, api_client, tenant):
        resp = api_client.get(
            URL_DS_SUMMARY,
            {"year": 2099, "delivery_week": 1, "model": "harvest"},
        )
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == []


@pytest.mark.django_db
class TestAddAdditionalTheoreticalAmount:
    def test_invalid_model_returns_400(self, api_client, tenant):
        """``model`` must be one of harvest/purchase/washamount/cleanamount."""
        resp = api_client.post(
            URL_DS_ADD_ADDITIONAL,
            {"model": "not-a-real-model"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "documentation.invalid_model"
        # Machine-readable as well as in the prose, so the client can show the
        # value the caller sent without parsing the message.
        assert resp.data["details"] == {"model": "not-a-real-model"}

    def _payload(self, article, **overrides):
        return {
            "model": "washamount",
            "year": 2026,
            "delivery_week": 15,
            "day_number": 1,
            "share_article": str(article.id),
            "unit": "KG",
            "size": "M",
            "amount": "5.00",
            **overrides,
        }

    def test_creates_the_row(self, api_client, tenant):
        from decimal import Decimal

        from apps.commissioning.models import AdditionalTheoreticalWashAmount

        StorageFactory(is_short_term_harvest_storage=True)
        article = ShareArticleFactory()

        resp = api_client.post(
            URL_DS_ADD_ADDITIONAL, self._payload(article), format="json"
        )

        assert resp.status_code == status.HTTP_201_CREATED
        written = AdditionalTheoreticalWashAmount.objects.get()
        assert written.share_article_id == article.id
        assert written.amount == Decimal("5.00")

    @pytest.mark.parametrize(
        "field,value",
        [
            ("year", "abc"),
            ("year", 12),
            ("delivery_week", 99),
            ("day_number", 9),
            ("amount", "lots"),
        ],
    )
    def test_unusable_value_returns_400(self, api_client, tenant, field, value):
        """These reach ORM lookups and model writes, so a non-numeric year used
        to surface as a 500 rather than a request error."""
        StorageFactory(is_short_term_harvest_storage=True)
        article = ShareArticleFactory()

        resp = api_client.post(
            URL_DS_ADD_ADDITIONAL,
            self._payload(article, **{field: value}),
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_missing_share_article_returns_400(self, api_client, tenant):
        StorageFactory(is_short_term_harvest_storage=True)
        article = ShareArticleFactory()
        payload = self._payload(article)
        del payload["share_article"]

        resp = api_client.post(URL_DS_ADD_ADDITIONAL, payload, format="json")

        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_unknown_share_article_returns_404(self, api_client, tenant):
        """A well-formed id for a row that doesn't exist is a 404: the id is
        resolved before the service reads it."""
        StorageFactory(is_short_term_harvest_storage=True)
        article = ShareArticleFactory()

        resp = api_client.post(
            URL_DS_ADD_ADDITIONAL,
            self._payload(article, share_article="no-such-article"),
            format="json",
        )

        assert resp.status_code == status.HTTP_404_NOT_FOUND
        assert resp.data["code"] == "share_article.not_found"


def _update_additional_url(pk: str) -> str:
    return reverse(
        "documentation_summary-update-additional-theoretical-amount",
        kwargs={"pk": pk},
    )


# A purchase entry of week 16, which the purchase list of week 15 shows beside
# its own rows while "include next week" is ticked.
ENTRY_YEAR, ENTRY_WEEK = 2026, 16


@pytest.mark.django_db
class TestUpdateAdditionalTheoreticalAmount:
    def test_invalid_model_returns_400(self, api_client, tenant):
        url = reverse(
            "documentation_summary-update-additional-theoretical-amount",
            kwargs={"pk": "anything"},
        )
        resp = api_client.patch(url, {"model": "not-real"}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def _entry(self, api_client) -> Purchase:
        """The entry with an extra amount, a PU and a note, as the list adds it."""
        StorageFactory(is_short_term_harvest_storage=True)
        article = ShareArticleFactory(is_purchased=True)
        resp = api_client.post(
            URL_DS_ADD_ADDITIONAL,
            {
                "model": "purchase",
                "year": ENTRY_YEAR,
                "delivery_week": ENTRY_WEEK,
                "share_article": str(article.id),
                "unit": "KG",
                "size": "L",
                "seller": str(ResellerFactory().id),
                "amount": "2.00",
                "amount_per_pu": "1.5",
                "note": "next",
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        return Purchase.objects.get(share_article=article)

    @staticmethod
    def _written(purchase: Purchase) -> tuple:
        """What an update can write: the extra amounts, the PU, the movements."""
        article = purchase.share_article
        purchase.refresh_from_db()
        return (
            list(
                AdditionalTheoreticalPurchase.objects.filter(
                    share_article=article
                ).values_list("year", "delivery_week", "amount", "note")
            ),
            purchase.amount_per_pu,
            list(
                MovementShareArticle.objects.filter(share_article=article)
                .order_by("id")
                .values_list("id", "date", "amount")
            ),
        )

    @pytest.mark.parametrize(
        "week,field",
        [
            ({"year": ENTRY_YEAR, "delivery_week": ENTRY_WEEK - 1}, "delivery_week"),
            ({"year": ENTRY_YEAR + 1, "delivery_week": ENTRY_WEEK}, "year"),
            ({"delivery_week": ENTRY_WEEK - 1}, "delivery_week"),
        ],
        ids=["another-week", "another-year", "week-alone"],
    )
    def test_a_body_naming_another_week_is_refused(
        self, api_client, tenant, week, field
    ):
        purchase = self._entry(api_client)
        before = self._written(purchase)

        resp = api_client.patch(
            _update_additional_url(purchase.id),
            {
                "model": "purchase",
                **week,
                "amount": "10.00",
                "amount_per_pu": "2.5",
                "note": "this week",
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "documentation.week_mismatch"
        assert resp.data["field"] == field
        assert resp.data["details"] == {
            "year": ENTRY_YEAR,
            "delivery_week": ENTRY_WEEK,
        }
        # A client without a translation for the code shows the message.
        assert "reload the page" in resp.data["message"]
        assert self._written(purchase) == before

    @pytest.mark.parametrize(
        "week",
        [{"year": ENTRY_YEAR, "delivery_week": ENTRY_WEEK}, {}],
        ids=["its-own-week", "no-week"],
    )
    def test_a_body_naming_the_rows_own_week_or_none_updates_it(
        self, api_client, tenant, week
    ):
        purchase = self._entry(api_client)

        resp = api_client.patch(
            _update_additional_url(purchase.id),
            {"model": "purchase", **week, "amount": "4.00", "note": "edited"},
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK, resp.data
        additional, _, _ = self._written(purchase)
        assert additional == [(ENTRY_YEAR, ENTRY_WEEK, Decimal("4.00"), "edited")]


_CASCADE = (
    "apps.commissioning.services.snapshot_service.SnapshotService.cascade_for_movements"
)


@pytest.mark.django_db
class TestMovementSourceDeleteRecascades:
    """Deleting a Harvest/Purchase/Waste cascade-deletes its movement, so
    perform_destroy must re-cascade stock snapshots for the affected entity (the
    plain DRF destroy never recomputes)."""

    @pytest.mark.parametrize(
        "factory,viewset_name,fk",
        [
            (HarvestFactory, "HarvestViewSet", "harvest"),
            (PurchaseFactory, "PurchaseViewSet", "purchase"),
            (WasteFactory, "WasteViewSet", "waste"),
        ],
    )
    def test_delete_recascades_snapshots(self, tenant, factory, viewset_name, fk):
        from apps.commissioning.viewsets import documentation_viewsets

        instance = factory()
        movement = MovementShareArticleFactory(
            share_article=instance.share_article, **{fk: instance}
        )
        viewset_cls = getattr(documentation_viewsets, viewset_name)

        with patch(_CASCADE) as cascade:
            viewset_cls().perform_destroy(instance)

        cascade.assert_called_once()
        captured = list(cascade.call_args[0][0])
        assert any(m.id == movement.id for m in captured)


# ---------------------------------------------------------------------------
# List filters stop at the list route
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestListFiltersDoNotScopeDetailRoutes:
    """A detail route addresses one row by id. The week filters belong to the
    list, so a page that keeps its selectors in the query string (or a stale
    bookmark) must still reach — and be able to edit — the addressed row."""

    def test_forecast_detail_reaches_a_row_outside_the_list_window(
        self, api_client, tenant
    ):
        forecast = ForecastFactory(year=2026, delivery_week=15)
        resp = api_client.get(
            reverse("forecast-detail", kwargs={"pk": forecast.pk}),
            {"year": 2099, "delivery_week": 1},
        )
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["id"] == forecast.id

    def test_waste_detail_reaches_a_row_outside_the_list_window(
        self, api_client, tenant
    ):
        waste = WasteFactory(year=2026, delivery_week=15, day_number=1)
        resp = api_client.get(
            reverse("waste-detail", kwargs={"pk": waste.pk}),
            {"year": 2099, "delivery_week": 1, "day_number": 4},
        )
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["id"] == waste.id

    def test_waste_patch_is_not_refused_by_a_stale_list_filter(
        self, api_client, tenant
    ):
        waste = WasteFactory(year=2026, delivery_week=15, day_number=1, amount=3)
        resp = api_client.patch(
            reverse("waste-detail", kwargs={"pk": waste.pk}) + "?year=2099",
            {"amount": 7},
            format="json",
        )
        assert resp.status_code == status.HTTP_200_OK
        waste.refresh_from_db()
        assert waste.amount == 7


# ---------------------------------------------------------------------------
# Export date range: one rule, one code
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestExportDateRangeOrder:
    @pytest.mark.parametrize("url_name", ["purchase-export-csv", "harvest-export-csv"])
    def test_inverted_range_is_refused(self, api_client, tenant, url_name):
        """An end before the start can only produce an empty CSV, which reads
        as "no data" rather than "the dates are swapped"."""
        resp = api_client.get(
            reverse(url_name), {"date_from": "2026-02-01", "date_to": "2026-01-01"}
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "query.invalid_param"
        assert resp.data["field"] == "date_from"
        assert resp.data["details"] == {
            "date_from": "2026-02-01",
            "date_to": "2026-01-01",
        }

    def test_a_single_day_range_still_exports(self, api_client, tenant):
        resp = api_client.get(
            reverse("purchase-export-csv"),
            {"date_from": "2026-01-15", "date_to": "2026-01-15"},
        )
        assert resp.status_code == status.HTTP_200_OK


# ---------------------------------------------------------------------------
# bulk_set_as_expected — the posted amount is money-grade, not a JSON float
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestBulkSetAsExpectedAmountPrecision:
    """The amount lands on a 2dp ``DecimalField``, so it is taken as a Decimal:
    the value the office confirmed is the value stored."""

    def _harvest_payload(self, article, storage, amount):
        return {
            "selectedData": [
                {
                    "id": str(article.pk),
                    "year": 2026,
                    "delivery_week": 15,
                    "day_number": 1,
                    "theoretical_harvest_amount": amount,
                    "theoretical_harvest_unit": "KG",
                    "theoretical_harvest_size": "M",
                    "storage": storage.id,
                }
            ]
        }

    def test_harvest_amount_is_stored_exactly(self, api_client, tenant):
        from decimal import Decimal

        article = ShareArticleFactory()
        storage = StorageFactory(is_short_term_harvest_storage=True)

        resp = api_client.post(
            URL_HARVEST_BULK_SET_EXPECTED,
            self._harvest_payload(article, storage, 12.34),
            format="json",
        )

        assert resp.status_code == status.HTTP_204_NO_CONTENT
        harvest = Harvest.objects.get(share_article=article)
        assert harvest.amount == Decimal("12.34")

    def test_a_harvest_amount_finer_than_the_column_is_refused(
        self, api_client, tenant
    ):
        article = ShareArticleFactory()
        storage = StorageFactory(is_short_term_harvest_storage=True)

        resp = api_client.post(
            URL_HARVEST_BULK_SET_EXPECTED,
            self._harvest_payload(article, storage, 12.345),
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert not Harvest.objects.filter(share_article=article).exists()

    def test_purchase_amount_is_stored_exactly(self, api_client, tenant):
        from decimal import Decimal

        article = ShareArticleFactory(is_purchased=True)
        storage = StorageFactory(is_short_term_harvest_storage=True)

        resp = api_client.post(
            URL_PURCHASE_BULK_SET_EXPECTED,
            {
                "selectedData": [
                    {
                        "id": str(article.pk),
                        "year": 2026,
                        "delivery_week": 15,
                        "theoretical_purchase_amount": 7.05,
                        "theoretical_purchase_unit": "KG",
                        "theoretical_purchase_size": "M",
                        "storage": storage.id,
                    }
                ]
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_204_NO_CONTENT
        purchase = Purchase.objects.get(share_article=article)
        assert purchase.amount == Decimal("7.05")
