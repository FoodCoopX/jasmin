from collections import defaultdict
from datetime import date
from decimal import ROUND_HALF_UP, Decimal

from django.db.models import Count, Q, QuerySet
from django.db.models.functions import TruncMonth, TruncWeek, TruncYear
from django.utils import timezone

from apps.shared.money import CENT, round_money

from ..models import Member, ShareContent
from ..models.choices import UnitOptions, VegetableSizeOptions


def _compute_variation_averages(
    share_type_variation_ids, year, delivery_week, years_back=2
):
    """
    Calculate statistical averages of share content (in kg) for one or more
    variations in a single ShareContent scan. Every result key embeds its
    ``variation_{id}`` so multiple variations never collide.
    Returns averages at three levels:
    1. Station level: day_X_variation_Y_station_ABC (most granular)
    2. Tour level: day_X_variation_Y_tour_Z (aggregated from stations)
    3. Day level: day_X_variation_Y (aggregated from stations)

    Args:
        share_type_variation: ShareTypeVariation instance
        year: Current year
        delivery_week: Current week number
        years_back: Number of years to look back (default: 2)

    Returns:
        Dictionary with structure:
        {
            'day_abc_variation_xyz_station_123': 4.2,  # Station level average
            'day_abc_variation_xyz_tour_1': 8.3,  # Tour level average (sum of stations)
            'day_abc_variation_xyz': 12.5,  # Day level average (sum of stations)
        }
    """
    # Calculate date range
    start_year = year - years_back

    # Get all relevant planning records - ONLY include data BEFORE the current week
    queryset = ShareContent.objects.filter(
        share__share_type_variation_id__in=share_type_variation_ids,
        share__year__gte=start_year,
    ).filter(
        # Include all years before current year
        Q(share__year__lt=year)
        |
        # OR current year but before current week
        Q(share__year=year, share__delivery_week__lt=delivery_week)
    )

    # Structure to hold sums PER WEEK at station level
    # Key: (week, year, station_key) -> amount
    # Quantities (amount, kg-per-piece/bunch) are DecimalFields — keep the
    # aggregation in Decimal end-to-end and float only at the response
    # boundary (return), so intermediate sums don't accrue binary-fp drift.
    weekly_station_amounts = defaultdict(lambda: defaultdict(Decimal))

    # Track all unique station keys
    all_station_keys = set()

    # Track station to tour/day mappings - key is (station_id, day_id)
    station_day_to_tour = {}

    # Get all records with their related data
    records = queryset.select_related(
        "share_article",
        "share",
        "share__delivery_day",
        "delivery_station",
    ).values(
        "id",
        "unit",
        "size",
        "amount",
        "share_article__kg_per_piece_S",
        "share_article__kg_per_piece_M",
        "share_article__kg_per_piece_L",
        "share_article__kg_per_bunch_S",
        "share_article__kg_per_bunch_M",
        "share_article__kg_per_bunch_L",
        "share__delivery_day__id",
        "share__delivery_week",
        "share__year",
        "share__share_type_variation_id",
        "delivery_station__id",
    )

    processed_count = 0

    # Process each record - aggregate by week first
    for record_data in records:
        amount = record_data.get("amount") or 0

        variation_id = record_data["share__share_type_variation_id"]
        day_id = record_data["share__delivery_day__id"]
        station_id = record_data["delivery_station__id"]
        week = record_data["share__delivery_week"]
        record_year = record_data["share__year"]

        # Convert to kg. ``amount`` and the ``kg_per_*`` columns are all
        # DecimalFields — coerce via ``Decimal(str(...))`` (never
        # ``Decimal(float)``) and multiply in Decimal.
        amount_dec = Decimal(str(amount))
        kg_amount = Decimal("0")
        unit = record_data["unit"]
        size = record_data["size"]

        _kg_per_field = {
            (UnitOptions.PCS, VegetableSizeOptions.S): "share_article__kg_per_piece_S",
            (UnitOptions.PCS, VegetableSizeOptions.M): "share_article__kg_per_piece_M",
            (UnitOptions.PCS, VegetableSizeOptions.L): "share_article__kg_per_piece_L",
            (
                UnitOptions.BUNCH,
                VegetableSizeOptions.S,
            ): "share_article__kg_per_bunch_S",
            (
                UnitOptions.BUNCH,
                VegetableSizeOptions.M,
            ): "share_article__kg_per_bunch_M",
            (
                UnitOptions.BUNCH,
                VegetableSizeOptions.L,
            ): "share_article__kg_per_bunch_L",
        }.get((unit, size))

        if unit == UnitOptions.KG:
            kg_amount = amount_dec
        elif _kg_per_field is not None:
            kg_amount = amount_dec * Decimal(str(record_data[_kg_per_field] or 0))

        # Station level aggregation: day_X_variation_Y_station_Z
        station_key = f"day_{day_id}_variation_{variation_id}_station_{station_id}"
        week_key = (record_year, week)

        # Sum up amounts per week per station (even if kg_amount is 0)
        weekly_station_amounts[week_key][station_key] += kg_amount
        all_station_keys.add(station_key)
        processed_count += 1

    # Now calculate averages: sum of weekly totals / number of weeks
    station_totals = defaultdict(lambda: {"sum": Decimal("0"), "count": 0})

    for _week_key, station_amounts in weekly_station_amounts.items():
        for station_key, amount in station_amounts.items():
            station_totals[station_key]["sum"] += amount
            station_totals[station_key]["count"] += 1

    # Get tour information from DeliveryStationDay
    from ..models import DeliveryStationDay

    # Get all unique (station_id, day_id) combinations from station_totals
    station_day_combinations = set()
    for station_key in all_station_keys:
        # Parse: day_{day_id}_variation_{variation_id}_station_{station_id}
        parts = station_key.split("_")
        day_id = parts[1]
        station_id = parts[5]
        station_day_combinations.add((station_id, day_id))

    # Fetch tour numbers for all combinations in one query
    delivery_station_days = DeliveryStationDay.objects.filter(
        delivery_station_id__in=[
            station_id for station_id, _ in station_day_combinations
        ],
        delivery_day_id__in=[
            delivery_day_id for _, delivery_day_id in station_day_combinations
        ],
    ).values("delivery_station_id", "delivery_day_id", "tour_number")

    # Build the lookup dictionary
    for delivery_station_day in delivery_station_days:
        key = (
            delivery_station_day["delivery_station_id"],
            delivery_station_day["delivery_day_id"],
        )
        station_day_to_tour[key] = delivery_station_day["tour_number"]

    # Calculate station-level averages
    station_averages = {}
    for field_name, data in station_totals.items():
        if data["count"] > 0:
            # ROUND_HALF_UP (not builtin round()'s banker's rounding) to match
            # the platform's money/quantity rounding standard.
            avg = (data["sum"] / data["count"]).quantize(CENT, rounding=ROUND_HALF_UP)
            station_averages[field_name] = avg

    # Now aggregate from station level to tour and day levels
    tour_totals = defaultdict(Decimal)
    day_totals = defaultdict(Decimal)

    for station_key, avg_value in station_averages.items():
        # Parse the station key to get day_id, variation_id, station_id
        # Format: day_{day_id}_variation_{variation_id}_station_{station_id}
        parts = station_key.split("_")
        day_id = parts[1]
        var_id = parts[3]
        station_id = parts[5]

        # Aggregate to day level
        day_key = f"day_{day_id}_variation_{var_id}"
        day_totals[day_key] += avg_value

        # Aggregate to tour level if tour mapping exists
        lookup_key = (station_id, day_id)
        if lookup_key in station_day_to_tour:
            tour_number = station_day_to_tour[lookup_key]
            tour_key = f"day_{day_id}_variation_{var_id}_tour_{tour_number}"
            tour_totals[tour_key] += avg_value

    # Combine all averages
    averages = {}

    # Station level (already calculated)
    averages.update(station_averages)

    # Tour level (rounded)
    for tour_key, total in tour_totals.items():
        averages[tour_key] = round(total, 2)

    # Day level (rounded)
    for day_key, total in day_totals.items():
        averages[day_key] = round(total, 2)

    # Float only at the response boundary — the values were accumulated in
    # Decimal above; ``float`` here keeps the wire contract (JSON numbers)
    # without re-introducing intermediate drift.
    return {key: float(value) for key, value in averages.items()}


def calculate_historical_share_type_variation_averages(
    share_type_variation_ids, year, delivery_week, years_back=2
):
    """
    Calculate statistical averages for multiple variations at once.

    Args:
        share_type_variation_ids: List of ShareTypeVariation IDs
        year: Current year
        delivery_week: Current week number
        years_back: Number of years to look back (default: 2)

    Returns:
        Merged dictionary with all variation averages at all levels
    """
    # One ShareContent scan for every variation (no per-id point-lookup, no
    # per-variation scan). Unknown ids simply contribute no records.
    return _compute_variation_averages(
        list(share_type_variation_ids), year, delivery_week, years_back
    )


def calculate_member_dashboard_statistics() -> dict:
    """Snapshot ("today") of member + cooperative-share statistics.

    Cooperative-share figures are SUMS of ``amount_of_coop_shares`` (the number
    of shares), not row counts, each with its value: every share counted at the
    value it was subscribed at. "Live" excludes cancelled shares; the payback
    figure is the opposite — shares owed back to exited members.
    """
    from django.db.models import DecimalField, F, Sum
    from django.utils import timezone

    from ..models import CoopShare, Member

    members = Member.objects.all()
    total_members = members.count()
    trial_members = members.filter(is_trial=True).count()
    confirmed_members = members.filter(admin_confirmed=True).count()
    pending_members = members.filter(
        admin_confirmed=False, cancelled_at__isnull=True
    ).count()
    cancelled_members = members.filter(cancelled_at__isnull=False).count()

    # Average age of current (non-cancelled) members with a known birth date.
    today = timezone.localdate()
    birth_dates = members.filter(
        cancelled_at__isnull=True, birth_date__isnull=False
    ).values_list("birth_date", flat=True)
    ages = [(today - bd).days / 365.25 for bd in birth_dates]
    average_age = round(sum(ages) / len(ages), 1) if ages else 0.0

    worth = Sum(
        F("amount_of_coop_shares") * F("value_one_coop_share"),
        output_field=DecimalField(max_digits=14, decimal_places=2),
    )

    def _shares(qs) -> tuple[float, Decimal]:
        totals = qs.aggregate(shares=Sum("amount_of_coop_shares"), value=worth)
        return float(totals["shares"] or 0), round_money(totals["value"])

    def _payback_due() -> tuple[float, Decimal]:
        # Per member: a negative transfer row nets against the rows its shares
        # came from, and a member whose due rows sum to zero or below owes nothing.
        due_by_member = list(
            CoopShare.objects.filter(
                payback_due_date__isnull=False, paid_back_date__isnull=True
            )
            .values("member_id")
            .annotate(shares=Sum("amount_of_coop_shares"), value=worth)
        )
        shares = sum(max(row["shares"], 0) for row in due_by_member)
        value = sum(
            (max(row["value"], Decimal(0)) for row in due_by_member), Decimal(0)
        )
        return float(shares), round_money(value)

    live = CoopShare.objects.filter(cancelled_at__isnull=True)
    coop_share_figures = {
        "total_coop_shares": _shares(live),
        "confirmed_coop_shares": _shares(live.filter(admin_confirmed=True)),
        "pending_coop_shares": _shares(live.filter(admin_confirmed=False)),
        "paid_coop_shares": _shares(live.filter(paid_at__isnull=False)),
        "unpaid_coop_shares": _shares(live.filter(paid_at__isnull=True)),
        "payback_due_coop_shares": _payback_due(),
    }
    return {
        "total_members": total_members,
        "trial_members": trial_members,
        "confirmed_members": confirmed_members,
        "pending_members": pending_members,
        "cancelled_members": cancelled_members,
        "average_age": average_age,
        **{key: shares for key, (shares, _value) in coop_share_figures.items()},
        **{
            f"{key}_value": value
            for key, (_shares, value) in coop_share_figures.items()
        },
    }


def calculate_member_growth_statistics(
    *, period: str, year: int | None = None, start_date: date | None = None
) -> list[dict]:
    """Confirmed members per period: entries, exits and the member count at the
    end of each period.

    A member counts from their ``entry_date`` once admin-confirmed until their
    exit date (``cancelled_effective_at``). Trial members aren't members of the
    cooperative yet and are left out. An exit dated after today isn't counted
    yet, because the member still belongs to the cooperative.

    ``year`` (which wins over ``start_date``) or ``start_date`` limit the
    periods returned; ``total_members`` still starts from everyone who joined
    before the window and hadn't left before it.
    """
    # One entry per catalogued ``period`` value (MEMBER_GROWTH_PERIODS); the
    # query-param catalogue refuses anything else before it reaches here.
    trunc = {"month": TruncMonth, "week": TruncWeek, "year": TruncYear}[period]
    members = Member.objects.filter(
        admin_confirmed=True, is_trial=False, entry_date__isnull=False
    )
    exited = members.filter(
        cancelled_effective_at__isnull=False,
        cancelled_effective_at__lte=timezone.localdate(),
    )

    window_start: date | None = start_date
    window_end: date | None = None
    if year is not None:
        window_start, window_end = date(year, 1, 1), date(year, 12, 31)

    def count_per_period(queryset: QuerySet[Member], field: str) -> dict[date, int]:
        if window_start is not None:
            queryset = queryset.filter(**{f"{field}__gte": window_start})
        if window_end is not None:
            queryset = queryset.filter(**{f"{field}__lte": window_end})
        rows = (
            queryset.annotate(period=trunc(field))
            .values("period")
            .annotate(count=Count("id"))
            .order_by("period")
        )
        return {row["period"]: row["count"] for row in rows}

    entries_by_period = count_per_period(members, "entry_date")
    exits_by_period = count_per_period(exited, "cancelled_effective_at")

    total = 0
    if window_start is not None:
        total = (
            members.filter(entry_date__lt=window_start).count()
            - exited.filter(cancelled_effective_at__lt=window_start).count()
        )

    result: list[dict] = []
    for period_start in sorted(entries_by_period.keys() | exits_by_period.keys()):
        new_members = entries_by_period.get(period_start, 0)
        exited_members = exits_by_period.get(period_start, 0)
        total += new_members - exited_members
        result.append(
            {
                "period": period_start,
                "new_members": new_members,
                "exited_members": exited_members,
                "total_members": total,
            }
        )
    return result
