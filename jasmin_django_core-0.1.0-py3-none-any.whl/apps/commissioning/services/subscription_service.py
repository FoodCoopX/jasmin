from __future__ import annotations

import datetime
import logging
from datetime import timedelta
from typing import Any

from django.db import transaction
from django.db.models import Max
from django.utils import timezone
from isoweek import Week

from apps.shared.subscription_hooks import notify_subscription_changed
from apps.shared.tenants.models import RateLimitedAction
from apps.shared.tenants.rate_limits import enforce_action_quota

from ..errors import (
    CancellationAfterValidUntil,
    CancellationBeforeValidFrom,
    CancellationInPast,
    CancellationNotSunday,
    DeliveryStationOverCapacity,
    NoSundayRemainsInTerm,
    SubscriptionDeliveryStationDayOutOfRange,
    SubscriptionNotConfirmed,
)
from ..models import (
    DeliveryStationDay,
    Member,
    Share,
    ShareDelivery,
    SharesDeliveryDay,
    ShareTypeVariation,
    Subscription,
)
from .additional_share_policy import (
    assert_additional_share_has_base,
    assert_additional_share_has_base_on_update,
)
from .capacity_reservation_service import CapacityReservationService
from .delivery_cycle import filter_weeks_by_delivery_cycle
from .variation_capacity_service import VariationCapacityService
from .waiting_list_policy import assert_waiting_list_enabled

logger = logging.getLogger(__name__)


def _delivery_cycle_of(subscription: Subscription) -> str | None:
    """The ``ShareType.delivery_cycle`` governing this subscription's cadence,
    or ``None`` (→ weekly) when the share type sets none."""
    return subscription.share_type_variation.share_type.delivery_cycle


class SubscriptionService:
    """Creates subscriptions and their associated Share/ShareDelivery objects."""

    @staticmethod
    def assert_delivery_station_day_covers_subscription(
        *,
        delivery_station_day: DeliveryStationDay | None,
        valid_from: datetime.date | None,
        valid_until: datetime.date | None,
    ) -> None:
        """Validate that the chosen DeliveryStationDay's validity covers the
        subscription's validity (with chained successors when needed).

        Exposed as a staticmethod so both ``Subscription.clean()`` and any
        bulk path (``bulk_create`` / ``bulk_update``) can call the same
        logic.
        """
        if not delivery_station_day or not valid_from:
            return

        if delivery_station_day.valid_from > valid_from:
            raise SubscriptionDeliveryStationDayOutOfRange(
                f"Delivery station day starts ({delivery_station_day.valid_from}) "
                f"after subscription start ({valid_from})",
                field="default_delivery_station_day",
            )

        if (
            valid_until
            and delivery_station_day.valid_until
            and delivery_station_day.valid_until < valid_until
        ):
            # The default DSD ends before the subscription. Its successor chain
            # (same station + day_number) must cover the REST of the window
            # CONTIGUOUSLY through valid_until — proving merely that SOME later
            # DSD exists is not enough: a successor that starts weeks later (a
            # gap) or itself ends early leaves weeks with no valid station day.
            successors = DeliveryStationDay.objects.filter(
                delivery_station=delivery_station_day.delivery_station,
                delivery_day__day_number=delivery_station_day.delivery_day.day_number,
                valid_from__gt=delivery_station_day.valid_from,
            ).order_by("valid_from")
            covered_until = delivery_station_day.valid_until
            for successor in successors:
                if covered_until >= valid_until:
                    break
                if successor.valid_from > covered_until + timedelta(days=1):
                    break  # gap — coverage stays short, raised below
                if successor.valid_until is None:
                    covered_until = valid_until
                    break
                if successor.valid_until > covered_until:
                    covered_until = successor.valid_until
            if covered_until < valid_until:
                raise SubscriptionDeliveryStationDayOutOfRange(
                    f"Delivery station day coverage ends ({covered_until}) "
                    f"before subscription ends ({valid_until}): the successor "
                    "chain has a gap or ends too early.",
                    field="default_delivery_station_day",
                )

    @transaction.atomic
    def create_bare_subscription(self, validated_data: dict[str, Any]) -> Subscription:
        """Create the Subscription row only.

        Shares + ShareDeliveries are NOT created here. They are materialised
        on admin-confirmation (see ``materialize_confirmed_subscription``),
        because we don't want delivery / billing artefacts for subscriptions
        that may still be rejected.

        The draft DOES reserve its station-day capacity across the period so
        two drafts can't both claim the last slot — race-safe, and rolled back
        with the create if a week is full (``DeliveryStationOverCapacity``).

        Waiting-list entries (``on_waiting_list=True``) are the exception:
        they hold NO capacity — no reservation now, no deliveries until the
        office promotes them through the normal confirm flow (which re-checks
        capacity). They only get a PENDING status and a FIFO queue position.
        """
        # A "Zusatz" (additional share) may only be added when the member
        # already holds a base share covering its period.
        assert_additional_share_has_base(
            member_id=validated_data.get("member"),
            share_type_variation_id=validated_data.get("share_type_variation"),
            valid_from=validated_data.get("valid_from"),
            valid_until=validated_data.get("valid_until"),
        )
        subscription = self._create_subscription(validated_data)
        if subscription.on_waiting_list:
            self._enqueue_on_waiting_list(subscription)
        else:
            # Both capacity gates: farm-wide variation cap AND per-week
            # station-day slot. Either full raises (and rolls back the create) —
            # the frontend then re-submits the order as a waiting-list entry.
            VariationCapacityService.assert_capacity_available(subscription)
            CapacityReservationService.reserve_for_subscription(subscription)
        return subscription

    @staticmethod
    def _enqueue_on_waiting_list(subscription: Subscription) -> None:
        """Mark the draft as a PENDING waiting-list entry with the next FIFO
        position for its station-day. The position is informational — the
        office may promote out of order.

        Refuses when the tenant has the waiting list turned off — this is the
        single central choke point for both create and update flip-onto-list.
        """
        assert_waiting_list_enabled()
        highest = (
            Subscription.objects.filter(
                on_waiting_list=True,
                default_delivery_station_day_id=(
                    subscription.default_delivery_station_day_id
                ),
            )
            .exclude(pk=subscription.pk)
            .aggregate(highest=Max("waiting_list_position"))["highest"]
        )
        subscription.waiting_list_status = Subscription.WaitingListStatus.PENDING
        subscription.waiting_list_position = (highest or 0) + 1
        subscription.waiting_list_reason = (
            SubscriptionService._infer_waiting_list_reason(subscription)
        )
        subscription.save(
            update_fields=[
                "waiting_list_status",
                "waiting_list_position",
                "waiting_list_reason",
            ]
        )

    @staticmethod
    def _infer_waiting_list_reason(subscription: Subscription) -> str:
        """Why is this subscription being queued? Variation sold out takes
        precedence (cheap farm-wide check); else a full station-day; else it's a
        manual office decision. Purely informational for the office."""
        if VariationCapacityService.is_over_capacity(subscription):
            return Subscription.WaitingListReason.VARIATION_FULL
        try:
            # Read-only fullness probe (creates no reservations); raises when the
            # station-day is full for any week of the term.
            CapacityReservationService.assert_capacity_available_for_confirm(
                subscription
            )
        except DeliveryStationOverCapacity:
            return Subscription.WaitingListReason.DELIVERY_STATION_FULL
        return Subscription.WaitingListReason.MANUAL

    @transaction.atomic
    def update_draft_subscription(
        self,
        subscription: Subscription,
        validated_data: dict[str, Any],
    ) -> Subscription:
        """Apply `validated_data` to a draft (unconfirmed) subscription.

        No related-object cascade is needed because draft subscriptions
        don't yet have shares / deliveries / charges. Caller must ensure
        ``subscription.admin_confirmed is False``.
        """
        # Re-check the additional-share rule against the RESULTING
        # term/variation, but only when this edit actually moves one of them (a
        # draft edit could switch to a Zusatz or extend it past its base). An
        # edit elsewhere on the row leaves the rule's inputs untouched and must
        # stay possible even when they already violate it.
        assert_additional_share_has_base_on_update(subscription, validated_data)
        previous_station_day_id = subscription.default_delivery_station_day_id
        was_waiting_listed = subscription.on_waiting_list
        for field, value in validated_data.items():
            # ``member`` and ``share_type_variation`` are writable id STRINGS on
            # the serializer (CharField) — mirror ``_create_subscription`` and
            # assign them to the FK's ``_id`` attribute. Django rejects a raw pk
            # on the plain FK attribute ("must be a Member instance"); other FK
            # fields arrive as model instances and set directly.
            if field in ("member", "share_type_variation") and isinstance(value, str):
                setattr(subscription, f"{field}_id", value)
            else:
                setattr(subscription, field, value)
        subscription.save()
        if subscription.on_waiting_list:
            # WaitingListed drafts hold no capacity, so there is nothing to
            # re-reserve (reserving would 409 on the very full station the
            # entry is queued for).
            if not was_waiting_listed:
                # Draft flipped ONTO the list: drop its capacity holds (a
                # waiting_list entry holds nothing) and queue it.
                CapacityReservationService.release_for_subscription(subscription)
                self._enqueue_on_waiting_list(subscription)
            elif (
                subscription.default_delivery_station_day_id != previous_station_day_id
            ):
                # Moving the entry to another station-day re-queues it at the
                # end of that day's list.
                self._enqueue_on_waiting_list(subscription)
            return subscription
        if was_waiting_listed:
            # Leaving the list needs a real slot on BOTH axes: variation cap
            # + station-day slot. Either full raises (and rolls the flip back),
            # then clear the queue state.
            VariationCapacityService.assert_capacity_available(subscription)
            CapacityReservationService.reserve_for_subscription(subscription)
            subscription.waiting_list_status = (
                Subscription.WaitingListStatus.NOT_ON_LIST
            )
            subscription.waiting_list_position = None
            subscription.save(
                update_fields=["waiting_list_status", "waiting_list_position"]
            )
            return subscription
        # Re-check both caps against the (possibly changed) variation /
        # station-day / period, then re-reserve the station-day slot.
        VariationCapacityService.assert_capacity_available(subscription)
        CapacityReservationService.reserve_for_subscription(subscription)
        return subscription

    @transaction.atomic
    def materialize_confirmed_subscription(
        self,
        subscription: Subscription,
        *,
        actor: Any = None,
        earliest_monday: datetime.date | None = None,
    ) -> Subscription:
        """Create Shares + ShareDeliveries + ChargeSchedule for a freshly
        confirmed subscription.

        Idempotent for re-confirmation: existing ShareDeliveries for the sub
        are kept; only missing ones are created. Charge regeneration is
        delegated to ``ChargeScheduleService`` which itself protects locked
        (issued/paid/…) rows.

        ``actor`` (the confirming user) is recorded on the rate-limit ledger
        when this is a fresh confirmation.

        ``earliest_monday`` lets a fresh confirm materialise delivery weeks
        before the current week, back to that Monday (onboarding backfill; see
        ``_delivery_weeks_excluding_paused``). Only the Share / ShareDelivery
        writes use it: the capacity gates keep checking current and future
        weeks, so past occupancy the office can no longer change never blocks
        the confirm. Past deliveries are billed like any other delivery.
        """
        if not subscription.valid_until:
            logger.info(
                "Subscription %s missing valid_until; skipping materialise",
                subscription.pk,
            )
            return subscription
        # Fresh confirm = no ShareDeliveries yet. Re-confirm is idempotent on the
        # delivery side and skips the capacity gates (the sub already holds its
        # slots); the charge service does its own diffing.
        fresh_confirm = not ShareDelivery.objects.filter(
            subscription=subscription
        ).exists()

        # Authoritative production-cap gate FIRST — before the DSD gate below and
        # before the no-DSD early return. Two reasons:
        #   * it locks the ShareTypeVariation, and taking that lock BEFORE the
        #     station-day locks (matching create/update) keeps ONE canonical lock
        #     order, so a concurrent create + confirm can't deadlock (ABBA);
        #   * a DSD-less sub materialises no deliveries but still occupies the
        #     variation's farm-wide cap, so it must be gated too (else two
        #     DSD-less drafts can both confirm past the cap).
        if fresh_confirm:
            # Volume cap on fresh subscription confirmations (re-confirmation is
            # idempotent and doesn't consume quota). A confirmation creates
            # delivery + billing obligations; capping it bounds how fast those
            # can be minted. Placed alongside the capacity gate — both reject a
            # fresh confirm here — and the cap is platform-owned (public Tenant).
            enforce_action_quota(
                RateLimitedAction.SUBSCRIPTION_CONFIRMATION, actor=actor
            )
            VariationCapacityService.assert_capacity_available(subscription)

        if not subscription.default_delivery_station_day_id:
            logger.info(
                "Subscription %s has no default DSD; skipping materialise",
                subscription.pk,
            )
            return subscription

        if fresh_confirm:
            # DSD logistics gate (locks the station-day weeks) — taken AFTER the
            # variation lock per the order above. The draft reserved these slots,
            # but the hold may have lapsed (TTL) and been taken; re-check under a
            # row lock, raising ``DeliveryStationOverCapacity`` (and rolling back)
            # if a week is now full. Then drop our reservations — the real
            # deliveries hold the slots from here, so keeping them double-counts.
            CapacityReservationService.assert_capacity_available_for_confirm(
                subscription
            )
            shares = self._create_shares(subscription, earliest_monday=earliest_monday)
            self._create_share_deliveries(
                subscription, shares, earliest_monday=earliest_monday
            )
            CapacityReservationService.release_for_subscription(subscription)

        if subscription.on_waiting_list:
            # The office confirmed a waiting_listed subscription: the capacity
            # backstop above proved a slot is free now (waiting_list entries hold
            # no reservation, so the check counts everyone else). This IS the
            # promotion — leave the waiting list and record the confirmation.
            subscription.confirm_spot()

        notify_subscription_changed(subscription)
        return subscription

    @transaction.atomic
    def cancel_subscription(
        self,
        subscription: Subscription,
        *,
        cancelled_by: Any,
        effective_at: datetime.date,
        reason: str | None = None,
    ) -> Subscription:
        """End a confirmed subscription early (e.g. member died).

        - Sets CancellableMixin fields.
        - Truncates ``valid_until`` to ``effective_at`` so reports/queries see
          the new end immediately.
        - Deletes all future ShareDeliveries (those whose share's ISO date is
          strictly after ``effective_at``).
        - Drops PLANNED ChargeSchedule rows that start after ``effective_at``
          and re-runs the schedule for the truncated term.
        ISSUED/PAID/FAILED/WAIVED charges are NEVER touched.
        """
        if not subscription.admin_confirmed:
            raise SubscriptionNotConfirmed(
                "Only admin-confirmed subscriptions can be cancelled."
            )
        # Idempotency: a re-cancel is a no-op that preserves the ORIGINAL
        # cancellation audit stamp (cancelled_at / cancelled_by /
        # cancelled_effective_at) and the already-truncated valid_until, and must
        # NOT re-truncate the term, delete further deliveries, or re-fire the
        # payments hook. Mirrors cancel_member_with_coop_shares' cancelled_at guard.
        if subscription.cancelled_at is not None:
            return subscription
        # ``effective_at`` becomes the new ``valid_until`` further down,
        # and ``TimeBoundMixin`` requires ``valid_until`` to fall on a
        # Sunday (Python ``weekday() == 6``). Enforce that up front so
        # the office sees a clean error instead of a model-level
        # ValidationError later in the same transaction.
        if effective_at.weekday() != 6:
            raise CancellationNotSunday(
                "effective_at must fall on a Sunday — cancellations are "
                "aligned with the end-of-delivery-week boundary."
            )
        # Lower bound 1: never in the past. The earliest a cancellation
        # can take effect is the **next Sunday** (today if today IS
        # Sunday). Past dates are nonsense — there is no "we already
        # delivered last week" undo.
        from ..utils.iso_week_utils import next_sunday

        today = timezone.localdate()
        next_sunday_date = next_sunday(today)
        if effective_at < next_sunday_date:
            raise CancellationInPast(
                "effective_at must be on or after the next Sunday "
                f"({next_sunday_date.isoformat()}). Cancellation cannot "
                "take effect in the past."
            )
        # Lower bound 2: still respect valid_from for future-dated
        # subscriptions (rare — a subscription scheduled to start in two
        # months can't be cancelled before it has begun).
        if effective_at < subscription.valid_from:
            raise CancellationBeforeValidFrom(
                "effective_at must be on or after the subscription's valid_from."
            )
        # Upper bound — cancelling on or before the term's natural end is
        # the only meaningful case. Anything past ``valid_until`` is a
        # no-op (the subscription is already over) and would silently
        # *extend* the term via the ``valid_until = effective_at`` line
        # below. Refuse so the office can't accidentally do that.
        if (
            subscription.valid_until is not None
            and effective_at > subscription.valid_until
        ):
            raise CancellationAfterValidUntil(
                "effective_at must be on or before the subscription's valid_until."
            )
        # If the next-Sunday floor is already past the natural term end,
        # there is no Sunday left to cancel into. This matches the
        # frontend rule that hides the Cancel button on rows that are
        # already too close to their natural expiry.
        if (
            subscription.valid_until is not None
            and next_sunday_date > subscription.valid_until
        ):
            raise NoSundayRemainsInTerm(
                "There is no valid Sunday between today and the "
                "subscription's end date — let the term expire naturally."
            )

        subscription.cancelled_at = timezone.now()
        subscription.cancelled_by = cancelled_by
        subscription.cancelled_effective_at = effective_at
        # Truncate the term so future logic stops scheduling past this date.
        if subscription.valid_until is None or subscription.valid_until > effective_at:
            subscription.valid_until = effective_at
        subscription.save()

        # Drop future deliveries past the cancellation date, recompute the
        # affected shares, and re-plan charges (shared with the member-exit
        # path; locked ISSUED/PAID/FAILED/WAIVED charges are preserved).
        from .subscription_deliveries import truncate_future_deliveries

        truncate_future_deliveries(subscription, cutoff_date=effective_at)

        if reason:
            subscription.cancellation_reason = reason
            subscription.save(update_fields=["cancellation_reason"])

        return subscription

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @transaction.atomic
    def _create_subscription(self, validated_data: dict[str, Any]) -> Subscription:
        member_id = validated_data.pop("member")
        share_type_variation_id = validated_data.pop("share_type_variation")
        pickup_name = validated_data.pop("pickup_name", None)

        # Fetch both FKs in a single round-trip where possible
        member = Member.objects.get(id=member_id)
        share_type_variation = ShareTypeVariation.objects.get(
            id=share_type_variation_id
        )

        if pickup_name is not None:
            member.pickup_name = pickup_name
            member.save(update_fields=["pickup_name"])

        validated_data["member"] = member
        validated_data["share_type_variation"] = share_type_variation
        return Subscription.objects.create(**validated_data)

    @staticmethod
    def _get_delivery_weeks(
        start_date: datetime.date,
        end_date: datetime.date,
        delivery_day: int,
        delivery_cycle: str | None = None,
    ) -> list[tuple[int, int]]:
        """Return ``(year, isoweek)`` tuples between *start_date* and *end_date*
        that contain the given *delivery_day* (0=Monday … 5=Saturday).

        When *delivery_cycle* (``ShareType.delivery_cycle``) is given, the full
        weekly cadence is reduced to that cycle's delivery weeks: WEEKLY/blank →
        every week, ODD_WEEKS/EVEN_WEEKS → matching ISO-week parity, and the
        month-based cycles → every Nth week. See services/delivery_cycle.py.
        """
        # Convert delivery_day (0-5) to isoweekday (1-6)
        iso_delivery_day = delivery_day + 1

        current_date = start_date
        days_ahead = iso_delivery_day - current_date.isoweekday()
        if days_ahead < 0:
            days_ahead += 7
        current_date += timedelta(days=days_ahead)

        delivery_weeks: list[tuple[int, int]] = []
        while current_date <= end_date:
            year, week, _ = current_date.isocalendar()
            delivery_weeks.append((year, week))
            current_date += timedelta(days=7)

        # Reduce the full weekly cadence to the configured cycle's delivery weeks
        # (WEEKLY keeps all; ODD/EVEN by parity; ALL_THREE/ALL_FOUR by stride).
        return filter_weeks_by_delivery_cycle(delivery_weeks, delivery_cycle)

    @staticmethod
    def _delivery_weeks_excluding_paused(
        subscription: Subscription,
        *,
        earliest_monday: datetime.date | None = None,
    ) -> list[tuple[int, int]]:
        """The subscription's ``(year, isoweek)`` delivery weeks with
        DeliveryExceptionPeriod ("Lieferpause") weeks removed — the week list
        that Share / ShareDelivery materialisation AND the capacity paths
        iterate.

        A paused week materialises no Share/ShareDelivery, so it consumes no
        station-day slot; excluding it here keeps capacity reserve/count and the
        materialisation write on the SAME week set — else the capacity paths
        would reserve/count phantom occupancy for weeks that are never delivered,
        and resync's restore would re-create a still-paused week. Returns ``[]``
        when the subscription has no delivery weeks (or every week is paused).

        ``earliest_monday`` moves the past-week floor back to that date's ISO
        week (never later than the current week, never before ``valid_from``).
        It is the one exception to the shared week set: only the onboarding
        backfill of a fresh confirm passes it, so those past weeks are
        materialised while capacity checks, reservations and pause resync keep
        the default set of current and future weeks.
        """
        day_number = subscription.default_delivery_station_day.delivery_day.day_number
        year_weeks = SubscriptionService._get_delivery_weeks(
            subscription.valid_from,
            subscription.valid_until,
            day_number,
            _delivery_cycle_of(subscription),
        )
        if not year_weeks:
            return []

        # By default, never materialise (or reserve capacity for) delivery weeks
        # already in the PAST. In normal use ``valid_from`` is a future Monday,
        # so every week is current/future and this is a no-op. It only bites when
        # confirming a subscription whose ``valid_from`` is historical (e.g. an
        # import of an existing member's subscription).
        #
        # Granularity is the ISO WEEK: the current week is kept even if its
        # delivery day already passed this week (a box "for this week"), and only
        # weeks before the floor are dropped. Because the variation cap gate is
        # clamped the same way (see ``VariationCapacityService``), materialisation
        # and all capacity paths share this week set, except for the onboarding
        # backfill (``earliest_monday``), which only materialisation uses.
        # Charge impact: EXACT billing is delivery-driven, so it bills exactly
        # the materialised weeks; SMOOTHED still enumerates its own periods over
        # the full term (dormant PLANNED past-period rows) — see apps.payments.
        current_monday = Week.withdate(timezone.localdate()).monday()
        floor = (
            current_monday
            if earliest_monday is None
            else min(Week.withdate(earliest_monday).monday(), current_monday)
        )
        year_weeks = [
            year_week
            for year_week in year_weeks
            if Week(year_week[0], year_week[1]).monday() >= floor
        ]
        if not year_weeks:
            return []

        from .delivery_exceptions import paused_weeks_for_variation

        paused = paused_weeks_for_variation(
            subscription.share_type_variation_id, year_weeks
        )
        if paused:
            year_weeks = [
                year_week for year_week in year_weeks if year_week not in paused
            ]
        return year_weeks

    @staticmethod
    def _active_chain_by_week(
        model: type,
        filters: dict[str, Any],
        weeks: list[tuple[int, int]],
        *,
        select_related: tuple[str, ...] = (),
    ) -> dict[tuple[int, int], Any]:
        """Resolve, for each ``(year, isoweek)`` in *weeks*, the time-bounded
        *model* row active on that week's Monday — or ``None`` when the chain has
        a gap that week.

        *filters* pin the chain (delivery_station + day_number for a
        DeliveryStationDay; day_number for a SharesDeliveryDay). This helper adds
        the shared date-window narrowing, the ``-valid_from`` tie-break (latest
        start wins on overlap) and the per-week ``is_active_at`` scan — built on
        ``TimeBoundMixin.is_active_at`` so materialisation and capacity resolve
        the SAME row per week. ``.objects`` (not ``.current``) matches the sibling
        resolvers so historical rows for PAST weeks aren't pre-filtered out; the
        date range + ``is_active_at`` do the validity scoping.
        """
        mondays = {
            year_week: Week(year_week[0], year_week[1]).monday() for year_week in weeks
        }
        queryset = model.objects.filter(**filters)
        if select_related:
            queryset = queryset.select_related(*select_related)
        candidates = list(
            queryset.filter(valid_from__lte=max(mondays.values()) + timedelta(days=6))
            .exclude(valid_until__lt=min(mondays.values()))
            .order_by("-valid_from")
        )

        def _active(active_at: datetime.date):
            for candidate in candidates:
                if candidate.is_active_at(active_at):
                    return candidate
            return None

        return {year_week: _active(mondays[year_week]) for year_week in weeks}

    @staticmethod
    def resolve_station_days_by_week(
        subscription: Subscription,
        *,
        earliest_monday: datetime.date | None = None,
    ) -> dict[tuple[int, int], DeliveryStationDay]:
        """Map each delivery week of *subscription* to the DeliveryStationDay
        that will actually hold its ShareDelivery: the default DSD when it is
        open-ended, else the per-week successor resolved from the station's
        time-bounded chain (mirrors the resolution in
        ``_create_share_deliveries``). Empty when the subscription consumes no
        station-day (no default DSD or no ``valid_until``).

        Capacity enforcement uses this so it reserves/checks the SAME DSD that
        materialization will write to, not just the default DSD. Capacity
        callers never pass ``earliest_monday``; the onboarding backfill passes
        it so past weeks resolve to the station day active at the time (see
        ``_delivery_weeks_excluding_paused``).
        """
        default_delivery_station_day = subscription.default_delivery_station_day
        if not default_delivery_station_day or not subscription.valid_until:
            return {}

        year_weeks = SubscriptionService._delivery_weeks_excluding_paused(
            subscription, earliest_monday=earliest_monday
        )
        if not year_weeks:
            return {}

        # Open-ended default DSD covers every week — the common fast path.
        if default_delivery_station_day.valid_until is None:
            return {year_week: default_delivery_station_day for year_week in year_weeks}

        # Time-bounded default: resolve the per-week successor from the station's
        # chain, falling back to the default DSD when no successor covers a week
        # (mirrors _create_share_deliveries, which warns + materializes onto it).
        active_by_week = SubscriptionService._active_chain_by_week(
            DeliveryStationDay,
            {
                "delivery_station": default_delivery_station_day.delivery_station,
                "delivery_day__day_number": (
                    default_delivery_station_day.delivery_day.day_number
                ),
            },
            year_weeks,
            select_related=("delivery_day",),
        )
        return {
            year_week: (active_by_week[year_week] or default_delivery_station_day)
            for year_week in year_weeks
        }

    @transaction.atomic
    def _create_shares(
        self,
        subscription: Subscription,
        *,
        earliest_monday: datetime.date | None = None,
    ) -> list[Share]:
        delivery_day = subscription.default_delivery_station_day.delivery_day
        share_type_variation = subscription.share_type_variation

        # Same week set resolve_station_days_by_week uses in
        # _create_share_deliveries (the same ``earliest_monday``) —
        # DeliveryExceptionPeriod ("Lieferpause") weeks excluded, so no Share /
        # ShareDelivery (and, billing being delivery-driven, no charge) is
        # materialised for a paused week.
        delivery_weeks = self._delivery_weeks_excluding_paused(
            subscription, earliest_monday=earliest_monday
        )
        if not delivery_weeks:
            return []

        # Pre-fetch existing shares to avoid N+1 get_or_create calls
        existing_shares = {
            (s.year, s.delivery_week, s.delivery_day_id): s
            for s in Share.objects.filter(
                year__in={y for y, _ in delivery_weeks},
                delivery_week__in={w for _, w in delivery_weeks},
                share_type_variation=share_type_variation,
            ).select_related("delivery_day")
        }

        delivery_day_stays_the_same = delivery_day.valid_until is None

        if delivery_day_stays_the_same:
            return self._create_shares_static_day(
                delivery_weeks, delivery_day, share_type_variation, existing_shares
            )
        return self._create_shares_dynamic_day(
            delivery_weeks,
            delivery_day,
            subscription,
            share_type_variation,
            existing_shares,
        )

    def _create_shares_static_day(
        self,
        delivery_weeks: list[tuple[int, int]],
        delivery_day: SharesDeliveryDay,
        share_type_variation: ShareTypeVariation,
        existing_shares: dict[tuple[int, int, str], Share],
    ) -> list[Share]:
        shares: list[Share] = []
        for year, week in delivery_weeks:
            key = (year, week, delivery_day.id)
            if key in existing_shares:
                shares.append(existing_shares[key])
            else:
                share, _ = Share.get_or_create_for_delivery(
                    year=year,
                    delivery_week=week,
                    delivery_day=delivery_day,
                    share_type_variation=share_type_variation,
                )
                shares.append(share)
        return shares

    def _create_shares_dynamic_day(
        self,
        delivery_weeks: list[tuple[int, int]],
        delivery_day: SharesDeliveryDay,
        subscription: Subscription,
        share_type_variation: ShareTypeVariation,
        existing_shares: dict[tuple[int, int, str], Share],
    ) -> list[Share]:
        day_number = delivery_day.day_number

        # Resolve the active SharesDeliveryDay per week (shared batch-fetch +
        # is_active_at scan). No select_related — SharesDeliveryDay has no chained
        # FK to preload here.
        active_day_by_week = self._active_chain_by_week(
            SharesDeliveryDay, {"day_number": day_number}, delivery_weeks
        )

        shares: list[Share] = []
        for year, week in delivery_weeks:
            current_delivery_day = active_day_by_week[(year, week)]
            if current_delivery_day is None:
                logger.error(
                    "No active delivery day for day_number=%s at %s",
                    day_number,
                    Week(year, week).monday(),
                )
                continue

            key = (year, week, current_delivery_day.id)
            if key in existing_shares:
                shares.append(existing_shares[key])
            else:
                share, _ = Share.get_or_create_for_delivery(
                    year=year,
                    delivery_week=week,
                    delivery_day=current_delivery_day,
                    share_type_variation=share_type_variation,
                )
                shares.append(share)
        return shares

    @staticmethod
    @transaction.atomic
    def _create_share_deliveries(
        subscription: Subscription,
        shares: list[Share],
        *,
        earliest_monday: datetime.date | None = None,
    ) -> list[ShareDelivery]:
        default_delivery_station_day = subscription.default_delivery_station_day

        # bulk_create() below bypasses ShareDelivery.save(), which is the only
        # place is_opted_in gets stamped from the variation's default_optin_state.
        # Without this, an on-by-default opt-in variation would be born opted-OUT
        # — silently suppressing both its billing and its production demand.
        variation = subscription.share_type_variation
        is_opted_in = bool(variation.requires_optin and variation.default_optin_state)

        # Single source of truth for the (year, week) -> DSD mapping: the same
        # resolver the capacity paths reserve/check against, so materialisation
        # writes to the SAME station-day capacity reserved. It handles the
        # open-ended default (every week on the default) and the time-bounded
        # default (per-week successor, falling back to the default) itself. It
        # must get the same ``earliest_monday`` as ``_create_shares``, or the
        # backfilled past weeks are missing from the map. Any share whose week
        # the resolver doesn't cover (defensive; e.g. a paused week) lands on the
        # default DSD with a logged warning.
        delivery_station_day_by_week = SubscriptionService.resolve_station_days_by_week(
            subscription, earliest_monday=earliest_monday
        )

        share_deliveries: list[ShareDelivery] = []
        for share in shares:
            resolved_delivery_station_day = delivery_station_day_by_week.get(
                (share.year, share.delivery_week)
            )
            if resolved_delivery_station_day is None:
                logger.error(
                    "No active DSD for station=%s day_number=%s at %s",
                    default_delivery_station_day.delivery_station,
                    default_delivery_station_day.delivery_day.day_number,
                    Week(share.year, share.delivery_week).monday(),
                )
                resolved_delivery_station_day = default_delivery_station_day  # fallback
            share_deliveries.append(
                ShareDelivery(
                    subscription=subscription,
                    share=share,
                    delivery_station_day=resolved_delivery_station_day,
                    joker_taken=False,
                    is_opted_in=is_opted_in,
                )
            )

        return SubscriptionService._bulk_create_deliveries_and_recompute(
            share_deliveries, shares, subscription
        )

    @staticmethod
    def _bulk_create_deliveries_and_recompute(
        share_deliveries: list[ShareDelivery],
        shares: list[Share],
        subscription: Subscription,
    ) -> list[ShareDelivery]:
        """bulk_create the ShareDeliveries, then recompute the affected shares.

        The recompute is capacity/billing-sensitive and runs inside the caller's
        @transaction.atomic: a failure re-raises so the just-created deliveries
        roll back, with the subscription id the bare recompute exception lacks.
        """
        ShareDelivery.objects.bulk_create(share_deliveries)
        from .recompute import recompute_shares

        try:
            recompute_shares(s.id for s in shares)
        except Exception:
            # Re-raise so the outer @transaction.atomic still rolls the
            # just-created deliveries back; add the subscription identifier
            # the bare recompute exception lacks.
            logger.exception(
                "recompute failed for subscription=%s after creating share deliveries",
                subscription.pk,
            )
            raise
        return share_deliveries
