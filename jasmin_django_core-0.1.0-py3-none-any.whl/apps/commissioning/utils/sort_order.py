from __future__ import annotations

from collections.abc import Callable
from typing import Any

from django.db.models import Case, IntegerField, TextChoices, Value, When

from ..models.choices import (
    ShareTypeVariationSizeOptions,
    UnitOptions,
    VegetableSizeOptions,
)

# Units and sizes outside the known choices sort after every known one.
UNKNOWN_SORT_ORDER = 999


def size_order_annotation():
    """Build a Case/When annotation that maps ShareTypeVariationSizeOptions to their enum index."""
    whens = [
        When(size=choice[0], then=Value(idx))
        for idx, choice in enumerate(ShareTypeVariationSizeOptions.choices)
    ]
    return Case(*whens, default=Value(UNKNOWN_SORT_ORDER), output_field=IntegerField())


def create_share_article_sorter(
    unit_choices: type[TextChoices] | None = None,
    size_choices: type[TextChoices] | None = None,
) -> Callable[[dict[str, Any]], tuple[str, int, int]]:
    """
    Create a sorting function for share articles.

    Args:
        unit_choices: Django TextChoices class for units (defaults to UnitOptions)
        size_choices: Django TextChoices class for sizes (defaults to VegetableSizeOptions)

    Returns:
        A function that can be used as a key for sorting

    Example:
        >>> sorter = create_share_article_sorter()
        >>> data = [{'share_article_name': 'Tomato', 'unit': 'kg', 'size': 'L'}]
        >>> sorted(data, key=sorter)
    """
    # Use defaults if not provided
    unit_choices = unit_choices or UnitOptions
    size_choices = size_choices or VegetableSizeOptions

    # Create ordering mappings (1-indexed for clarity)
    unit_order = {choice[0]: idx for idx, choice in enumerate(unit_choices.choices, 1)}
    size_order = {choice[0]: idx for idx, choice in enumerate(size_choices.choices, 1)}

    def get_sort_key(item: dict[str, Any]) -> tuple[str, int, int]:
        """
        Custom sorting function for share articles.

        Sorts by: share_article_name -> unit -> size
        """
        share_article_name = item.get("share_article_name") or ""
        unit = item.get("unit") or ""
        size = item.get("size") or ""

        # Get numeric order for unit and size
        unit_order_value = unit_order.get(unit, UNKNOWN_SORT_ORDER)
        size_order_value = size_order.get(size, UNKNOWN_SORT_ORDER)

        return (share_article_name, unit_order_value, size_order_value)

    return get_sort_key


def sort_share_articles(
    data: list[dict[str, Any]],
    unit_choices: type[TextChoices] | None = None,
    size_choices: type[TextChoices] | None = None,
) -> list[dict[str, Any]]:
    """
    Sort a list of share article data.

    Args:
        data: List of dictionaries containing share article data
        unit_choices: Django TextChoices class for units (defaults to UnitOptions)
        size_choices: Django TextChoices class for sizes (defaults to VegetableSizeOptions)

    Returns:
        Sorted list of share articles

    Example:
        >>> articles = [
        ...     {'share_article_name': 'Tomato', 'unit': 'kg', 'size': 'L'},
        ...     {'share_article_name': 'Apple', 'unit': 'pieces', 'size': 'M'}
        ... ]
        >>> sorted_articles = sort_share_articles(articles)
    """
    sorter = create_share_article_sorter(unit_choices, size_choices)
    return sorted(data, key=sorter)
