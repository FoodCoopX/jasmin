"""HTTP layer for the CSV data-list upload feature.

Pure HTTP plumbing — the import logic lives in
:mod:`apps.commissioning.services.data_import`.

Endpoint: ``POST /api/commissioning/data_import/``

Request (multipart/form-data):
    model_name  registry key naming the target model
                (``share_article``, ``crate``, ``member``,
                ``delivery_station``, ``reseller``)
    file        the filled-in CSV (template format: row 0 titles,
                row 1 field names, row 2 type hints; two-row hand-rolled
                CSVs also work)
    fixed_values  optional JSON object of field values set on every row,
                over the file's own cells

Response (200): see :class:`DataImportResult` for the shape.
Response (400): unknown ``model_name``, undecodable file, missing data row.
"""

from __future__ import annotations

import json
import os
from typing import Any

from drf_spectacular.utils import extend_schema
from rest_framework import status
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import RequiresStepUp
from apps.authz.permissions import APIViewRolePermissionsMixin, IsOffice
from apps.shared.query_params import parse_body_bool
from apps.shared.request_utils import body
from core.serializers import ErrorResponseSerializer

from ..errors import DataImportInvalid, RequiredFieldMissing
from ..serializers.imports_serializer import DataImportResponseSerializer
from ..services.data_import import (
    BANK_DATA_IMPORT_COLUMNS,
    MODEL_IMPORT_REGISTRY,
    ImportOptions,
    bank_data_columns_in_csv,
    get_serializer_for_model,
    import_rows_from_csv,
)
from ..services.onboarding_policy import onboarding_mode_enabled

# Cap the upload before a byte of it is read. The import's row cap bounds
# PARSING, not memory: by the time it applies, the whole file plus its decoded
# copy are resident. A 5000-row data list is well under a megabyte, so this
# only ever catches a runaway export (nginx's 50 MB body limit is far too
# coarse for a worker handling several uploads at once).
_MAX_UPLOAD_BYTES = 10 * 1024 * 1024
_UPLOAD_TOO_LARGE = (
    f"file exceeds the {_MAX_UPLOAD_BYTES // (1024 * 1024)} MB upload limit — "
    "split the list into smaller files."
)


class DataImportView(APIViewRolePermissionsMixin, APIView):
    """POST a CSV → run it through the registered serializer row by row."""

    read_permission = IsOffice
    write_permission = IsOffice
    parser_classes = [MultiPartParser, FormParser]

    @extend_schema(
        summary="Bulk import data list rows from CSV",
        description=(
            "Upload a filled-in CSV template. The endpoint reads row 1 "
            "(``dataIndex`` field names) as the schema, validates each "
            "data row through the registered serializer, and continues "
            "past any individual row failure."
        ),
        request={
            "multipart/form-data": {
                "type": "object",
                "properties": {
                    "model_name": {
                        "type": "string",
                        "description": (
                            "Registry key for the target model. Allowed: "
                            + ", ".join(
                                f"``{k}``" for k in sorted(MODEL_IMPORT_REGISTRY)
                            )
                        ),
                    },
                    "file": {"type": "string", "format": "binary"},
                    "dry_run": {
                        "type": "boolean",
                        "description": (
                            "Validate every row (including FK resolution) "
                            "without persisting anything — the preview pass for "
                            "many-FK imports like subscriptions."
                        ),
                    },
                    "fixed_values": {
                        "type": "string",
                        "description": (
                            "A JSON object of field values set on every row, "
                            "over the file's own cells, e.g. "
                            '``{"is_extra": true, "default_movement_unit": '
                            '"PCS"}`` for extra articles. Only fields the '
                            "import can write are accepted."
                        ),
                    },
                },
                "required": ["model_name", "file"],
            }
        },
        responses={
            200: DataImportResponseSerializer,
            400: ErrorResponseSerializer,
        },
    )
    def post(self, request: Request) -> Response:
        raw_model_name = body(request).get("model_name")
        if raw_model_name is not None and not isinstance(raw_model_name, str):
            # A ``model_name`` sent as a file part rather than a form field
            # arrives as an UploadedFile. Refusing it as the missing field
            # keeps it away from ``.strip()``, which would answer with a 500.
            raise RequiredFieldMissing("model_name is required", field="model_name")
        model_name = (raw_model_name or "").strip().lower()
        upload = request.FILES.get("file")

        if not model_name:
            raise RequiredFieldMissing("model_name is required", field="model_name")
        if upload is None:
            raise RequiredFieldMissing("file is required", field="file")

        # Reject non-CSV uploads early. The .csv extension isn't a
        # security boundary (an attacker could rename anything), but it
        # cuts off the accidental "I uploaded the wrong file" case and
        # documents the contract.
        if os.path.splitext(upload.name)[1].lower() != ".csv":
            raise DataImportInvalid("file must be a .csv", field="file")

        # Accepts a boolean or true/false, 1/0, yes/no, on/off (the form part
        # arrives as a string); absent means a real run.
        dry_run = parse_body_bool(body(request), "dry_run")
        fixed_values = _parse_fixed_values(body(request).get("fixed_values"))

        # ``size`` is what the multipart parser recorded; the bounded read is
        # what actually holds, for an upload whose size is unknown or wrong.
        if (upload.size or 0) > _MAX_UPLOAD_BYTES:
            raise DataImportInvalid(_UPLOAD_TOO_LARGE, field="file")
        file_bytes = upload.read(_MAX_UPLOAD_BYTES + 1)
        if len(file_bytes) > _MAX_UPLOAD_BYTES:
            raise DataImportInvalid(_UPLOAD_TOO_LARGE, field="file")

        if not dry_run:
            self._require_step_up_for_bank_columns(
                request, model_name, file_bytes, fixed_values
            )

        # ``import_rows_from_csv`` raises ``DataImportInvalid`` directly for
        # whole-file problems; the global handler renders it. Per-row failures
        # come back on ``result`` and never raise.
        result = import_rows_from_csv(
            model_name,
            file_bytes,
            importing_user=request.user,
            dry_run=dry_run,
            options=ImportOptions(
                # In onboarding mode a linked member stays unconfirmed so the
                # office can confirm it with its historical date and without
                # an email.
                confirm_active_users=not onboarding_mode_enabled(),
                fixed_values=fixed_values,
            ),
        )

        return Response(result.to_dict(), status=status.HTTP_200_OK)

    def _require_step_up_for_bank_columns(
        self,
        request: Request,
        model_name: str,
        file_bytes: bytes,
        fixed_values: dict[str, Any],
    ) -> None:
        """Refuse a real import that writes bank data without fresh step-up auth.

        IBANs, account holders and SEPA mandates need a fresh step-up claim on
        every interactive write, so a bulk upload must not be the way around
        that. Only a real import is gated: a dry run persists nothing, so the
        office can still preview a bank-data file without re-authenticating.
        """
        # An unknown model gets its 400 before any step-up prompt.
        get_serializer_for_model(model_name)
        # A bank field set through ``fixed_values`` writes bank data as surely
        # as a column in the file.
        bank_columns = bank_data_columns_in_csv(file_bytes)
        if not bank_columns and not BANK_DATA_IMPORT_COLUMNS.intersection(fixed_values):
            return
        # Raises ``StepUpRequired`` (403 ``auth.step_up_required``, the code the
        # frontend interceptor answers with the step-up modal and a retry) when
        # the access token carries no fresh step-up claim.
        RequiresStepUp().has_permission(request, self)


def _parse_fixed_values(raw: object) -> dict[str, Any]:
    """The ``fixed_values`` form field as a dict; absent or blank is none."""
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return {}
    try:
        parsed = json.loads(raw) if isinstance(raw, str) else None
    except ValueError:
        parsed = None
    if not isinstance(parsed, dict):
        raise DataImportInvalid(
            "fixed_values must be a JSON object", field="fixed_values"
        )
    return parsed
