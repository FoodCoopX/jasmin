from rest_framework import serializers

from ..models import (
    TheoreticalCleanAmount,
    TheoreticalHarvest,
    TheoreticalPurchase,
    TheoreticalWashAmount,
)
from .serializers_mixin import AUDIT_READONLY_FIELDS, NameFieldMixin

# The line a theoretical row was derived from. The services that create these
# rows own the movements and snapshots derived alongside them, so repointing one
# through a generic PATCH would leave that derived state on the old parent.
PROVENANCE_READONLY_FIELDS = ("share_content", "order_content")


class TheoreticalHarvestSerializer(NameFieldMixin, serializers.ModelSerializer):
    NAME_FIELDS = ["share_article_name"]

    class Meta:
        model = TheoreticalHarvest
        fields = "__all__"
        # ``created_by`` is stamped by ``_TheoreticalBaseViewSet.perform_create``.
        read_only_fields = (
            *AUDIT_READONLY_FIELDS,
            *PROVENANCE_READONLY_FIELDS,
            # A harvest row also records the forecast it was planned from.
            "forecast",
        )


class TheoreticalCleanAmountSerializer(NameFieldMixin, serializers.ModelSerializer):
    NAME_FIELDS = ["share_article_name"]

    class Meta:
        model = TheoreticalCleanAmount
        fields = "__all__"
        # ``created_by`` is stamped by ``_TheoreticalBaseViewSet.perform_create``.
        read_only_fields = (*AUDIT_READONLY_FIELDS, *PROVENANCE_READONLY_FIELDS)


class TheoreticalPurchaseSerializer(NameFieldMixin, serializers.ModelSerializer):
    NAME_FIELDS = ["share_article_name"]

    class Meta:
        model = TheoreticalPurchase
        fields = "__all__"
        # ``created_by`` is stamped by ``_TheoreticalBaseViewSet.perform_create``.
        read_only_fields = (*AUDIT_READONLY_FIELDS, *PROVENANCE_READONLY_FIELDS)


class TheoreticalWashAmountSerializer(NameFieldMixin, serializers.ModelSerializer):
    NAME_FIELDS = ["share_article_name"]

    class Meta:
        model = TheoreticalWashAmount
        fields = "__all__"
        # ``created_by`` is stamped by ``_TheoreticalBaseViewSet.perform_create``.
        read_only_fields = (*AUDIT_READONLY_FIELDS, *PROVENANCE_READONLY_FIELDS)


class StockComparisonSerializer(serializers.Serializer):
    """Single row in the theoretical-vs-actual stock comparison view."""

    id = serializers.CharField(help_text="Composite ID")
    share_article = serializers.CharField()
    share_article_name = serializers.CharField()
    unit = serializers.CharField()
    size = serializers.CharField()
    storage_id = serializers.CharField(allow_null=True)
    theoretical_current_stock = serializers.FloatField(allow_null=True)
    amount = serializers.FloatField(
        allow_null=True, help_text="Absolute counted value (or null if not yet counted)"
    )
    is_finalized = serializers.BooleanField(allow_null=True)
    washed = serializers.BooleanField(allow_null=True)
    cleaned = serializers.BooleanField(allow_null=True)
    for_shares = serializers.BooleanField(allow_null=True)
    for_resellers = serializers.BooleanField(allow_null=True)
    for_markets = serializers.BooleanField(allow_null=True)
    note = serializers.CharField(allow_null=True, allow_blank=True, required=False)


class InventoryMetadataSerializer(serializers.Serializer):
    """The flag/note half of an INVENTORY movement's PATCH body.

    ``amount`` is parsed separately by the view, which answers a malformed one
    with the stable ``stock.amount_*`` codes; everything else is validated
    here so a bad flag or an over-long note is refused as a field error
    instead of reaching ``full_clean()`` inside ``save()``.
    """

    for_shares = serializers.BooleanField(required=False)
    for_resellers = serializers.BooleanField(required=False)
    for_markets = serializers.BooleanField(required=False)
    washed = serializers.BooleanField(required=False)
    cleaned = serializers.BooleanField(required=False)
    note = serializers.CharField(
        required=False, allow_blank=True, allow_null=True, max_length=500
    )


class InventoryEntrySerializer(serializers.Serializer):
    """Response serializer for PATCH on an INVENTORY movement."""

    id = serializers.CharField(help_text="Composite ID")
    share_article = serializers.CharField()
    share_article_name = serializers.CharField()
    unit = serializers.CharField()
    size = serializers.CharField()
    storage_id = serializers.CharField(allow_null=True)
    amount = serializers.FloatField(allow_null=True, help_text="Absolute counted value")
    for_shares = serializers.BooleanField()
    for_resellers = serializers.BooleanField()
    for_markets = serializers.BooleanField()
    washed = serializers.BooleanField()
    cleaned = serializers.BooleanField()
    note = serializers.CharField(allow_null=True)


class StorageLoggingEntrySerializer(serializers.Serializer):
    """
    Unified serializer for all movement entries in the stock ledger,
    including INVENTORY movements (physical stock counts).

    Fields that are null indicate they're not applicable for that entry type:
    - Non-INVENTORY movements: washed, cleaned, for_* and is_finalized are None
    - INVENTORY movements: cultivation_origin is None
    """

    id = serializers.CharField(help_text="Entry ID (mv_* for Movement)")
    date = serializers.DateTimeField()
    type = serializers.CharField(
        help_text="INVENTORY, HARVEST, SHARECONTENT, ORDERCONTENT, etc."
    )
    share_article = serializers.CharField()
    share_article_name = serializers.CharField()
    amount = serializers.FloatField()
    unit = serializers.CharField()
    size = serializers.CharField()
    # The ISO week and weekday of ``date``.
    year = serializers.IntegerField()
    delivery_week = serializers.IntegerField()
    day_number = serializers.IntegerField()

    # INVENTORY-specific fields
    washed = serializers.BooleanField(allow_null=True, required=False)
    cleaned = serializers.BooleanField(allow_null=True, required=False)
    for_shares = serializers.BooleanField(allow_null=True, required=False)
    for_resellers = serializers.BooleanField(allow_null=True, required=False)
    for_markets = serializers.BooleanField(allow_null=True, required=False)
    is_finalized = serializers.BooleanField(allow_null=True, required=False)

    # Movement-specific fields
    cultivation_origin = serializers.CharField(allow_null=True, required=False)

    # Common fields
    note = serializers.CharField(allow_null=True, required=False)
    storage_name = serializers.CharField()
    running_balance = serializers.FloatField()
