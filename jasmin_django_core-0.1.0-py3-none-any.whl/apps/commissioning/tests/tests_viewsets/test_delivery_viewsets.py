"""Tests for delivery_viewsets.py — DeliveryStation, DeliveryStationDay, DeliveryTours."""

from __future__ import annotations

import datetime

import pytest
import time_machine
from django.urls import reverse
from django.utils import timezone
from rest_framework import status

from apps.commissioning.models import DeliveryStation, DeliveryStationDay
from apps.commissioning.tests.factories import (
    DeliveryStationDayFactory,
    DeliveryStationFactory,
    ShareDeliveryFactory,
    ShareFactory,
    SharesDeliveryDayFactory,
    ShareTypeFactory,
    ShareTypeVariationFactory,
    SubscriptionFactory,
)
from apps.commissioning.utils.iso_week_utils import previous_monday
from apps.shared.tenants.models import TenantSettings


def _set_onboarding_mode(tenant, enabled: bool) -> None:
    row = TenantSettings.objects.filter(tenant=tenant, valid_until__isnull=True).first()
    if row is None:
        row = TenantSettings.objects.create(
            tenant=tenant, valid_from=timezone.now() - datetime.timedelta(days=365)
        )
    elif row.valid_from > timezone.now():
        # The frozen clock sits before a row opened in real time; move its start
        # back so ``get_current_settings`` sees it.
        row.valid_from = timezone.now() - datetime.timedelta(days=365)
    row.onboarding_mode = enabled
    row.save()


@pytest.fixture()
def onboarding_mode(tenant):
    _set_onboarding_mode(tenant, True)
    yield
    _set_onboarding_mode(tenant, False)


@pytest.fixture()
def onboarding_mode_off(tenant):
    _set_onboarding_mode(tenant, False)


# ---------------------------------------------------------------------------
# DeliveryStationViewSet
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestDeliveryStationViewSet:
    URL = reverse("delivery_station-list")

    def test_list_empty(self, api_client, tenant):
        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == []

    def test_list_returns_stations(self, api_client, tenant):
        DeliveryStationFactory()
        resp = api_client.get(self.URL)
        assert len(resp.data) >= 1

    def test_filter_is_active(self, api_client, tenant):
        DeliveryStationFactory(is_active=True)
        DeliveryStationFactory(is_active=False)
        resp = api_client.get(self.URL, {"is_active": "true"})
        assert all(s["is_active"] for s in resp.data)

    def test_retrieve_station(self, api_client, tenant):
        ds = DeliveryStationFactory()
        url = reverse("delivery_station-detail", kwargs={"pk": ds.pk})
        resp = api_client.get(url)
        assert resp.status_code == status.HTTP_200_OK

    def test_can_be_deleted_reflects_delivery_station_days(self, api_client, tenant):
        # A station configured with a delivery-station-day is undeletable: the
        # day CASCADEs off the station but is itself PROTECTed downstream
        # (import demand rows / share content / a member's default station-day),
        # so deleting the station would raise ProtectedError mid-cascade. The
        # office must not be offered a delete button -> can_be_deleted is False.
        # A bare station (no days) is still deletable.
        plain = DeliveryStationFactory()
        dsd = DeliveryStationDayFactory()
        configured = dsd.delivery_station

        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_200_OK
        flags = {s["id"]: s["can_be_deleted"] for s in resp.data}
        assert flags[str(plain.id)] is True
        assert flags[str(configured.id)] is False

    def test_filter_by_member_returns_only_subscribed_stations(
        self, api_client, tenant
    ):
        # A confirmed, still-running subscription pins the member to station A
        # (its default_delivery_station_day's station).
        dsd = DeliveryStationDayFactory()
        station_a = dsd.delivery_station
        sub = SubscriptionFactory(
            default_delivery_station_day=dsd,
            admin_confirmed=True,
        )
        # An unrelated station the member has no subscription to.
        station_b = DeliveryStationFactory()

        resp = api_client.get(self.URL, {"member": str(sub.member.id)})
        assert resp.status_code == status.HTTP_200_OK
        ids = {s["id"] for s in resp.data}
        assert str(station_a.id) in ids
        assert str(station_b.id) not in ids

    def test_filter_by_member_excludes_unconfirmed_subscription(
        self, api_client, tenant
    ):
        # A not-yet-confirmed subscription must NOT surface its station.
        dsd = DeliveryStationDayFactory()
        sub = SubscriptionFactory(
            default_delivery_station_day=dsd,
            admin_confirmed=False,
        )
        resp = api_client.get(self.URL, {"member": str(sub.member.id)})
        assert resp.status_code == status.HTTP_200_OK
        ids = {s["id"] for s in resp.data}
        assert str(dsd.delivery_station.id) not in ids

    def test_filter_by_delivery_day_lists_a_superseded_station_once(
        self, api_client, tenant
    ):
        # A station day with a successor leaves two rows for one station on the
        # same delivery day; the join must not repeat the station.
        closed = DeliveryStationDayFactory(
            valid_from=datetime.date(2026, 1, 5),
            valid_until=datetime.date(2026, 3, 1),
        )
        DeliveryStationDayFactory(
            delivery_station=closed.delivery_station,
            delivery_day=closed.delivery_day,
            valid_from=datetime.date(2026, 3, 2),
        )

        resp = api_client.get(self.URL, {"delivery_day": str(closed.delivery_day.id)})

        assert resp.status_code == status.HTTP_200_OK
        assert [s["id"] for s in resp.data] == [str(closed.delivery_station.id)]

    def test_member_role_can_list(self, anon_client, member_user, tenant):
        # Members read the list too (their member-detail stations card).
        DeliveryStationFactory()
        anon_client.force_authenticate(user=member_user)
        resp = anon_client.get(self.URL)
        assert resp.status_code == status.HTTP_200_OK


# ---------------------------------------------------------------------------
# DeliveryStationDayViewSet
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestDeliveryStationDayViewSet:
    URL = reverse("delivery_station_day-list")

    def test_list_empty(self, api_client, tenant):
        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_200_OK

    def test_list_returns_entries(self, api_client, tenant):
        DeliveryStationDayFactory()
        resp = api_client.get(self.URL)
        assert len(resp.data) >= 1

    def test_filter_by_delivery_station(self, api_client, tenant):
        dsd = DeliveryStationDayFactory()
        resp = api_client.get(
            self.URL, {"delivery_station": str(dsd.delivery_station.id)}
        )
        assert resp.status_code == status.HTTP_200_OK
        assert len(resp.data) >= 1

    def test_filter_by_delivery_day(self, api_client, tenant):
        dsd = DeliveryStationDayFactory()
        resp = api_client.get(self.URL, {"delivery_day": str(dsd.delivery_day.id)})
        assert resp.status_code == status.HTTP_200_OK
        assert len(resp.data) >= 1

    def test_flags_a_station_day_that_is_on_no_tour(self, api_client, tenant):
        day = SharesDeliveryDayFactory(day_number=2)
        on_tour = DeliveryStationDayFactory(
            delivery_day=day, tour_number=2, stop_order=1
        )
        off_tour = DeliveryStationDayFactory(delivery_day=day, stop_order=None)

        resp = api_client.get(self.URL, {"delivery_day": str(day.id)})

        assert resp.status_code == status.HTTP_200_OK
        missing = {row["id"]: row["tour_assignment_missing"] for row in resp.data}
        assert missing == {str(on_tour.id): False, str(off_tour.id): True}

    def test_a_station_day_taken_off_its_tour_reads_as_missing(
        self, api_client, tenant
    ):
        day = SharesDeliveryDayFactory(day_number=2)
        kept = DeliveryStationDayFactory(delivery_day=day, tour_number=1, stop_order=1)
        dropped = DeliveryStationDayFactory(
            delivery_day=day, tour_number=1, stop_order=2
        )

        resp = api_client.post(
            reverse("delivery_tours-update-tours"),
            {
                "delivery_day": str(day.id),
                "tours": [
                    {
                        "tour_number": 1,
                        "positions": [
                            {
                                "position": 1,
                                "delivery_station_id": str(kept.delivery_station_id),
                            }
                        ],
                    }
                ],
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_200_OK

        resp = api_client.get(self.URL, {"delivery_day": str(day.id)})
        missing = {row["id"]: row["tour_assignment_missing"] for row in resp.data}
        assert missing == {str(kept.id): False, str(dropped.id): True}

    def test_filter_by_member_returns_only_assigned_station_days(
        self, api_client, tenant
    ):
        # A confirmed, still-running subscription assigns the member to station-day
        # A (its default_delivery_station_day); a second station-day is unrelated.
        # Distinct day_numbers so the two SharesDeliveryDays don't collide on the
        # one-open-per-day_number constraint.
        dsd_a = DeliveryStationDayFactory(
            delivery_day=SharesDeliveryDayFactory(day_number=1)
        )
        dsd_b = DeliveryStationDayFactory(
            delivery_day=SharesDeliveryDayFactory(day_number=3)
        )
        sub = SubscriptionFactory(
            default_delivery_station_day=dsd_a,
            admin_confirmed=True,
        )
        resp = api_client.get(self.URL, {"member": str(sub.member.id)})
        assert resp.status_code == status.HTTP_200_OK
        ids = {row["id"] for row in resp.data}
        assert str(dsd_a.id) in ids
        assert str(dsd_b.id) not in ids

    def test_filter_by_member_excludes_unconfirmed_subscription(
        self, api_client, tenant
    ):
        # A not-yet-confirmed subscription must NOT surface its station-day.
        dsd = DeliveryStationDayFactory()
        sub = SubscriptionFactory(
            default_delivery_station_day=dsd,
            admin_confirmed=False,
        )
        resp = api_client.get(self.URL, {"member": str(sub.member.id)})
        assert resp.status_code == status.HTTP_200_OK
        ids = {row["id"] for row in resp.data}
        assert str(dsd.id) not in ids

    def test_member_cannot_query_another_members_station_days(
        self, anon_client, member_user, tenant
    ):
        # A crafted ?member=<other id> from a non-staff member is rejected — the
        # member↔station-day association must not be readable cross-member.
        other = SubscriptionFactory(admin_confirmed=True)
        anon_client.force_authenticate(user=member_user)
        resp = anon_client.get(self.URL, {"member": str(other.member.id)})
        assert resp.status_code == status.HTTP_403_FORBIDDEN

    def test_filter_by_member_includes_reassigned_upcoming_delivery(
        self, api_client, tenant
    ):
        # Subscription defaults to station-day A, but the member reassigned an
        # UPCOMING delivery to station-day B — both must appear.
        dsd_a = DeliveryStationDayFactory(
            delivery_day=SharesDeliveryDayFactory(day_number=1)
        )
        dsd_b = DeliveryStationDayFactory(
            delivery_day=SharesDeliveryDayFactory(day_number=3)
        )
        sub = SubscriptionFactory(
            default_delivery_station_day=dsd_a,
            admin_confirmed=True,
        )
        future_share = ShareFactory(
            delivery_day=dsd_b.delivery_day,
            share_type_variation=sub.share_type_variation,
            year=2027,
            delivery_week=15,
        )
        ShareDeliveryFactory(
            subscription=sub, share=future_share, delivery_station_day=dsd_b
        )
        resp = api_client.get(self.URL, {"member": str(sub.member.id)})
        assert resp.status_code == status.HTTP_200_OK
        ids = {row["id"] for row in resp.data}
        assert str(dsd_a.id) in ids
        assert str(dsd_b.id) in ids

    def test_filter_by_member_excludes_past_reassigned_delivery(
        self, api_client, tenant
    ):
        # A PAST one-off reassignment isn't actionable — station-day B must NOT
        # surface just because an old delivery used it.
        dsd_a = DeliveryStationDayFactory(
            delivery_day=SharesDeliveryDayFactory(day_number=1)
        )
        dsd_b = DeliveryStationDayFactory(
            delivery_day=SharesDeliveryDayFactory(day_number=3)
        )
        sub = SubscriptionFactory(
            default_delivery_station_day=dsd_a,
            admin_confirmed=True,
        )
        past_share = ShareFactory(
            delivery_day=dsd_b.delivery_day,
            share_type_variation=sub.share_type_variation,
            year=2020,
            delivery_week=15,
        )
        ShareDeliveryFactory(
            subscription=sub, share=past_share, delivery_station_day=dsd_b
        )
        resp = api_client.get(self.URL, {"member": str(sub.member.id)})
        assert resp.status_code == status.HTTP_200_OK
        ids = {row["id"] for row in resp.data}
        assert str(dsd_a.id) in ids
        assert str(dsd_b.id) not in ids

    def test_capacity_without_year_week_returns_null(self, api_client, tenant):
        DeliveryStationDayFactory(capacity=10)
        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data[0]["capacity_by_week"] is None

    def test_capacity_no_deliveries(self, api_client, tenant):
        dsd = DeliveryStationDayFactory(capacity=10)
        resp = api_client.get(
            self.URL, {"year": 2026, "delivery_week": 15, "num_weeks": 1}
        )
        assert resp.status_code == status.HTTP_200_OK
        entry = next(e for e in resp.data if e["id"] == str(dsd.id))
        assert entry["capacity_by_week"]["2026-15"]["occupied"] == 0
        assert entry["capacity_by_week"]["2026-15"]["free"] == 10

    def test_capacity_counts_harvest_shares(self, api_client, tenant):
        dd = SharesDeliveryDayFactory(day_number=3)
        dsd = DeliveryStationDayFactory(delivery_day=dd, capacity=10)

        # Create 3 HARVEST_SHARE deliveries (each needs unique share_type for variation unique_together)
        for _ in range(3):
            harvest_type = ShareTypeFactory(share_option="HARVEST_SHARE")
            harvest_var = ShareTypeVariationFactory(share_type=harvest_type)
            share = ShareFactory(
                delivery_day=dd,
                share_type_variation=harvest_var,
                year=2026,
                delivery_week=15,
            )
            ShareDeliveryFactory(share=share, delivery_station_day=dsd)

        resp = api_client.get(
            self.URL, {"year": 2026, "delivery_week": 15, "num_weeks": 1}
        )
        entry = next(e for e in resp.data if e["id"] == str(dsd.id))
        assert entry["capacity_by_week"]["2026-15"]["occupied"] == 3
        assert entry["capacity_by_week"]["2026-15"]["free"] == 7

    def test_capacity_counts_fruit_shares(self, api_client, tenant):
        dd = SharesDeliveryDayFactory(day_number=4)
        dsd = DeliveryStationDayFactory(delivery_day=dd, capacity=5)

        for _ in range(2):
            fruit_type = ShareTypeFactory(share_option="HARVEST_SHARE_FRUIT")
            fruit_var = ShareTypeVariationFactory(share_type=fruit_type)
            share = ShareFactory(
                delivery_day=dd,
                share_type_variation=fruit_var,
                year=2026,
                delivery_week=15,
            )
            ShareDeliveryFactory(share=share, delivery_station_day=dsd)

        resp = api_client.get(
            self.URL, {"year": 2026, "delivery_week": 15, "num_weeks": 1}
        )
        entry = next(e for e in resp.data if e["id"] == str(dsd.id))
        assert entry["capacity_by_week"]["2026-15"]["occupied"] == 2
        assert entry["capacity_by_week"]["2026-15"]["free"] == 3

    def test_capacity_excludes_other_share_types(self, api_client, tenant):
        dd = SharesDeliveryDayFactory(day_number=5)
        dsd = DeliveryStationDayFactory(delivery_day=dd, capacity=10)

        # HARVEST_SHARE counts
        harvest_type = ShareTypeFactory(share_option="HARVEST_SHARE")
        harvest_var = ShareTypeVariationFactory(share_type=harvest_type)
        share_h = ShareFactory(
            delivery_day=dd,
            share_type_variation=harvest_var,
            year=2026,
            delivery_week=15,
        )
        ShareDeliveryFactory(share=share_h, delivery_station_day=dsd)

        # An ADDITIONAL (packed-along) share does NOT count — it takes no slot.
        chicken_type = ShareTypeFactory(
            share_option="CHICKEN_SHARE", is_additional_share_type=True
        )
        chicken_var = ShareTypeVariationFactory(share_type=chicken_type)
        share_c = ShareFactory(
            delivery_day=dd,
            share_type_variation=chicken_var,
            year=2026,
            delivery_week=15,
        )
        ShareDeliveryFactory(share=share_c, delivery_station_day=dsd)

        resp = api_client.get(
            self.URL, {"year": 2026, "delivery_week": 15, "num_weeks": 1}
        )
        entry = next(e for e in resp.data if e["id"] == str(dsd.id))
        assert entry["capacity_by_week"]["2026-15"]["occupied"] == 1  # only harvest
        assert entry["capacity_by_week"]["2026-15"]["free"] == 9

    def test_capacity_counts_standalone_non_harvest_share(self, api_client, tenant):
        # Capacity keys on is_additional_share_type, NOT the share_option: a
        # STANDALONE (non-additional) share occupies a slot even when it isn't a
        # harvest share — a standalone chicken box takes a pickup slot.
        dd = SharesDeliveryDayFactory(day_number=6)
        dsd = DeliveryStationDayFactory(delivery_day=dd, capacity=10)
        chicken_type = ShareTypeFactory(
            share_option="CHICKEN_SHARE", is_additional_share_type=False
        )
        chicken_var = ShareTypeVariationFactory(share_type=chicken_type)
        share_c = ShareFactory(
            delivery_day=dd,
            share_type_variation=chicken_var,
            year=2026,
            delivery_week=15,
        )
        ShareDeliveryFactory(share=share_c, delivery_station_day=dsd)

        resp = api_client.get(
            self.URL, {"year": 2026, "delivery_week": 15, "num_weeks": 1}
        )
        entry = next(e for e in resp.data if e["id"] == str(dsd.id))
        assert entry["capacity_by_week"]["2026-15"]["occupied"] == 1

    def test_capacity_different_week_not_counted(self, api_client, tenant):
        dd = SharesDeliveryDayFactory(day_number=0)
        dsd = DeliveryStationDayFactory(delivery_day=dd, capacity=10)

        harvest_type = ShareTypeFactory(share_option="HARVEST_SHARE")
        harvest_var = ShareTypeVariationFactory(share_type=harvest_type)
        # Delivery in week 16
        share = ShareFactory(
            delivery_day=dd,
            share_type_variation=harvest_var,
            year=2026,
            delivery_week=16,
        )
        ShareDeliveryFactory(share=share, delivery_station_day=dsd)

        # Query for week 15 — should be empty
        resp = api_client.get(
            self.URL, {"year": 2026, "delivery_week": 15, "num_weeks": 1}
        )
        entry = next(e for e in resp.data if e["id"] == str(dsd.id))
        assert entry["capacity_by_week"]["2026-15"]["occupied"] == 0
        assert entry["capacity_by_week"]["2026-15"]["free"] == 10


# ---------------------------------------------------------------------------
# DeliveryStationDayViewSet — moving valid_from
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestDeliveryStationDayValidFromMove:
    """PATCHing the START of a station-day's window.

    Moving it LATER past existing deliveries is refused in every mode: they keep
    pointing at this row — the migration runs only on the create/succession path
    — so nothing re-homes them. Moving it EARLIER into a week that has already
    been delivered is refused too, unless the tenant is in onboarding mode; a
    start before the station-day's OWN delivery day is refused in every mode.
    """

    @pytest.fixture(autouse=True)
    def _frozen_clock(self):
        # A Monday away from any year boundary. The current week starts
        # 2026-02-02, so the rows built at 2026-01-05 start in a past week
        # while 2026-06-01 stays comfortably in the future.
        with time_machine.travel(datetime.datetime(2026, 2, 2, 12, 0), tick=False):
            yield

    @staticmethod
    def _url(station_day):
        return reverse("delivery_station_day-detail", kwargs={"pk": station_day.pk})

    def test_moving_start_later_past_existing_deliveries_returns_409(
        self, api_client, tenant, onboarding_mode_off
    ):
        station_day = DeliveryStationDayFactory(valid_from=datetime.date(2026, 1, 5))
        # ISO week 15/2026 starts 2026-04-06 — before the proposed new start.
        share = ShareFactory(
            delivery_day=station_day.delivery_day, year=2026, delivery_week=15
        )
        ShareDeliveryFactory(share=share, delivery_station_day=station_day)

        resp = api_client.patch(
            self._url(station_day), {"valid_from": "2026-06-01"}, format="json"
        )

        assert resp.status_code == status.HTTP_409_CONFLICT
        assert resp.data["code"] == "delivery_station_day.start_move_strands_children"
        assert resp.data["details"]["stranded_count"] == 1
        station_day.refresh_from_db()
        assert station_day.valid_from == datetime.date(2026, 1, 5)

    def test_moving_start_later_past_deliveries_stays_refused_in_onboarding_mode(
        self, api_client, tenant, onboarding_mode
    ):
        """Onboarding opens the earlier direction only — the later move still
        strands the deliveries pointing at this row."""
        station_day = DeliveryStationDayFactory(valid_from=datetime.date(2026, 1, 5))
        share = ShareFactory(
            delivery_day=station_day.delivery_day, year=2026, delivery_week=15
        )
        ShareDeliveryFactory(share=share, delivery_station_day=station_day)

        resp = api_client.patch(
            self._url(station_day), {"valid_from": "2026-06-01"}, format="json"
        )

        assert resp.status_code == status.HTTP_409_CONFLICT
        assert resp.data["code"] == "delivery_station_day.start_move_strands_children"
        station_day.refresh_from_db()
        assert station_day.valid_from == datetime.date(2026, 1, 5)

    def test_moving_start_into_a_past_week_is_refused(
        self, api_client, tenant, onboarding_mode_off
    ):
        # The delivery day itself starts well before the proposed date, so the
        # past-week rule is the only one in play.
        delivery_day = SharesDeliveryDayFactory(valid_from=datetime.date(2025, 10, 6))
        station_day = DeliveryStationDayFactory(
            delivery_day=delivery_day, valid_from=datetime.date(2026, 1, 5)
        )

        resp = api_client.patch(
            self._url(station_day), {"valid_from": "2025-11-03"}, format="json"
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "delivery_day.valid_from_move_into_past"
        station_day.refresh_from_db()
        assert station_day.valid_from == datetime.date(2026, 1, 5)

    def test_moving_start_into_a_past_week_is_allowed_in_onboarding_mode(
        self, api_client, tenant, onboarding_mode
    ):
        """Widening the window backwards strands nothing, and the office is
        entering a pickup schedule that has been running for a while."""
        delivery_day = SharesDeliveryDayFactory(valid_from=datetime.date(2025, 10, 6))
        station_day = DeliveryStationDayFactory(
            delivery_day=delivery_day, valid_from=datetime.date(2026, 1, 5)
        )
        share = ShareFactory(delivery_day=delivery_day, year=2026, delivery_week=15)
        ShareDeliveryFactory(share=share, delivery_station_day=station_day)

        resp = api_client.patch(
            self._url(station_day), {"valid_from": "2025-11-03"}, format="json"
        )

        assert resp.status_code == status.HTTP_200_OK
        station_day.refresh_from_db()
        assert station_day.valid_from == datetime.date(2025, 11, 3)

    def test_moving_start_before_its_delivery_day_is_refused(
        self, api_client, tenant, onboarding_mode_off
    ):
        delivery_day = SharesDeliveryDayFactory(valid_from=datetime.date(2026, 3, 2))
        station_day = DeliveryStationDayFactory(
            delivery_day=delivery_day, valid_from=datetime.date(2026, 3, 2)
        )

        # The current week's Monday — not a past week, so only the delivery
        # day's own start stands in the way.
        resp = api_client.patch(
            self._url(station_day), {"valid_from": "2026-02-02"}, format="json"
        )

        assert resp.status_code == status.HTTP_409_CONFLICT
        assert resp.data["code"] == "delivery_station_day.starts_before_delivery_day"
        station_day.refresh_from_db()
        assert station_day.valid_from == datetime.date(2026, 3, 2)

    def test_moving_start_before_its_delivery_day_is_refused_in_onboarding_mode(
        self, api_client, tenant, onboarding_mode
    ):
        """Onboarding relaxes the past-week rule, not the coverage one — the
        station-day would be active on weeks its day does not run."""
        delivery_day = SharesDeliveryDayFactory(valid_from=datetime.date(2026, 3, 2))
        station_day = DeliveryStationDayFactory(
            delivery_day=delivery_day, valid_from=datetime.date(2026, 3, 2)
        )

        resp = api_client.patch(
            self._url(station_day), {"valid_from": "2025-11-03"}, format="json"
        )

        assert resp.status_code == status.HTTP_409_CONFLICT
        assert resp.data["code"] == "delivery_station_day.starts_before_delivery_day"
        station_day.refresh_from_db()
        assert station_day.valid_from == datetime.date(2026, 3, 2)

    def test_moving_start_later_with_nothing_before_it_is_allowed(
        self, api_client, tenant, onboarding_mode_off
    ):
        station_day = DeliveryStationDayFactory(valid_from=datetime.date(2026, 1, 5))
        # Week 40/2026 starts 2026-09-28 — after the proposed new start.
        share = ShareFactory(
            delivery_day=station_day.delivery_day, year=2026, delivery_week=40
        )
        ShareDeliveryFactory(share=share, delivery_station_day=station_day)

        resp = api_client.patch(
            self._url(station_day), {"valid_from": "2026-06-01"}, format="json"
        )

        assert resp.status_code == status.HTTP_200_OK
        station_day.refresh_from_db()
        assert station_day.valid_from == datetime.date(2026, 6, 1)


# ---------------------------------------------------------------------------
# DeliveryStationDayViewSet — creating
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestDeliveryStationDayCreate:
    """POSTing a station-day.

    The new row must open inside its delivery day's window, and not in the
    past. The window guard matters as much here as on the move: the office UI
    locks ``delivery_day`` and ``valid_from`` once the row is saved, and moving
    the start back to reach the day is refused by the update guard too — so a
    row minted outside its day's window has no repair path.
    """

    URL = reverse("delivery_station_day-list")

    @pytest.fixture(autouse=True)
    def _frozen_clock(self):
        # A Monday away from any year boundary, so the dates below keep their
        # past/future relationship whatever the wall clock reads.
        with time_machine.travel(datetime.datetime(2026, 2, 2, 12, 0), tick=False):
            yield

    @staticmethod
    def _payload(station, delivery_day, valid_from):
        return {
            "delivery_station": str(station.id),
            "delivery_day": str(delivery_day.id),
            "valid_from": valid_from,
        }

    def test_creating_before_its_delivery_day_returns_409(self, api_client, tenant):
        """A future-dated delivery day is offered next to a valid_from picker
        bounded only at today, so this is the pairing the office lands on."""
        delivery_day = SharesDeliveryDayFactory(valid_from=datetime.date(2026, 10, 5))
        station = DeliveryStationFactory()

        resp = api_client.post(
            self.URL,
            # A future Monday — past the create guard, still eight weeks before
            # the delivery day itself starts.
            self._payload(station, delivery_day, "2026-08-10"),
            format="json",
        )

        assert resp.status_code == status.HTTP_409_CONFLICT
        assert resp.data["code"] == "delivery_station_day.starts_before_delivery_day"
        assert not DeliveryStationDay.objects.filter(
            delivery_station=station, delivery_day=delivery_day
        ).exists()

    def test_creating_on_its_delivery_days_own_start_is_allowed(
        self, api_client, tenant
    ):
        delivery_day = SharesDeliveryDayFactory(valid_from=datetime.date(2026, 10, 5))
        station = DeliveryStationFactory()

        resp = api_client.post(
            self.URL,
            self._payload(station, delivery_day, "2026-10-05"),
            format="json",
        )

        assert resp.status_code == status.HTTP_201_CREATED
        created = DeliveryStationDay.objects.get(
            delivery_station=station, delivery_day=delivery_day
        )
        assert created.valid_from == datetime.date(2026, 10, 5)

    def test_creating_with_valid_from_in_the_past_returns_400(self, api_client, tenant):
        """The create boundary is today; the laxer move boundary (the current
        week's Monday, liftable by onboarding mode) carries its own code."""
        delivery_day = SharesDeliveryDayFactory(valid_from=datetime.date(2025, 10, 6))
        station = DeliveryStationFactory()

        resp = api_client.post(
            self.URL,
            self._payload(station, delivery_day, "2026-01-05"),
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "delivery_day.valid_from_in_past"
        assert not DeliveryStationDay.objects.filter(
            delivery_station=station, delivery_day=delivery_day
        ).exists()


# ---------------------------------------------------------------------------
# DeliveryToursViewSet
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestDeliveryToursViewSet:
    URL = reverse("delivery_tours-list")

    def test_list_requires_delivery_day(self, api_client, tenant):
        resp = api_client.get(self.URL)
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_list_with_delivery_day(self, api_client, tenant):
        dd = SharesDeliveryDayFactory(day_number=1)
        DeliveryStationDayFactory(delivery_day=dd, tour_number=1, stop_order=1)
        resp = api_client.get(self.URL, {"delivery_day": str(dd.id)})
        assert resp.status_code == status.HTTP_200_OK

    def test_update_tours_targets_open_row_when_station_day_is_versioned(
        self, api_client, tenant
    ):
        # A (station, day) pair with history: the current open station-day plus
        # an earlier closed one. update_tours must resolve to only the OPEN row —
        # an update_or_create unscoped by valid_until would match BOTH rows on its
        # implicit get() and 500 with MultipleObjectsReturned.
        station = DeliveryStationFactory()
        day = SharesDeliveryDayFactory(day_number=3)
        # First day opens 2026-01-05 (factory default). Creating a second at a
        # later Monday auto-closes this predecessor at 2026-05-31 via
        # TimeBoundMixin succession, leaving two rows for the pair.
        closed = DeliveryStationDayFactory(delivery_station=station, delivery_day=day)
        current = DeliveryStationDayFactory(
            delivery_station=station,
            delivery_day=day,
            valid_from=datetime.date(2026, 6, 1),
        )
        closed.refresh_from_db()
        assert closed.valid_until is not None  # predecessor was closed
        assert current.valid_until is None  # successor is the open row

        resp = api_client.post(
            reverse("delivery_tours-update-tours"),
            {
                "delivery_day": str(day.id),
                "tours": [
                    {
                        "tour_number": 2,
                        "positions": [
                            {"position": 1, "delivery_station_id": str(station.id)}
                        ],
                    }
                ],
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK
        current.refresh_from_db()
        closed.refresh_from_db()
        # The open row carries the new assignment; the closed history row is
        # left exactly as it was.
        assert current.tour_number == 2
        assert current.stop_order == 1
        assert closed.tour_number == 1
        assert closed.stop_order is None


@pytest.mark.django_db
class TestUpdateToursCreatesStationDay:
    """The CREATE branch of ``update_tours``' ``update_or_create``.

    ``DeliveryStationDay`` has no ``is_active`` field (its sibling
    ``DeliveryStation`` does), so ``defaults`` must not carry one. Django
    setattrs unknown defaults on the UPDATE branch, so only this CREATE branch
    exposes it: it passes them to the constructor and raises
    ``TypeError: got unexpected keyword arguments``.

    Activeness for this model IS ``valid_until IS NULL``, which the queryset
    filter already expresses.
    """

    def test_assigning_a_station_with_no_station_day_creates_one(
        self, api_client, tenant
    ):
        station = DeliveryStationFactory()
        day = SharesDeliveryDayFactory(day_number=4)
        # Deliberately NO DeliveryStationDay for this pair -> the create branch.
        assert not DeliveryStationDay.objects.filter(
            delivery_station=station, delivery_day=day
        ).exists()

        resp = api_client.post(
            reverse("delivery_tours-update-tours"),
            {
                "delivery_day": str(day.id),
                "tours": [
                    {
                        "tour_number": 3,
                        "positions": [
                            {"position": 1, "delivery_station_id": str(station.id)}
                        ],
                    }
                ],
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK
        created = DeliveryStationDay.objects.get(
            delivery_station=station, delivery_day=day
        )
        assert created.tour_number == 3
        assert created.stop_order == 1
        # Open row = the active one; there is no is_active column to set.
        assert created.valid_until is None
        # valid_from is NOT NULL with no model default, so the create branch has
        # to supply it — and the project invariant is that it is always a Monday.
        assert created.valid_from is not None
        assert created.valid_from.weekday() == 0, "valid_from must be a Monday"
        # Effective from the current week. This day started long ago, so the
        # clamp to its own start doesn't bite.
        assert created.valid_from == previous_monday(timezone.localdate())

    def test_assignment_on_a_future_dated_day_opens_at_that_days_start(
        self, api_client, tenant
    ):
        """A station-day may not open before its delivery day, so the created
        row starts at the day's own start rather than this week's Monday."""
        with time_machine.travel(datetime.datetime(2026, 2, 2, 12, 0), tick=False):
            station = DeliveryStationFactory()
            day = SharesDeliveryDayFactory(
                day_number=5, valid_from=datetime.date(2026, 10, 5)
            )

            resp = api_client.post(
                reverse("delivery_tours-update-tours"),
                {
                    "delivery_day": str(day.id),
                    "tours": [
                        {
                            "tour_number": 1,
                            "positions": [
                                {"position": 1, "delivery_station_id": str(station.id)}
                            ],
                        }
                    ],
                },
                format="json",
            )

            assert resp.status_code == status.HTTP_200_OK
            created = DeliveryStationDay.objects.get(
                delivery_station=station, delivery_day=day
            )
            assert created.valid_from == datetime.date(2026, 10, 5)


@pytest.mark.django_db
class TestUpdateToursKeepsStationDayStart:
    """The UPDATE branch of ``update_tours`` moves an existing station day to
    its new tour and stop and leaves its start alone — a start moved back in
    the station's modal (onboarding mode) survives the next tour edit, and
    the deliveries before this week stay inside the row's window."""

    def test_an_existing_station_day_keeps_its_start(self, api_client, tenant):
        station = DeliveryStationFactory()
        day = SharesDeliveryDayFactory(day_number=4)
        station_day = DeliveryStationDayFactory(
            delivery_station=station,
            delivery_day=day,
            valid_from=datetime.date(2026, 1, 5),
            tour_number=1,
            stop_order=1,
        )

        resp = api_client.post(
            reverse("delivery_tours-update-tours"),
            {
                "delivery_day": str(day.id),
                "tours": [
                    {
                        "tour_number": 2,
                        "positions": [
                            {"position": 3, "delivery_station_id": str(station.id)}
                        ],
                    }
                ],
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK
        station_day.refresh_from_db()
        assert station_day.tour_number == 2
        assert station_day.stop_order == 3
        assert station_day.valid_from == datetime.date(2026, 1, 5)
        assert (
            DeliveryStationDay.objects.filter(
                delivery_station=station, delivery_day=day
            ).count()
            == 1
        )


# ---------------------------------------------------------------------------
# DeliveryStationViewSet — an IBAN rewrite needs step-up
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestDeliveryStationIbanStepUp:
    """A station writes through to the ContactEntity a linked reseller shares,
    so an IBAN rewrite here redirects money exactly as it does on the reseller
    and is gated the same way."""

    STORED_IBAN = "DE89370400440532013000"
    NEW_IBAN = "DE75512108001245126199"
    LIST_URL = reverse("delivery_station-list")
    SHORT_NAME = "Bank Street Station"

    @staticmethod
    def _station_with_contact(iban):
        from apps.commissioning.tests.factories import ContactEntityFactory

        return DeliveryStationFactory(contact=ContactEntityFactory(iban=iban))

    @staticmethod
    def _url(station):
        return reverse("delivery_station-detail", kwargs={"pk": station.pk})

    @classmethod
    def _create_body(cls, **overrides):
        return {
            "short_name": cls.SHORT_NAME,
            "address": "Main 1",
            "zip_code": "12345",
            "city": "Town",
            **overrides,
        }

    def _created(self):
        return DeliveryStation.objects.filter(short_name=self.SHORT_NAME)

    def test_rewriting_the_iban_is_refused_without_step_up(self, api_client, tenant):
        station = self._station_with_contact(self.STORED_IBAN)

        resp = api_client.patch(
            self._url(station), {"iban": self.NEW_IBAN}, format="json"
        )

        assert resp.status_code == status.HTTP_403_FORBIDDEN
        assert resp.data["code"] == "auth.step_up_required"
        station.contact.refresh_from_db()
        assert station.contact.iban == self.STORED_IBAN

    def test_a_station_without_a_contact_is_gated_too(self, api_client, tenant):
        station = DeliveryStationFactory()

        resp = api_client.patch(
            self._url(station), {"iban": self.NEW_IBAN}, format="json"
        )

        assert resp.status_code == status.HTTP_403_FORBIDDEN
        assert resp.data["code"] == "auth.step_up_required"

    def test_a_fresh_step_up_claim_writes_the_iban(self, step_up_client, tenant):
        station = self._station_with_contact(self.STORED_IBAN)

        resp = step_up_client.patch(
            self._url(station), {"iban": self.NEW_IBAN}, format="json"
        )

        assert resp.status_code == status.HTTP_200_OK
        station.contact.refresh_from_db()
        assert station.contact.iban == self.NEW_IBAN

    def test_resending_the_stored_iban_prompts_for_nothing(self, api_client, tenant):
        station = self._station_with_contact(self.STORED_IBAN)

        resp = api_client.patch(
            self._url(station),
            {"iban": self.STORED_IBAN, "is_active": False},
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK
        station.refresh_from_db()
        assert station.is_active is False

    def test_an_edit_that_leaves_the_iban_alone_prompts_for_nothing(
        self, api_client, tenant
    ):
        station = self._station_with_contact(self.STORED_IBAN)

        resp = api_client.patch(self._url(station), {"is_active": False}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        station.refresh_from_db()
        assert station.is_active is False

    def test_creating_with_an_iban_is_refused_without_step_up(self, api_client, tenant):
        resp = api_client.post(
            self.LIST_URL, self._create_body(iban=self.NEW_IBAN), format="json"
        )

        assert resp.status_code == status.HTTP_403_FORBIDDEN
        assert resp.data["code"] == "auth.step_up_required"
        assert not self._created().exists()

    def test_a_fresh_step_up_claim_creates_with_the_iban(self, step_up_client, tenant):
        resp = step_up_client.post(
            self.LIST_URL, self._create_body(iban=self.NEW_IBAN), format="json"
        )

        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert self._created().get().contact.iban == self.NEW_IBAN

    def test_creating_without_an_iban_key_prompts_for_nothing(self, api_client, tenant):
        resp = api_client.post(self.LIST_URL, self._create_body(), format="json")

        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert self._created().exists()

    def test_creating_with_a_blank_iban_prompts_for_nothing(self, api_client, tenant):
        """A create payload that serialises every contact field carries an
        empty ``iban``; it sets no bank account, so it is not challenged."""
        resp = api_client.post(self.LIST_URL, self._create_body(iban=""), format="json")

        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert self._created().get().contact.iban in (None, "")
