"""Tests for reseller_views.py — order overview, bulk document ops, offers."""

from __future__ import annotations

import pytest
from django.urls import reverse
from rest_framework import status

from apps.commissioning.models import (
    DeliveryNoteReseller,
    InvoiceReseller,
    InvoiceResellerContent,
    Order,
)
from apps.commissioning.tests.factories import (
    DeliveryNoteContentFactory,
    DeliveryNoteResellerFactory,
    InvoiceResellerFactory,
    OfferFactory,
    OfferGroupFactory,
    OrderContentFactory,
    OrderFactory,
    ResellerFactory,
)

# ---------------------------------------------------------------------------
# DaysWithOrdersView
# ---------------------------------------------------------------------------
URL_DAYS_WITH_ORDERS = reverse("days_with_orders")


@pytest.mark.django_db
class TestDaysWithOrdersView:
    def test_returns_distinct_days(self, api_client, tenant):
        reseller = ResellerFactory()
        o1 = OrderFactory(reseller=reseller, year=2026, delivery_week=15, day_number=1)
        o2 = OrderFactory(reseller=reseller, year=2026, delivery_week=15, day_number=3)
        OrderContentFactory(order=o1)
        OrderContentFactory(order=o2)

        resp = api_client.get(URL_DAYS_WITH_ORDERS, {"year": 2026, "delivery_week": 15})
        assert resp.status_code == status.HTTP_200_OK
        assert set(resp.data["days"]) == {1, 3}

    def test_empty_when_no_orders(self, api_client, tenant):
        resp = api_client.get(URL_DAYS_WITH_ORDERS, {"year": 2026, "delivery_week": 15})
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["days"] == []

    def test_missing_params_returns_400(self, api_client, tenant):
        resp = api_client.get(URL_DAYS_WITH_ORDERS)
        assert resp.status_code == status.HTTP_400_BAD_REQUEST


# ---------------------------------------------------------------------------
# CombinedOrderOverviewView
# ---------------------------------------------------------------------------
URL_ORDERS_OVERVIEW = reverse("orders_overview")


@pytest.mark.django_db
class TestCombinedOrderOverviewView:
    def test_returns_orders(self, api_client, tenant):
        reseller = ResellerFactory()
        OrderFactory(reseller=reseller, year=2026, delivery_week=15, day_number=1)

        resp = api_client.get(URL_ORDERS_OVERVIEW, {"year": 2026, "delivery_week": 15})
        assert resp.status_code == status.HTTP_200_OK
        assert len(resp.data) == 1
        assert "order_number" in resp.data[0]
        assert resp.data[0]["has_delivery_note"] is False

    def test_filters_by_reseller(self, api_client, tenant):
        r1 = ResellerFactory()
        r2 = ResellerFactory()
        OrderFactory(reseller=r1, year=2026, delivery_week=15, day_number=1)
        OrderFactory(reseller=r2, year=2026, delivery_week=15, day_number=1)

        resp = api_client.get(
            URL_ORDERS_OVERVIEW,
            {"year": 2026, "delivery_week": 15, "reseller": str(r1.id)},
        )
        assert resp.status_code == status.HTTP_200_OK
        assert len(resp.data) == 1

    def test_includes_delivery_note_info(self, api_client, tenant):
        reseller = ResellerFactory()
        order = OrderFactory(
            reseller=reseller, year=2026, delivery_week=15, day_number=1
        )
        DeliveryNoteResellerFactory(order=order)

        resp = api_client.get(URL_ORDERS_OVERVIEW, {"year": 2026, "delivery_week": 15})
        assert resp.data[0]["has_delivery_note"] is True

    def test_empty_without_orders(self, api_client, tenant):
        resp = api_client.get(URL_ORDERS_OVERVIEW, {"year": 2026, "delivery_week": 53})
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data == []

    def test_missing_year_returns_400(self, api_client, tenant):
        # year is required at runtime — without it the endpoint would
        # materialize every order across all years with no pagination.
        resp = api_client.get(URL_ORDERS_OVERVIEW)
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "query.invalid_param"
        assert "year" in resp.data["message"]


# ---------------------------------------------------------------------------
# BulkCopyOffersToNextWeekView
# ---------------------------------------------------------------------------
URL_COPY_OFFERS = reverse("bulk_copy_offers_to_next_week")


@pytest.mark.django_db
class TestBulkCopyOffersToNextWeekView:
    def test_copies_offers(self, api_client, tenant):
        offer = OfferFactory(year=2026, delivery_week=15)

        resp = api_client.post(
            URL_COPY_OFFERS,
            {"ids": [str(offer.id)]},
            format="json",
        )
        assert resp.status_code == status.HTTP_201_CREATED
        assert resp.data["total_requested"] == 1
        assert resp.data["total_copied"] >= 0

    def test_empty_ids_returns_400(self, api_client, tenant):
        resp = api_client.post(URL_COPY_OFFERS, {"ids": []}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST


@pytest.mark.django_db
class TestBulkResellerEndpointsRejectNonStringIds:
    """Every ids entry must be a non-empty string; a number, null or object
    entry is refused before any row is looked up."""

    @pytest.mark.parametrize(
        ("url_name", "extra"),
        [
            ("bulk_copy_offers_to_next_week", {}),
            ("bulk_create_documents_from_orders", {"model": "invoice"}),
            ("bulk_finalize_documents", {"model": "delivery_note"}),
            ("bulk_delete_documents", {"model": "invoice"}),
            ("bulk_set_to_paid_documents", {"model": "invoice"}),
            ("bulk_create_summary_invoice_from_orders", {}),
        ],
    )
    @pytest.mark.parametrize("bad_id", [123, None, {"id": "x"}])
    def test_non_string_id_returns_400(
        self, api_client, tenant, url_name, extra, bad_id
    ):
        order = OrderFactory()
        resp = api_client.post(
            reverse(url_name),
            {"ids": [str(order.id), bad_id], **extra},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "bulk.ids_invalid"
        assert resp.data["field"] == "ids"


# ---------------------------------------------------------------------------
# BulkCopyOffersToOfferGroupView
# ---------------------------------------------------------------------------
URL_COPY_TO_GROUP = reverse("bulk_copy_offers_to_offer_group")


@pytest.mark.django_db
class TestBulkCopyOffersToOfferGroupView:
    def test_copies_to_group(self, api_client, tenant):
        offer = OfferFactory(year=2026, delivery_week=15)
        group = OfferGroupFactory()

        resp = api_client.post(
            URL_COPY_TO_GROUP,
            {
                "ids": [str(offer.id)],
                "year": 2026,
                "delivery_week": 15,
                "offer_group": str(group.id),
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_201_CREATED

    def test_missing_offer_group_returns_400(self, api_client, tenant):
        resp = api_client.post(
            URL_COPY_TO_GROUP,
            {"ids": ["some-id"], "year": 2026, "delivery_week": 15},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "bulk_copy_offers.offer_group_required"

    def test_missing_week_returns_400(self, api_client, tenant):
        group = OfferGroupFactory()
        resp = api_client.post(
            URL_COPY_TO_GROUP,
            {"ids": ["some-id"], "year": 2026, "offer_group": str(group.id)},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "bulk_copy_offers.week_required"

    @pytest.mark.parametrize(
        "year,delivery_week",
        [("abc", 15), (2026, 99), (2026, "week")],
    )
    def test_unusable_week_scope_returns_400(
        self, api_client, tenant, year, delivery_week
    ):
        """A year or week that is present but not a usable number reached the
        ``exists_filter`` query raw. It is a request error, not a 500, and
        nothing is copied."""
        from apps.commissioning.models import Offer

        offer = OfferFactory(year=2026, delivery_week=15)
        group = OfferGroupFactory()

        resp = api_client.post(
            URL_COPY_TO_GROUP,
            {
                "ids": [str(offer.id)],
                "year": year,
                "delivery_week": delivery_week,
                "offer_group": str(group.id),
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "bulk_copy_offers.invalid"
        assert Offer.objects.count() == 1

    @pytest.mark.parametrize("ids", [5, "abc", [], None])
    def test_unusable_ids_returns_400(self, api_client, tenant, ids):
        """``ids`` was read with a ``[]`` default and iterated as given, so a
        scalar reached the service."""
        group = OfferGroupFactory()

        resp = api_client.post(
            URL_COPY_TO_GROUP,
            {
                "ids": ids,
                "year": 2026,
                "delivery_week": 15,
                "offer_group": str(group.id),
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "bulk_copy_offers.ids_required"


# ---------------------------------------------------------------------------
# SetInvoiceNoteView
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestSetInvoiceNoteView:
    @staticmethod
    def _order_with_invoice(note: str = "") -> tuple[Order, InvoiceReseller]:
        """An order carried all the way to an invoice. The view resolves the
        invoice through order → delivery_note → the invoice line's provenance
        link, so a standalone invoice is never found and every request 404s
        before the body is even looked at."""
        reseller = ResellerFactory()
        order = OrderFactory(reseller=reseller)
        delivery_note_line = DeliveryNoteContentFactory(
            delivery_note=DeliveryNoteResellerFactory(order=order)
        )
        invoice = InvoiceResellerFactory(reseller=reseller, note=note)
        invoice_line = InvoiceResellerContent.objects.create(
            invoice=invoice,
            share_article=delivery_note_line.share_article,
            amount=delivery_note_line.amount,
            unit=delivery_note_line.unit,
            size=delivery_note_line.size,
            tax_rate=delivery_note_line.tax_rate,
        )
        invoice_line.delivery_note_contents.add(delivery_note_line)
        return order, invoice

    def test_sets_note(self, api_client, tenant):
        order, invoice = self._order_with_invoice()

        url = reverse("set_invoice_note", args=[str(order.id)])
        resp = api_client.patch(url, {"note": "Test note"}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["note"] == "Test note"
        invoice.refresh_from_db()
        assert invoice.note == "Test note"

    def test_note_longer_than_the_column_returns_400(self, api_client, tenant):
        """``InvoiceReseller.note`` is CharField(max_length=500), and the
        request serializer mirrors that width: an over-long note is a 400
        naming the field, never a generic data error from Postgres."""
        order, invoice = self._order_with_invoice(note="keep me")

        url = reverse("set_invoice_note", args=[str(order.id)])
        resp = api_client.patch(url, {"note": "x" * 501}, format="json")

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "note" in resp.data["details"]
        invoice.refresh_from_db()
        assert invoice.note == "keep me"

    def test_note_at_the_column_limit_is_accepted(self, api_client, tenant):
        order, invoice = self._order_with_invoice()

        url = reverse("set_invoice_note", args=[str(order.id)])
        resp = api_client.patch(url, {"note": "x" * 500}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        invoice.refresh_from_db()
        assert invoice.note == "x" * 500


# ---------------------------------------------------------------------------
# BulkFinalizeDocumentsView
# ---------------------------------------------------------------------------
URL_FINALIZE_DOCS = reverse("bulk_finalize_documents")


@pytest.mark.django_db
class TestBulkFinalizeDocumentsView:
    def test_missing_model_returns_400(self, api_client, tenant):
        resp = api_client.post(
            URL_FINALIZE_DOCS,
            {"ids": ["some-id"]},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_invalid_model_returns_400(self, api_client, tenant):
        resp = api_client.post(
            URL_FINALIZE_DOCS,
            {"ids": ["some-id"], "model": "invalid"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_no_orders_returns_404(self, api_client, tenant):
        resp = api_client.post(
            URL_FINALIZE_DOCS,
            {
                "ids": ["00000000-0000-0000-0000-000000000000"],
                "model": "delivery_note",
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND


# ---------------------------------------------------------------------------
# BulkDeleteDocumentsView
# ---------------------------------------------------------------------------
URL_DELETE_DOCS = reverse("bulk_delete_documents")


@pytest.mark.django_db
class TestBulkDeleteDocumentsView:
    def test_deletes_delivery_note(self, api_client, tenant):
        reseller = ResellerFactory()
        order = OrderFactory(reseller=reseller)
        dn = DeliveryNoteResellerFactory(order=order)

        resp = api_client.post(
            URL_DELETE_DOCS,
            {"ids": [str(order.id)], "model": "delivery_note"},
            format="json",
        )
        assert resp.status_code in (status.HTTP_200_OK, status.HTTP_207_MULTI_STATUS)
        # Delivery note should be deleted
        assert not DeliveryNoteReseller.objects.filter(pk=dn.pk).exists()

    def test_cannot_delete_finalized(self, api_client, tenant):
        reseller = ResellerFactory()
        order = OrderFactory(reseller=reseller)
        dn = DeliveryNoteResellerFactory(order=order)
        DeliveryNoteReseller.objects.filter(pk=dn.pk).update(is_finalized=True)

        resp = api_client.post(
            URL_DELETE_DOCS,
            {"ids": [str(order.id)], "model": "delivery_note"},
            format="json",
        )
        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert DeliveryNoteReseller.objects.filter(pk=dn.pk).exists()

    def test_invalid_model_returns_400(self, api_client, tenant):
        resp = api_client.post(
            URL_DELETE_DOCS,
            {"ids": ["x"], "model": "BAD"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST


# ---------------------------------------------------------------------------
# _run_per_order_bulk savepoint isolation
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestRunPerOrderBulkSavepoint:
    """A real DB-level error in one order's handler (e.g. a PROTECT FK on
    delete) must roll back ONLY that order, leaving the connection usable so
    the rest of the batch still commits — a 207, not a 500. Without the
    per-order savepoint the first IntegrityError poisons the view's outer
    ``@transaction.atomic`` and every later query raises
    ``TransactionManagementError``."""

    def test_db_error_in_one_order_does_not_abort_batch(self, tenant):
        from django.db import transaction

        from apps.commissioning.views.reseller_views import _run_per_order_bulk

        good = OrderFactory()
        bad = OrderFactory()

        def handler(order, results, errors):
            if order.pk == bad.pk:
                # Force a real IntegrityError: re-INSERT an already-saved row
                # (duplicate primary key). bulk_create bypasses save() /
                # full_clean and hits the DB directly, so this is a genuine
                # transaction-aborting error — exactly what the savepoint must
                # contain. Without the savepoint the outer atomic is poisoned
                # and the later query/commit raises TransactionManagementError.
                Order.objects.bulk_create([good])
            results.append({"order_id": str(order.id), "success": True})

        with transaction.atomic():  # mimic the view's outer @transaction.atomic
            results, errors = _run_per_order_bulk(
                Order.objects.filter(pk__in=[good.pk, bad.pk]), handler
            )
            # Connection still usable after the failing order — without the
            # savepoint this query raises TransactionManagementError.
            assert Order.objects.filter(pk=good.pk).exists()

        result_ids = {r["order_id"] for r in results}
        assert str(good.id) in result_ids  # the good order committed
        assert str(bad.id) not in result_ids  # the bad order rolled back
        assert any(e["order_id"] == str(bad.id) for e in errors)


# ---------------------------------------------------------------------------
# BulkSetToPaidDocumentsView
# ---------------------------------------------------------------------------
URL_SET_TO_PAID = reverse("bulk_set_to_paid_documents")


@pytest.mark.django_db
class TestBulkSetToPaidDocumentsView:
    def test_only_invoice_model_accepted(self, api_client, tenant):
        resp = api_client.post(
            URL_SET_TO_PAID,
            {"ids": ["x"], "model": "delivery_note"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_empty_ids_returns_400(self, api_client, tenant):
        resp = api_client.post(
            URL_SET_TO_PAID,
            {"ids": [], "model": "invoice"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_no_orders_returns_404(self, api_client, tenant):
        resp = api_client.post(
            URL_SET_TO_PAID,
            {
                "ids": ["00000000-0000-0000-0000-000000000000"],
                "model": "invoice",
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND

    def test_summary_invoice_spanning_orders_no_spurious_already_paid(
        self, api_client, tenant
    ):
        """Several orders sharing ONE summary invoice, set-to-paid in one
        batch, report one success per order — not 1 success + N-1 spurious
        'already paid' failures."""
        from apps.commissioning.services import InvoiceService
        from apps.commissioning.tests.tests_services.test_invoice_service import (
            _finalized_delivery_note,
        )

        reseller = ResellerFactory()
        dn1 = _finalized_delivery_note(tenant, reseller=reseller, delivery_week=15)
        dn2 = _finalized_delivery_note(tenant, reseller=reseller, delivery_week=16)
        InvoiceService.create_summary_invoice_from_delivery_notes([dn1, dn2])

        resp = api_client.post(
            URL_SET_TO_PAID,
            {
                "ids": [str(dn1.order.id), str(dn2.order.id)],
                "model": "invoice",
            },
            format="json",
        )

        assert resp.status_code in (status.HTTP_200_OK, status.HTTP_207_MULTI_STATUS)
        assert resp.data["successful"] == 2
        assert resp.data["failed"] == 0


# ---------------------------------------------------------------------------
# BulkCreateDocumentsFromOrdersView
# ---------------------------------------------------------------------------
URL_CREATE_DOCS = reverse("bulk_create_documents_from_orders")


@pytest.mark.django_db
class TestBulkCreateDocumentsFromOrdersView:
    def test_creates_delivery_notes_from_orders(self, api_client, tenant):
        """Happy path: a fresh order without a DN gets a new DN created."""
        reseller = ResellerFactory()
        order = OrderFactory(reseller=reseller)
        OrderContentFactory(order=order)

        resp = api_client.post(
            URL_CREATE_DOCS,
            {
                "ids": [str(order.id)],
                "model": "delivery_note",
                "date": "2026-05-25",
            },
            format="json",
        )
        # 201 on full success, 207 if any per-order error occurred.
        assert resp.status_code in (
            status.HTTP_201_CREATED,
            status.HTTP_207_MULTI_STATUS,
        )
        assert resp.data["model"] == "delivery_note"
        assert resp.data["total_processed"] == 1
        # Either it succeeded (DN created) or the failure surfaces in errors;
        # both shapes are accepted to keep this tolerant of service-layer
        # invariants (e.g. missing prices) that aren't the point of this test.
        assert resp.data["successful"] + resp.data["failed"] == 1

    def test_no_orders_returns_404(self, api_client, tenant):
        resp = api_client.post(
            URL_CREATE_DOCS,
            {
                "ids": ["00000000-0000-0000-0000-000000000000"],
                "model": "delivery_note",
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND

    def test_missing_model_returns_400(self, api_client, tenant):
        resp = api_client.post(URL_CREATE_DOCS, {"ids": ["x"]}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST


# ---------------------------------------------------------------------------
# BulkCreateSummaryInvoiceFromOrdersView
# ---------------------------------------------------------------------------
URL_SUMMARY_INVOICE = reverse("bulk_create_summary_invoice_from_orders")


@pytest.mark.django_db
class TestBulkCreateSummaryInvoiceFromOrdersView:
    def test_empty_ids_returns_error(self, api_client, tenant):
        resp = api_client.post(URL_SUMMARY_INVOICE, {"ids": []}, format="json")
        assert resp.status_code in (
            status.HTTP_400_BAD_REQUEST,
            status.HTTP_422_UNPROCESSABLE_ENTITY,
        )

    def test_no_orders_returns_404(self, api_client, tenant):
        resp = api_client.post(
            URL_SUMMARY_INVOICE,
            {"ids": ["00000000-0000-0000-0000-000000000000"]},
            format="json",
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND

    def test_order_without_delivery_note_fails(self, api_client, tenant):
        """Orders without a DN can't be summarized — must surface as a
        ``summary_invoice.no_valid_dns`` error rather than crash."""
        reseller = ResellerFactory()
        order = OrderFactory(reseller=reseller)  # no DN
        OrderContentFactory(order=order)

        resp = api_client.post(
            URL_SUMMARY_INVOICE, {"ids": [str(order.id)]}, format="json"
        )
        assert resp.status_code in (
            status.HTTP_400_BAD_REQUEST,
            status.HTTP_422_UNPROCESSABLE_ENTITY,
        )


# ---------------------------------------------------------------------------
# SetOrderNoteView
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestSetOrderNoteView:
    def test_sets_note(self, api_client, tenant):
        from apps.commissioning.models import Order

        reseller = ResellerFactory()
        order = OrderFactory(reseller=reseller)

        url = reverse("set_order_note", args=[str(order.id)])
        resp = api_client.patch(url, {"note": "ring twice at the gate"}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["note"] == "ring twice at the gate"
        order_db = Order.objects.get(pk=order.pk)
        assert order_db.note == "ring twice at the gate"

    def test_unknown_order_returns_404(self, api_client, tenant):
        url = reverse("set_order_note", args=["00000000-0000-0000-0000-000000000000"])
        resp = api_client.patch(url, {"note": "anything"}, format="json")
        assert resp.status_code == status.HTTP_404_NOT_FOUND

    def test_note_longer_than_the_column_returns_400(self, api_client, tenant):
        """``Order.note`` is CharField(max_length=500). An over-long note used
        to reach Postgres and come back as a generic data error; the request
        serializer now names the field and nothing is written."""
        order = OrderFactory(reseller=ResellerFactory(), note="keep me")

        url = reverse("set_order_note", args=[str(order.id)])
        resp = api_client.patch(url, {"note": "x" * 501}, format="json")

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "note" in resp.data["details"]
        assert Order.objects.get(pk=order.pk).note == "keep me"

    def test_note_at_the_column_limit_is_accepted(self, api_client, tenant):
        order = OrderFactory(reseller=ResellerFactory())

        url = reverse("set_order_note", args=[str(order.id)])
        resp = api_client.patch(url, {"note": "x" * 500}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert Order.objects.get(pk=order.pk).note == "x" * 500

    def test_blank_note_still_clears_it(self, api_client, tenant):
        """The office autosave sends an empty string for an emptied box —
        adding the serializer must not turn that into a 400."""
        order = OrderFactory(reseller=ResellerFactory(), note="previous")

        url = reverse("set_order_note", args=[str(order.id)])
        resp = api_client.patch(url, {"note": ""}, format="json")

        assert resp.status_code == status.HTTP_200_OK
        assert Order.objects.get(pk=order.pk).note == ""


# ---------------------------------------------------------------------------
# CreateOffersView
# ---------------------------------------------------------------------------
URL_CREATE_OFFERS = reverse("create_offers")


@pytest.mark.django_db
class TestCreateOffersView:
    def test_missing_params_returns_400(self, api_client, tenant):
        resp = api_client.post(URL_CREATE_OFFERS, {}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_empty_week_returns_200_with_zero_counts(self, api_client, tenant):
        """A week with no forecasts / share contents → no offers created.
        Service returns ``success=False`` with counts at 0; view returns 200."""
        resp = api_client.post(
            URL_CREATE_OFFERS,
            {"year": 2099, "delivery_week": 1},
            format="json",
        )
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["success"] is False
        assert resp.data["created_count"] == 0
        assert resp.data["skipped_count"] == 0


# ---------------------------------------------------------------------------
# offer_sending_status
# ---------------------------------------------------------------------------
URL_OFFER_SENDING_STATUS = reverse("offer_sending_status")


@pytest.mark.django_db
class TestOfferSendingStatus:
    def test_missing_params_raises(self, api_client, tenant):
        resp = api_client.get(URL_OFFER_SENDING_STATUS)
        # CommissioningError → 400 via the DRF exception handler.
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_unknown_offer_group_returns_404(self, api_client, tenant):
        resp = api_client.get(
            URL_OFFER_SENDING_STATUS,
            {
                "year": 2026,
                "delivery_week": 15,
                "offer_group": "00000000-0000-0000-0000-000000000000",
            },
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND

    def test_returns_resellers_in_group(self, api_client, tenant):
        """All resellers in the offer-group are listed, with ``sent=False``
        when no ``OfferSending`` row exists for them yet."""
        offer_group = OfferGroupFactory()
        # Two resellers belonging to the group, one outside.
        r_in_1 = ResellerFactory()
        r_in_2 = ResellerFactory()
        r_out = ResellerFactory()
        offer_group.reseller_set.add(r_in_1, r_in_2)

        resp = api_client.get(
            URL_OFFER_SENDING_STATUS,
            {
                "year": 2026,
                "delivery_week": 15,
                "offer_group": str(offer_group.id),
            },
        )
        assert resp.status_code == status.HTTP_200_OK
        ids = {entry["id"] for entry in resp.data}
        assert r_in_1.id in ids
        assert r_in_2.id in ids
        assert r_out.id not in ids
        assert all(entry["sent"] is False for entry in resp.data)

    def test_returns_sent_true_when_offersending_row_exists(self, api_client, tenant):
        """When an ``OfferSending`` row exists for a (group, year,
        week, reseller) tuple, the matching response entry has
        ``sent=True`` and a non-null ``sent_at``. The view filters on the
        composite-key columns directly, not via an Offer JOIN."""
        from apps.commissioning.models import OfferSending

        offer_group = OfferGroupFactory()
        r_sent = ResellerFactory()
        r_unsent = ResellerFactory()
        offer_group.reseller_set.add(r_sent, r_unsent)

        OfferSending.objects.create(
            offer_group=offer_group,
            year=2026,
            delivery_week=15,
            reseller=r_sent,
        )

        resp = api_client.get(
            URL_OFFER_SENDING_STATUS,
            {
                "year": 2026,
                "delivery_week": 15,
                "offer_group": str(offer_group.id),
            },
        )
        assert resp.status_code == status.HTTP_200_OK
        by_id = {entry["id"]: entry for entry in resp.data}
        assert by_id[r_sent.id]["sent"] is True
        assert by_id[r_sent.id]["sent_at"] is not None
        assert by_id[r_unsent.id]["sent"] is False
        assert by_id[r_unsent.id]["sent_at"] is None

    def test_unique_composite_key_blocks_duplicate(self, tenant):
        """The ``UniqueConstraint`` on
        ``(offer_group, year, delivery_week, reseller)`` is the
        defense-in-depth backstop for the service's ``.exists()``
        pre-check. A second ``.create()`` with the same composite
        key MUST raise ``IntegrityError`` so a buggy / racing caller
        can't silently double-record a send."""
        from django.db import IntegrityError

        from apps.commissioning.models import OfferSending

        offer_group = OfferGroupFactory()
        reseller = ResellerFactory()
        offer_group.reseller_set.add(reseller)

        OfferSending.objects.create(
            offer_group=offer_group,
            year=2026,
            delivery_week=15,
            reseller=reseller,
        )
        with pytest.raises(IntegrityError):
            OfferSending.objects.create(
                offer_group=offer_group,
                year=2026,
                delivery_week=15,
                reseller=reseller,
            )


# ---------------------------------------------------------------------------
# BulkSendInvoiceRemindersViaEmailView  (validation only — happy path
# requires a configured SMTP backend that's out of scope for unit tests)
# ---------------------------------------------------------------------------
URL_SEND_REMINDERS = reverse("bulk_send_invoice_reminders_via_email")


@pytest.mark.django_db
class TestBulkSendInvoiceRemindersViaEmail:
    """View-layer tests for the enqueue endpoint. The actual SMTP
    work + grouping logic live in ``invoice_reminder.
    bulk_send_invoice_reminders`` and is covered separately under
    ``tests_services/test_invoice_reminder_service.py``.

    These tests verify the 202+job_id contract and that the view
    validates its inputs synchronously before enqueueing.
    """

    def test_missing_model_returns_400(self, step_up_client, tenant):
        resp = step_up_client.post(URL_SEND_REMINDERS, {"ids": ["x"]}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_empty_ids_returns_400(self, step_up_client, tenant):
        resp = step_up_client.post(
            URL_SEND_REMINDERS,
            {"ids": [], "model": "invoice"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_valid_payload_returns_202_and_creates_job(self, step_up_client, tenant):
        """Happy-path view contract: payload validates, a
        ``BackgroundJob`` row is created in ``queued`` state, and the
        response is a 202 with the job id. The actual SMTP / order
        resolution happens in the worker (covered by service tests),
        not here.
        """
        from apps.notifications.models import BackgroundJob

        before = BackgroundJob.objects.count()
        resp = step_up_client.post(
            URL_SEND_REMINDERS,
            {
                "ids": ["00000000-0000-0000-0000-000000000000"],
                "model": "invoice",
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_202_ACCEPTED
        assert resp.data["kind"] == "invoice_reminder.bulk_send"
        assert resp.data["status"] == "queued"
        assert BackgroundJob.objects.count() == before + 1
        job = BackgroundJob.objects.get(pk=resp.data["job_id"])
        assert job.kind == "invoice_reminder.bulk_send"
        assert job.status == "queued"


# ---------------------------------------------------------------------------
# BulkSendDocumentsViaEmailView (enqueue contract; the send is a service test)
# ---------------------------------------------------------------------------
URL_SEND_DOCUMENTS = reverse("bulk_send_documents_via_email")


@pytest.mark.django_db
class TestBulkSendDocumentsViaEmail:
    @pytest.mark.parametrize("model", ["invoice", "delivery_note"])
    def test_enqueues_a_job(self, step_up_client, tenant, email_config, model):
        from apps.notifications.models import BackgroundJob

        resp = step_up_client.post(
            URL_SEND_DOCUMENTS, {"ids": ["order-1"], "model": model}, format="json"
        )

        assert resp.status_code == status.HTTP_202_ACCEPTED, resp.data
        assert resp.data["kind"] == f"{model}.bulk_send"
        assert BackgroundJob.objects.get(pk=resp.data["job_id"]).status == "queued"

    def test_requires_step_up(self, api_client, tenant, email_config):
        resp = api_client.post(
            URL_SEND_DOCUMENTS, {"ids": ["order-1"], "model": "invoice"}, format="json"
        )

        assert resp.status_code == status.HTTP_403_FORBIDDEN
        assert resp.data["code"] == "auth.step_up_required"

    def test_refused_without_a_mail_server(self, step_up_client, tenant):
        from apps.notifications.models import BackgroundJob
        from apps.shared.tenants.models import TenantEmailConfig

        TenantEmailConfig.objects.filter(tenant=tenant).delete()
        before = BackgroundJob.objects.count()

        resp = step_up_client.post(
            URL_SEND_DOCUMENTS, {"ids": ["order-1"], "model": "invoice"}, format="json"
        )

        assert resp.status_code == status.HTTP_409_CONFLICT
        assert resp.data["code"] == "email_config.sending_not_set_up"
        assert BackgroundJob.objects.count() == before

    def test_an_unknown_model_is_refused(self, step_up_client, tenant, email_config):
        resp = step_up_client.post(
            URL_SEND_DOCUMENTS, {"ids": ["order-1"], "model": "offer"}, format="json"
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    @pytest.mark.parametrize("bad_id", [123, None, {"id": "x"}])
    def test_a_non_string_id_is_refused(
        self, step_up_client, tenant, email_config, bad_id
    ):
        from apps.notifications.models import BackgroundJob

        before = BackgroundJob.objects.count()

        resp = step_up_client.post(
            URL_SEND_DOCUMENTS,
            {"ids": ["order-1", bad_id], "model": "invoice"},
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "bulk.ids_invalid"
        assert BackgroundJob.objects.count() == before


# ---------------------------------------------------------------------------
# BulkSendOffersViaEmailView (validation + 404 — happy path needs SMTP)
# ---------------------------------------------------------------------------
URL_SEND_OFFERS = reverse("bulk_send_offers_via_email")


@pytest.mark.django_db
class TestBulkSendOffersViaEmail:
    def test_missing_offer_group_returns_400(self, step_up_client, tenant):
        resp = step_up_client.post(
            URL_SEND_OFFERS,
            {"year": 2026, "delivery_week": 15, "reseller_ids": []},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_unknown_offer_group_returns_404(self, step_up_client, tenant):
        # Serializer requires ``reseller_ids`` to be non-empty (min_length=1),
        # so pass a real reseller — otherwise we'd hit 400 from the serializer
        # before the offer_group lookup runs.
        reseller = ResellerFactory()
        resp = step_up_client.post(
            URL_SEND_OFFERS,
            {
                "year": 2026,
                "delivery_week": 15,
                "offer_group": "00000000-0000-0000-0000-000000000000",
                "reseller_ids": [str(reseller.id)],
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND

    def test_valid_payload_returns_202_and_creates_job(self, step_up_client, tenant):
        """Happy-path view contract: payload
        validates, ``OfferGroup`` lookup succeeds, a ``BackgroundJob``
        row is created in ``queued`` state, response is 202 with the
        job id. The actual SMTP work happens in the worker (covered
        by ``OfferService.bulk_send_offers_via_email`` tests).
        """
        from apps.commissioning.tests.factories import OfferGroupFactory
        from apps.notifications.models import BackgroundJob

        offer_group = OfferGroupFactory()
        reseller = ResellerFactory()

        before = BackgroundJob.objects.count()
        resp = step_up_client.post(
            URL_SEND_OFFERS,
            {
                "year": 2026,
                "delivery_week": 15,
                "offer_group": str(offer_group.id),
                "reseller_ids": [str(reseller.id)],
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_202_ACCEPTED
        assert resp.data["kind"] == "offer.bulk_send"
        assert resp.data["status"] == "queued"
        assert BackgroundJob.objects.count() == before + 1
        job = BackgroundJob.objects.get(pk=resp.data["job_id"])
        assert job.kind == "offer.bulk_send"
        assert job.status == "queued"


# ---------------------------------------------------------------------------
# BulkFinalizeDocumentsView happy path  (TestBulkFinalizeDocumentsView covers
# the validation branches)
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestBulkFinalizeDocumentsViewHappyPath:
    def test_finalizes_delivery_note(self, api_client, tenant):
        reseller = ResellerFactory()
        order = OrderFactory(reseller=reseller)
        dn = DeliveryNoteResellerFactory(order=order)
        # DN must have at least one item — ``DeliveryNoteService.finalize_delivery_note``
        # refuses to finalize an empty DN with "Cannot finalize delivery note
        # - it has no items".
        DeliveryNoteContentFactory(delivery_note=dn)
        assert dn.is_finalized is False

        resp = api_client.post(
            URL_FINALIZE_DOCS,
            {"ids": [str(order.id)], "model": "delivery_note"},
            format="json",
        )
        assert resp.status_code in (status.HTTP_200_OK, status.HTTP_207_MULTI_STATUS)
        # Service flips ``is_finalized`` on success; tolerate the 207 branch
        # (per-order errors not under test here) but require finalize WAS
        # attempted on the right model.
        assert resp.data["model"] == "delivery_note"
        assert resp.data["total_processed"] == 1


# ---------------------------------------------------------------------------
# Unknown order ids in a bulk batch
# ---------------------------------------------------------------------------
UNKNOWN_ORDER_ID = "no-such-order"


def _reports_unknown_id(response) -> bool:
    return any(
        row["order_id"] == UNKNOWN_ORDER_ID and row["error"] == "Order not found"
        for row in response.data.get("errors", [])
    )


@pytest.mark.django_db
class TestBulkUnknownOrderIdsAreReported:
    """An id matching no order gets its own error row on every bulk endpoint,
    so ``successful + failed`` adds up to ``total_processed`` instead of
    silently falling short."""

    def test_create_documents(self, api_client, tenant):
        order = OrderFactory(reseller=ResellerFactory())
        OrderContentFactory(order=order)

        resp = api_client.post(
            URL_CREATE_DOCS,
            {"ids": [str(order.id), UNKNOWN_ORDER_ID], "model": "delivery_note"},
            format="json",
        )

        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["total_processed"] == 2
        assert resp.data["successful"] + resp.data["failed"] == 2
        assert _reports_unknown_id(resp)

    def test_finalize_documents(self, api_client, tenant):
        order = OrderFactory(reseller=ResellerFactory())
        delivery_note = DeliveryNoteResellerFactory(order=order)
        DeliveryNoteContentFactory(delivery_note=delivery_note)

        resp = api_client.post(
            URL_FINALIZE_DOCS,
            {"ids": [str(order.id), UNKNOWN_ORDER_ID], "model": "delivery_note"},
            format="json",
        )

        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["total_processed"] == 2
        assert resp.data["successful"] + resp.data["failed"] == 2
        assert _reports_unknown_id(resp)

    def test_delete_documents(self, api_client, tenant):
        order = OrderFactory(reseller=ResellerFactory())
        DeliveryNoteResellerFactory(order=order)

        resp = api_client.post(
            URL_DELETE_DOCS,
            {"ids": [str(order.id), UNKNOWN_ORDER_ID], "model": "delivery_note"},
            format="json",
        )

        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["total_processed"] == 2
        assert resp.data["successful"] + resp.data["failed"] == 2
        assert _reports_unknown_id(resp)

    def test_set_to_paid(self, api_client, tenant):
        from apps.commissioning.services import InvoiceService
        from apps.commissioning.tests.tests_services.test_invoice_service import (
            _finalized_delivery_note,
        )

        delivery_note = _finalized_delivery_note(
            tenant, reseller=ResellerFactory(), delivery_week=15
        )
        InvoiceService.create_summary_invoice_from_delivery_notes([delivery_note])

        resp = api_client.post(
            URL_SET_TO_PAID,
            {
                "ids": [str(delivery_note.order.id), UNKNOWN_ORDER_ID],
                "model": "invoice",
            },
            format="json",
        )

        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["total_processed"] == 2
        assert resp.data["successful"] + resp.data["failed"] == 2
        assert _reports_unknown_id(resp)

    def test_summary_invoice(self, api_client, tenant):
        from apps.commissioning.tests.tests_services.test_invoice_service import (
            _finalized_delivery_note,
        )

        delivery_note = _finalized_delivery_note(
            tenant, reseller=ResellerFactory(), delivery_week=15
        )

        resp = api_client.post(
            URL_SUMMARY_INVOICE,
            {"ids": [str(delivery_note.order.id), UNKNOWN_ORDER_ID]},
            format="json",
        )

        assert resp.status_code == status.HTTP_207_MULTI_STATUS
        assert resp.data["total_orders_included"] == 1
        assert _reports_unknown_id(resp)


@pytest.mark.django_db
class TestBulkRepeatedOrderIdsCountOnce:
    """One id means one order means one row, so a repeated id is collapsed and
    ``total_processed`` still matches ``successful + failed``."""

    def test_create_documents(self, api_client, tenant):
        order = OrderFactory(reseller=ResellerFactory())
        OrderContentFactory(order=order)

        resp = api_client.post(
            URL_CREATE_DOCS,
            {"ids": [str(order.id), str(order.id)], "model": "delivery_note"},
            format="json",
        )

        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert resp.data["total_processed"] == 1
        assert resp.data["successful"] + resp.data["failed"] == 1
        assert DeliveryNoteReseller.objects.filter(order=order).count() == 1

    def test_delete_documents(self, api_client, tenant):
        order = OrderFactory(reseller=ResellerFactory())
        DeliveryNoteResellerFactory(order=order)

        resp = api_client.post(
            URL_DELETE_DOCS,
            {"ids": [str(order.id), str(order.id)], "model": "delivery_note"},
            format="json",
        )

        assert resp.status_code == status.HTTP_200_OK, resp.data
        assert resp.data["total_processed"] == 1
        assert resp.data["successful"] + resp.data["failed"] == 1


# ---------------------------------------------------------------------------
# Summary invoice date
# ---------------------------------------------------------------------------
@pytest.mark.django_db
class TestBulkCreateSummaryInvoiceDate:
    def _delivery_note(self, tenant):
        from apps.commissioning.tests.tests_services.test_invoice_service import (
            _finalized_delivery_note,
        )

        return _finalized_delivery_note(
            tenant, reseller=ResellerFactory(), delivery_week=15
        )

    def test_malformed_date_is_refused(self, api_client, tenant):
        delivery_note = self._delivery_note(tenant)
        invoices_before = InvoiceReseller.objects.count()

        resp = api_client.post(
            URL_SUMMARY_INVOICE,
            {"ids": [str(delivery_note.order.id)], "date": "2026-13-45"},
            format="json",
        )

        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "summary_invoice.date_format"
        assert InvoiceReseller.objects.count() == invoices_before

    def test_valid_date_is_used(self, api_client, tenant):
        delivery_note = self._delivery_note(tenant)

        resp = api_client.post(
            URL_SUMMARY_INVOICE,
            {"ids": [str(delivery_note.order.id)], "date": "2026-05-25"},
            format="json",
        )

        assert resp.status_code == status.HTTP_201_CREATED
        invoice = InvoiceReseller.objects.get(pk=resp.data["invoice_id"])
        assert str(invoice.date) == "2026-05-25"

    def test_absent_date_is_derived(self, api_client, tenant):
        delivery_note = self._delivery_note(tenant)

        resp = api_client.post(
            URL_SUMMARY_INVOICE,
            {"ids": [str(delivery_note.order.id)]},
            format="json",
        )

        assert resp.status_code == status.HTTP_201_CREATED
        invoice = InvoiceReseller.objects.get(pk=resp.data["invoice_id"])
        assert invoice.date is not None
