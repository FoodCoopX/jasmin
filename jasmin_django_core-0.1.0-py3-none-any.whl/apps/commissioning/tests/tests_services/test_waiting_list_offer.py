"""Waiting-list offer flow: office offers a freed spot, member accepts/declines
via magic link, and an offered/accepted spot HOLDS capacity so it can't be
sniped during the response window.

The station-day reservation + the offer email are mocked here — this suite
covers the offer state machine and the variation status-counted hold. The DSD
reservation itself is covered by ``test_capacity_reservation.py``.
"""

from __future__ import annotations

import datetime
from unittest import mock

import pytest
import time_machine
from django.utils import timezone

from apps.commissioning.errors import (
    WaitingListOfferExpired,
    WaitingListOfferInvalid,
    WaitingListOfferMemberHasNoEmail,
    WaitingListOfferNotAvailable,
)
from apps.commissioning.models import Member, Subscription
from apps.commissioning.services.variation_capacity_service import (
    VariationCapacityService,
)
from apps.commissioning.services.waiting_list_offer_service import (
    WaitingListOfferService,
)
from apps.commissioning.tests.factories import (
    DeliveryStationDayFactory,
    ShareTypeVariationFactory,
    SubscriptionFactory,
)

_SPAN = {
    "valid_from": datetime.date(2026, 1, 5),  # Monday
    "valid_until": datetime.date(2027, 1, 3),  # Sunday
}


@pytest.fixture
def dsd():
    return DeliveryStationDayFactory()


# The instant the whole module runs at. ``_SPAN`` brackets it, so an offered
# term reads as live no matter how far the real clock has moved on.
_NOW = datetime.datetime(2026, 7, 20, 12, 0)


@pytest.fixture(autouse=True)
def _mock_holds_and_email():
    """Isolate the offer state machine: stub the DSD reservation (own suite) and
    the deferred email so tests don't need harvest/DSD capacity or SMTP, and pin
    the clock so the term the subscriptions are built on stays current."""
    with (
        time_machine.travel(_NOW, tick=False),
        mock.patch.object(
            WaitingListOfferService, "_send_offer_email", return_value=None
        ),
        mock.patch(
            "apps.commissioning.services.waiting_list_offer_service."
            "CapacityReservationService.reserve_for_subscription",
            return_value=None,
        ),
        mock.patch(
            "apps.commissioning.services.waiting_list_offer_service."
            "CapacityReservationService.release_for_subscription",
            return_value=None,
        ),
    ):
        yield


def _pending(variation, dsd, quantity=1):
    return SubscriptionFactory(
        share_type_variation=variation,
        default_delivery_station_day=dsd,
        quantity=quantity,
        admin_confirmed=False,
        on_waiting_list=True,
        waiting_list_status=Subscription.WaitingListStatus.PENDING,
        **_SPAN,
    )


@pytest.mark.django_db
class TestWaitingListOffer:
    def test_offer_requires_pending_entry(self, tenant, dsd):
        variation = ShareTypeVariationFactory(capacity=5)
        # An ordinary (non-waiting_list) draft can't be offered.
        sub = SubscriptionFactory(
            share_type_variation=variation,
            default_delivery_station_day=dsd,
            admin_confirmed=False,
            **_SPAN,
        )
        with pytest.raises(WaitingListOfferNotAvailable):
            WaitingListOfferService.offer_spot(sub)

    def test_a_member_without_an_email_is_refused(self, tenant, dsd):
        # Only the email carries the offer link: the slot would stay on hold
        # for someone who is never told.
        variation = ShareTypeVariationFactory(capacity=5)
        sub = _pending(variation, dsd)
        Member.objects.filter(pk=sub.member_id).update(email="")

        with pytest.raises(WaitingListOfferMemberHasNoEmail):
            WaitingListOfferService.offer_spot(Subscription.objects.get(pk=sub.pk))

        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.PENDING
        assert sub.notification_token is None

    def test_offer_sets_spot_available_with_token(self, tenant, dsd):
        variation = ShareTypeVariationFactory(capacity=5)
        sub = _pending(variation, dsd)
        WaitingListOfferService.offer_spot(sub)
        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.SPOT_AVAILABLE
        assert sub.on_waiting_list is True
        assert sub.notification_token is not None
        assert sub.notification_expires_at is not None

    def test_offer_holds_the_variation_slot(self, tenant, dsd):
        # cap 1, nothing confirmed → free. Offering the last slot must HOLD it,
        # so a fresh subscribe now reads the variation as full.
        variation = ShareTypeVariationFactory(capacity=1)
        queued = _pending(variation, dsd)
        WaitingListOfferService.offer_spot(queued)

        newcomer = SubscriptionFactory(
            share_type_variation=variation,
            default_delivery_station_day=dsd,
            admin_confirmed=True,
            **_SPAN,
        )
        assert VariationCapacityService.is_over_capacity(newcomer) is True

    def test_offer_applies_office_price(self, tenant, dsd):
        from decimal import Decimal

        variation = ShareTypeVariationFactory(capacity=5)
        sub = _pending(variation, dsd)
        WaitingListOfferService.offer_spot(sub, price_per_delivery="12.50")
        sub.refresh_from_db()
        assert sub.price_per_delivery == Decimal("12.50")

    def test_accept_leaves_waiting_list_as_unconfirmed_draft(self, tenant, dsd):
        variation = ShareTypeVariationFactory(capacity=5)
        sub = _pending(variation, dsd)
        WaitingListOfferService.offer_spot(sub)
        token = Subscription.objects.get(pk=sub.pk).notification_token

        WaitingListOfferService.accept_offer(token)
        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.CONFIRMED
        assert sub.on_waiting_list is False
        assert sub.admin_confirmed is False  # still needs office admin-confirm
        assert sub.notification_token is None  # link consumed

    def test_accepted_pending_still_holds_the_slot(self, tenant, dsd):
        variation = ShareTypeVariationFactory(capacity=1)
        sub = _pending(variation, dsd)
        WaitingListOfferService.offer_spot(sub)
        token = Subscription.objects.get(pk=sub.pk).notification_token
        WaitingListOfferService.accept_offer(
            token
        )  # now CONFIRMED, not admin-confirmed

        newcomer = SubscriptionFactory(
            share_type_variation=variation,
            default_delivery_station_day=dsd,
            admin_confirmed=True,
            **_SPAN,
        )
        assert VariationCapacityService.is_over_capacity(newcomer) is True

    def test_decline_frees_the_slot(self, tenant, dsd):
        variation = ShareTypeVariationFactory(capacity=1)
        sub = _pending(variation, dsd)
        WaitingListOfferService.offer_spot(sub)
        token = Subscription.objects.get(pk=sub.pk).notification_token

        WaitingListOfferService.decline_offer(token)
        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.DECLINED
        assert sub.on_waiting_list is False

        newcomer = SubscriptionFactory(
            share_type_variation=variation,
            default_delivery_station_day=dsd,
            admin_confirmed=True,
            **_SPAN,
        )
        assert VariationCapacityService.is_over_capacity(newcomer) is False

    def test_accept_after_window_raises_and_expires(self, tenant, dsd):
        variation = ShareTypeVariationFactory(capacity=5)
        sub = _pending(variation, dsd)
        WaitingListOfferService.offer_spot(sub)
        # Backdate the window so the offer has lapsed.
        # A real lapsed offer keeps sent_at <= expires_at (both in the past);
        # backdate both so the mixin's clean() stays valid on the expiry save.
        Subscription.objects.filter(pk=sub.pk).update(
            notification_sent_at=timezone.now() - datetime.timedelta(days=8),
            notification_expires_at=timezone.now() - datetime.timedelta(days=1),
        )
        token = Subscription.objects.get(pk=sub.pk).notification_token
        with pytest.raises(WaitingListOfferExpired):
            WaitingListOfferService.accept_offer(token)
        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.EXPIRED

    def test_unknown_token_is_invalid(self, tenant):
        import uuid

        with pytest.raises(WaitingListOfferInvalid):
            WaitingListOfferService.accept_offer(uuid.uuid4())

    def test_expire_stale_offers_sweep(self, tenant, dsd):
        variation = ShareTypeVariationFactory(capacity=5)
        sub = _pending(variation, dsd)
        WaitingListOfferService.offer_spot(sub)
        # A real lapsed offer keeps sent_at <= expires_at (both in the past);
        # backdate both so the mixin's clean() stays valid on the expiry save.
        Subscription.objects.filter(pk=sub.pk).update(
            notification_sent_at=timezone.now() - datetime.timedelta(days=8),
            notification_expires_at=timezone.now() - datetime.timedelta(days=1),
        )
        assert WaitingListOfferService.expire_stale_offers() == 1
        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.EXPIRED


@pytest.mark.django_db
class TestWaitingListOfferPriceRules:
    """``offer_spot`` writes the price the member accepts, so it applies the
    same non-negative bound and solidarity floor as the subscription serializer.
    The floor is resolved at the subscription's start (``_SPAN``), not today."""

    def _enable_solidarity(self, tenant):
        from apps.shared.tenants.models import TenantSettings

        TenantSettings.objects.create(
            tenant=tenant,
            valid_from=timezone.now() - datetime.timedelta(seconds=1),
            allows_solidarity_pricing=True,
        )

    def _variation_with_floor(self):
        from decimal import Decimal

        from apps.commissioning.tests.factories.shares import (
            ShareTypeVariationGrossPriceFactory,
        )

        variation = ShareTypeVariationFactory(capacity=5)
        ShareTypeVariationGrossPriceFactory(
            share_type_variation=variation,
            valid_from=_SPAN["valid_from"],
            price_per_delivery=Decimal("10.00"),
            solidarity_min_price_per_delivery=Decimal("7.00"),
        )
        return variation

    def test_offer_below_the_solidarity_floor_is_refused(self, tenant, dsd):
        from apps.commissioning.errors import SolidarityPriceBelowMinimum

        self._enable_solidarity(tenant)
        sub = _pending(self._variation_with_floor(), dsd)

        with pytest.raises(SolidarityPriceBelowMinimum):
            WaitingListOfferService.offer_spot(sub, price_per_delivery="6.00")

        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.PENDING
        assert sub.price_per_delivery is None

    def test_offer_keeping_a_stored_price_below_the_floor_is_refused(self, tenant, dsd):
        from decimal import Decimal

        from apps.commissioning.errors import SolidarityPriceBelowMinimum

        self._enable_solidarity(tenant)
        sub = _pending(self._variation_with_floor(), dsd)
        Subscription.objects.filter(pk=sub.pk).update(
            price_per_delivery=Decimal("6.00")
        )
        sub.refresh_from_db()

        with pytest.raises(SolidarityPriceBelowMinimum):
            WaitingListOfferService.offer_spot(sub)

        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.PENDING

    def test_offer_at_the_floor_is_sent(self, tenant, dsd):
        from decimal import Decimal

        self._enable_solidarity(tenant)
        sub = _pending(self._variation_with_floor(), dsd)

        WaitingListOfferService.offer_spot(sub, price_per_delivery="7.00")

        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.SPOT_AVAILABLE
        assert sub.price_per_delivery == Decimal("7.00")

    @pytest.mark.parametrize("price", ["-1", "abc", "NaN"])
    def test_offer_with_an_invalid_price_is_refused(self, tenant, dsd, price):
        from apps.commissioning.errors import SubscriptionPriceInvalid

        sub = _pending(ShareTypeVariationFactory(capacity=5), dsd)

        with pytest.raises(SubscriptionPriceInvalid):
            WaitingListOfferService.offer_spot(sub, price_per_delivery=price)

        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.PENDING
        assert sub.price_per_delivery is None

    @pytest.mark.parametrize(
        "price",
        [
            "12345678.00",  # more than the six digits before the point
            "1e6",  # the same overflow in exponent notation
            "10.999",  # a third decimal the write would round away
            " 12.345 ",  # ... and surrounded by whitespace
            "999999.995",  # in range until it rounds up out of it
        ],
    )
    def test_offer_outside_the_column_bounds_is_refused(self, tenant, dsd, price):
        """A caller that isn't the endpoint is held to ``numeric(8, 2)`` too."""
        from apps.commissioning.errors import SubscriptionPriceInvalid

        sub = _pending(ShareTypeVariationFactory(capacity=5), dsd)

        with pytest.raises(SubscriptionPriceInvalid):
            WaitingListOfferService.offer_spot(sub, price_per_delivery=price)

        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.PENDING
        assert sub.price_per_delivery is None

    def test_offer_at_the_widest_storable_amount_is_sent(self, tenant, dsd):
        """The bound is the column's, not a stricter one: the largest amount
        ``numeric(8, 2)`` holds still goes out."""
        from decimal import Decimal

        sub = _pending(ShareTypeVariationFactory(capacity=5), dsd)

        WaitingListOfferService.offer_spot(sub, price_per_delivery="999999.99")

        sub.refresh_from_db()
        assert sub.waiting_list_status == Subscription.WaitingListStatus.SPOT_AVAILABLE
        assert sub.price_per_delivery == Decimal("999999.99")
