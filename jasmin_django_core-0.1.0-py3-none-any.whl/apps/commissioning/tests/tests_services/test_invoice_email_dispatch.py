"""Tests for ``InvoiceService.send_to_reseller`` /
``send_to_accounting``.

Contract:

  * Both helpers are best-effort: a transient SMTP failure must NOT
    raise, because the invoice was already legally finalized in a
    prior transaction (UStG §14 / GoBD: invoices are one-way
    finalized) and a downstream email error must not roll that back.
  * On success the matching ``*_at`` timestamp is stamped:
        send_to_reseller   -> has_been_sent_to_reseller_at
        send_to_accounting -> has_been_sent_to_accounting_at
    ``has_been_sent_to_reseller`` and
    ``has_been_sent_to_accounting`` are derived @properties (True
    iff the matching timestamp is set).
  * The timestamp write uses ``ALLOWED_FINALIZED_UPDATES`` on
    ``InvoiceReseller`` — listed there explicitly, so a regular
    ``invoice.save(update_fields=[...])`` works post-finalize.
  * Short-circuit cases that MUST return False without sending:
      - No ``reseller.invoice_email``  (reseller-side)
      - No ``TenantEmailConfig.accounting_email``  (accounting-side)
      - No ``invoice.file``  (PDF hasn't been uploaded yet)
  * ``upload_pdf`` stamps only the sends that will happen, and a send that
    fails releases its stamp, so an invoice never reads as sent when it
    wasn't. The office sends again through the ``send_to_reseller`` /
    ``send_to_accounting`` actions.

We patch ``EmailService.send_email`` with ``autospec=True`` so the
mock keeps the same ``self`` binding as the real method — a plain
``mock.patch`` would hide a call made on the class instead of an
instance (same protection as
``test_reseller_views.py::TestBulkSendInvoiceRemindersViaEmail``).
"""

from __future__ import annotations

import datetime
import smtplib
from decimal import Decimal
from unittest import mock

import pytest
from django.core.files.uploadedfile import SimpleUploadedFile

from apps.commissioning.models import InvoiceReseller
from apps.commissioning.services.invoice_service import InvoiceService
from apps.commissioning.tests.factories import (
    InvoiceResellerFactory,
    ResellerFactory,
)
from apps.shared.tenants.email_service import EmailService
from apps.shared.tenants.models import TenantEmailConfig
from core.tenant_db import connection

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


def _attach_pdf(
    invoice, name: str = "rechnung.pdf", body: bytes = b"%PDF-1.4 test"
) -> None:
    """Attach a stub PDF to ``invoice.file`` so the email helpers see
    a file to read. The bytes don't have to be a valid PDF — the
    helpers only ``.read()`` them."""
    invoice.file = SimpleUploadedFile(name, body, content_type="application/pdf")
    invoice.save(update_fields=["file"])


@pytest.fixture
def reseller_with_email():
    return ResellerFactory(invoice_email="reseller@example.org")


@pytest.fixture
def finalized_invoice_with_pdf(reseller_with_email):
    # ``number`` is an IntegerField on NumberedDocumentMixin, so don't pass
    # a string here. ``prefix`` defaults to ``""`` and ``number`` is
    # nullable — leaving both unset is fine for the
    # email-context smoke test; the rendered subject line just shows
    # an empty number, which is what we'd see if a real invoice were
    # email-sent before ``assign_final_number`` ran. The email body
    # going out is incidental to what we're testing here.
    invoice = InvoiceResellerFactory(
        reseller=reseller_with_email,
        is_finalized=True,
        date=datetime.date(2026, 6, 1),
    )
    _attach_pdf(invoice)
    return invoice


@pytest.fixture
def accounting_email_config(tenant):
    """TenantEmailConfig with a populated ``accounting_email``. Tests
    that need ``send_to_accounting`` to actually try sending need
    this; tests that need the no-config short-circuit branch should
    NOT request it."""
    cfg = TenantEmailConfig.objects.create(
        tenant=tenant,
        smtp_host="localhost",
        smtp_port=25,
        smtp_use_tls=False,
        from_email="noreply@example.org",
        from_name="Test Tenant",
        accounting_email="datev@coop.de",
        is_active=True,
        is_verified=True,
    )
    return cfg


# ---------------------------------------------------------------------------
# send_to_reseller
# ---------------------------------------------------------------------------


def _with_total(amount: str):
    return mock.patch.object(
        InvoiceReseller,
        "sum_brutto",
        new_callable=mock.PropertyMock,
        return_value=Decimal(amount),
    )


@pytest.mark.django_db
class TestInvoiceEmailContextTotal:
    """The invoice email's total is ``sum_brutto`` with the currency, written
    the way the tenant's app writes amounts.

    ``sum_brutto`` is a @property: the context formats its value, and calling
    it as ``sum_brutto()`` would raise a ``TypeError``.
    """

    def test_total_in_the_tenants_number_format_with_its_currency(
        self, tenant, finalized_invoice_with_pdf
    ):
        with _with_total("1234.5"):
            ctx = InvoiceService._build_invoice_email_context(
                finalized_invoice_with_pdf
            )

        assert ctx["invoice"]["total"] == "1.234,50 €"

    def test_another_number_locale_and_currency(
        self, tenant, monkeypatch, finalized_invoice_with_pdf
    ):
        monkeypatch.setattr(connection.tenant, "number_locale", "en-US")
        monkeypatch.setattr(connection.tenant, "currency", "USD")

        with _with_total("1234.5"):
            ctx = InvoiceService._build_invoice_email_context(
                finalized_invoice_with_pdf
            )

        assert ctx["invoice"]["total"] == "$1,234.50"


@pytest.mark.django_db
class TestInvoiceEmailContextDueDate:
    def test_in_the_tenants_date_format(self, tenant, monkeypatch, reseller_with_email):
        monkeypatch.setattr(connection.tenant, "date_format", "YYYY-MM-DD")
        issued = datetime.date(2025, 5, 2)
        invoice = InvoiceResellerFactory(reseller=reseller_with_email, date=issued)

        ctx = InvoiceService._build_invoice_email_context(invoice)

        terms = datetime.timedelta(days=reseller_with_email.get_payment_terms_days())
        assert ctx["invoice"]["due_date"] == (issued + terms).isoformat()

    def test_a_cancellation_has_none(self, tenant, reseller_with_email):
        cancelled = InvoiceResellerFactory(
            reseller=reseller_with_email, date=datetime.date(2025, 5, 2)
        )
        cancellation = InvoiceResellerFactory(
            reseller=reseller_with_email,
            date=datetime.date(2025, 5, 9),
            document_type="storno",
            cancels_invoice=cancelled,
        )

        ctx = InvoiceService._build_invoice_email_context(cancellation)

        assert ctx["invoice"]["due_date"] == ""


@pytest.mark.django_db
class TestInvoiceEmailContextNames:
    def test_bank_details_carry_the_iban_and_the_creditor_bic(
        self, tenant, monkeypatch
    ):
        monkeypatch.setattr(connection.tenant, "iban", "DE89370400440532013000")
        monkeypatch.setattr(connection.tenant, "sepa_creditor_bic", "COBADEFFXXX")
        invoice = InvoiceResellerFactory()

        ctx = InvoiceService._build_invoice_email_context(invoice)

        assert ctx["tenant"]["bank_details"] == ("DE89370400440532013000 / COBADEFFXXX")

    def test_a_reseller_without_any_name_is_greeted_without_one(self, tenant):
        reseller = ResellerFactory(
            contact__company_name="", contact__first_name="", contact__last_name=""
        )
        invoice = InvoiceResellerFactory(reseller=reseller)

        ctx = InvoiceService._build_invoice_email_context(invoice)

        assert ctx["reseller"]["name"] == ""


@pytest.mark.django_db
class TestSendToReseller:
    def test_short_circuits_when_reseller_has_no_invoice_email(self, tenant):
        reseller = ResellerFactory(invoice_email=None)
        invoice = InvoiceResellerFactory(reseller=reseller, is_finalized=True)
        _attach_pdf(invoice)

        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            assert InvoiceService.send_to_reseller(invoice) is False
        assert not send_email.called

        invoice.refresh_from_db()
        assert invoice.has_been_sent_to_reseller is False
        assert invoice.has_been_sent_to_reseller_at is None

    def test_short_circuits_when_reseller_opted_out_of_email(self, tenant):
        """A reseller with a valid invoice_email but invoice_via_email=
        False (paper-only) must NOT be auto-emailed — the gate lives in
        send_to_reseller so every caller (incl. the upload auto-send) honours it."""
        reseller = ResellerFactory(
            invoice_email="reseller@example.org", invoice_via_email=False
        )
        invoice = InvoiceResellerFactory(reseller=reseller, is_finalized=True)
        _attach_pdf(invoice)

        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            assert InvoiceService.send_to_reseller(invoice) is False
        assert not send_email.called

        invoice.refresh_from_db()
        assert invoice.has_been_sent_to_reseller is False
        assert invoice.has_been_sent_to_reseller_at is None

    def test_short_circuits_when_pdf_not_uploaded(self, tenant, reseller_with_email):
        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email, is_finalized=True
        )
        # No ``_attach_pdf`` here on purpose.

        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            assert InvoiceService.send_to_reseller(invoice) is False
        assert not send_email.called

    def test_happy_path_flips_tracker_flags(self, tenant, finalized_invoice_with_pdf):
        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            assert InvoiceService.send_to_reseller(finalized_invoice_with_pdf) is True

        # autospec keeps ``self`` as the first positional arg →
        # asserts the helper hit the method via an instance, not the
        # class.
        assert send_email.called
        bound_self = send_email.call_args.args[0]
        assert isinstance(bound_self, EmailService)
        kwargs = send_email.call_args.kwargs
        assert kwargs["slug"] == "commissioning.invoice"
        assert kwargs["to_emails"] == ["reseller@example.org"]
        assert kwargs["purpose"] == "invoice:reseller"
        assert kwargs["related_object_type"] == "invoice"
        assert len(kwargs["attachments"]) == 1
        filename, body, mimetype = kwargs["attachments"][0]
        assert filename.endswith(".pdf")
        assert mimetype == "application/pdf"
        assert body == b"%PDF-1.4 test"

        finalized_invoice_with_pdf.refresh_from_db()
        assert finalized_invoice_with_pdf.has_been_sent_to_reseller is True
        assert finalized_invoice_with_pdf.has_been_sent_to_reseller_at is not None

    def test_does_not_raise_on_smtp_error(self, tenant, finalized_invoice_with_pdf):
        """The invoice is already legally finalized in a prior txn.
        A transient SMTP error here must NOT bubble up and cause a
        500 — it would mislead the caller into thinking the upload
        itself failed."""
        import smtplib

        with mock.patch.object(
            EmailService,
            "send_email",
            autospec=True,
            side_effect=smtplib.SMTPException("simulated SMTP outage"),
        ):
            # Must not raise.
            assert InvoiceService.send_to_reseller(finalized_invoice_with_pdf) is False

        finalized_invoice_with_pdf.refresh_from_db()
        assert finalized_invoice_with_pdf.has_been_sent_to_reseller is False


# ---------------------------------------------------------------------------
# send_to_accounting
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestSendToAccounting:
    def test_short_circuits_when_no_tenant_email_config(
        self, tenant, finalized_invoice_with_pdf
    ):
        """No TenantEmailConfig at all → return False, never invoke
        the SMTP layer. The tenant simply hasn't configured outbound
        email yet; that's a valid early-stage state."""
        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            assert (
                InvoiceService.send_to_accounting(finalized_invoice_with_pdf) is False
            )
        assert not send_email.called

    def test_short_circuits_when_accounting_email_not_set(
        self, tenant, finalized_invoice_with_pdf
    ):
        TenantEmailConfig.objects.create(
            tenant=tenant,
            smtp_host="localhost",
            smtp_port=25,
            from_email="noreply@example.org",
            from_name="Test Tenant",
            accounting_email=None,  # the case under test
            is_active=True,
        )

        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            assert (
                InvoiceService.send_to_accounting(finalized_invoice_with_pdf) is False
            )
        assert not send_email.called

    def test_happy_path_flips_accounting_flags(
        self,
        tenant,
        finalized_invoice_with_pdf,
        accounting_email_config,
    ):
        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            assert InvoiceService.send_to_accounting(finalized_invoice_with_pdf) is True

        kwargs = send_email.call_args.kwargs
        assert kwargs["slug"] == "commissioning.invoice"
        assert kwargs["to_emails"] == ["datev@coop.de"]
        assert kwargs["purpose"] == "invoice:accounting"

        finalized_invoice_with_pdf.refresh_from_db()
        assert finalized_invoice_with_pdf.has_been_sent_to_accounting is True
        assert finalized_invoice_with_pdf.has_been_sent_to_accounting_at is not None

    def test_attaches_zugferd_xml_when_present(
        self,
        tenant,
        reseller_with_email,
        accounting_email_config,
    ):
        """ZUGFeRD is embedded in the PDF, but tenants who run a DATEV
        ingestion pipeline often want the standalone XML too. When
        ``invoice.xml_file`` is populated, both go out as separate
        attachments."""
        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email,
            is_finalized=True,
            date=datetime.date(2026, 6, 1),
        )
        _attach_pdf(invoice)
        invoice.xml_file = SimpleUploadedFile(
            "rechnung.xml",
            b"<?xml version='1.0'?><Invoice/>",
            content_type="application/xml",
        )
        invoice.save(update_fields=["xml_file"])

        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            InvoiceService.send_to_accounting(invoice)

        attachments = send_email.call_args.kwargs["attachments"]
        assert len(attachments) == 2
        mimetypes = {a[2] for a in attachments}
        assert mimetypes == {"application/pdf", "application/xml"}


# ---------------------------------------------------------------------------
# Auto-send on upload_pdf
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestUploadPdfAutoSend:
    """Cover the wiring in
    ``InvoiceResellerViewSet.upload_pdf`` -> ``transaction.on_commit
    (send_to_reseller / send_to_accounting)``.

    We patch the two service helpers at module path level (where
    ``upload_pdf`` imports them) so the assertion is about the
    trigger, not the send itself — the send is covered above.

    Critical: ``transaction.on_commit`` callbacks do NOT fire under
    pytest-django's default savepoint mode — the surrounding test
    transaction never commits, so the deferred callbacks just leak.
    We wrap the upload call in ``TestCase.captureOnCommitCallbacks
    (execute=True)`` so the on-commit hooks fire synchronously at
    context-exit. Same idiom Django's own contrib tests use."""

    def _upload(self, api_client, invoice, content: bytes = b"%PDF-1.4 test"):
        from django.urls import reverse

        url = reverse("invoices-upload-pdf", kwargs={"pk": invoice.pk})
        upload = SimpleUploadedFile(
            "rechnung.pdf", content, content_type="application/pdf"
        )
        return api_client.post(url, {"file": upload}, format="multipart")

    def test_first_upload_triggers_both_sends(
        self, api_client, tenant, reseller_with_email, accounting_email_config
    ):
        from django.test import TestCase

        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email, is_finalized=True
        )
        # Neither flag set yet → both sends should fire.
        assert invoice.has_been_sent_to_reseller is False
        assert invoice.has_been_sent_to_accounting is False

        with (
            mock.patch(
                "apps.commissioning.services.invoice_service."
                "InvoiceService.send_to_reseller",
            ) as send_reseller,
            mock.patch(
                "apps.commissioning.services.invoice_service."
                "InvoiceService.send_to_accounting",
            ) as send_accounting,
            TestCase.captureOnCommitCallbacks(execute=True),
        ):
            resp = self._upload(api_client, invoice)

        from rest_framework import status

        assert resp.status_code == status.HTTP_200_OK
        assert send_reseller.call_count == 1
        assert send_accounting.call_count == 1

    def test_second_upload_does_not_re_trigger_sends(
        self, api_client, tenant, reseller_with_email, accounting_email_config
    ):
        """Idempotency on the auto-send side. Once
        ``has_been_sent_to_reseller_at`` is set, subsequent
        ``upload_pdf`` calls (e.g. the frontend resubmitting after a
        transient upload error, or an admin replacing the PDF) must
        NOT fire another reseller-email. Same for the accounting
        side. ``has_been_sent_to_reseller`` is a @property derived
        from the timestamp, so setting the timestamp marks it sent."""
        from django.test import TestCase

        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email,
            is_finalized=True,
            has_been_sent_to_reseller_at=datetime.datetime(
                2026, 6, 1, tzinfo=datetime.UTC
            ),
            has_been_sent_to_accounting_at=datetime.datetime(
                2026, 6, 1, tzinfo=datetime.UTC
            ),
        )

        with (
            mock.patch(
                "apps.commissioning.services.invoice_service."
                "InvoiceService.send_to_reseller",
            ) as send_reseller,
            mock.patch(
                "apps.commissioning.services.invoice_service."
                "InvoiceService.send_to_accounting",
            ) as send_accounting,
            TestCase.captureOnCommitCallbacks(execute=True),
        ):
            resp = self._upload(api_client, invoice)

        from rest_framework import status

        assert resp.status_code == status.HTTP_200_OK
        assert send_reseller.call_count == 0
        assert send_accounting.call_count == 0

    @pytest.mark.parametrize(
        "reseller_kwargs",
        [
            {"invoice_email": None},
            # Paper only: an address is on file, but invoice email is off.
            {"invoice_email": "reseller@example.org", "invoice_via_email": False},
        ],
        ids=["no-address", "paper-only"],
    )
    def test_no_reseller_send_is_claimed_without_a_recipient(
        self, api_client, tenant, accounting_email_config, reseller_kwargs
    ):
        from django.test import TestCase

        invoice = InvoiceResellerFactory(
            reseller=ResellerFactory(**reseller_kwargs), is_finalized=True
        )

        with (
            mock.patch(
                "apps.commissioning.services.invoice_service."
                "InvoiceService.send_to_reseller",
            ) as send_reseller,
            mock.patch(
                "apps.commissioning.services.invoice_service."
                "InvoiceService.send_to_accounting",
                return_value=True,
            ),
            TestCase.captureOnCommitCallbacks(execute=True),
        ):
            resp = self._upload(api_client, invoice)

        assert resp.status_code == 200
        assert send_reseller.call_count == 0
        invoice.refresh_from_db()
        assert invoice.has_been_sent_to_reseller_at is None

    def test_no_accounting_send_is_claimed_without_an_accounting_address(
        self, api_client, tenant, reseller_with_email
    ):
        from django.test import TestCase

        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email, is_finalized=True
        )

        with (
            mock.patch(
                "apps.commissioning.services.invoice_service."
                "InvoiceService.send_to_reseller",
                return_value=True,
            ),
            mock.patch(
                "apps.commissioning.services.invoice_service."
                "InvoiceService.send_to_accounting",
            ) as send_accounting,
            TestCase.captureOnCommitCallbacks(execute=True),
        ):
            resp = self._upload(api_client, invoice)

        assert resp.status_code == 200
        assert send_accounting.call_count == 0
        invoice.refresh_from_db()
        assert invoice.has_been_sent_to_accounting_at is None

    def test_failed_sends_release_their_claims(
        self, api_client, tenant, reseller_with_email, accounting_email_config
    ):
        from django.test import TestCase

        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email, is_finalized=True
        )

        with (
            mock.patch.object(
                EmailService,
                "send_email",
                autospec=True,
                side_effect=smtplib.SMTPException("simulated SMTP outage"),
            ),
            TestCase.captureOnCommitCallbacks(execute=True),
        ):
            resp = self._upload(api_client, invoice)

        # The upload itself succeeded; only the emails didn't go out.
        assert resp.status_code == 200
        invoice.refresh_from_db()
        assert invoice.file
        assert invoice.has_been_sent_to_reseller_at is None
        assert invoice.has_been_sent_to_accounting_at is None
        # The release is on the invoice's audit record, like the claim.
        from auditlog.models import LogEntry

        reseller_changes = [
            entry.changes_dict["has_been_sent_to_reseller_at"]
            for entry in LogEntry.objects.get_for_object(invoice)
            if "has_been_sent_to_reseller_at" in entry.changes_dict
        ]
        assert any(old != "None" and new == "None" for old, new in reseller_changes)

    def test_a_send_that_raises_releases_its_claim_and_the_other_still_runs(
        self, api_client, tenant, reseller_with_email, accounting_email_config
    ):
        from django.test import TestCase

        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email, is_finalized=True
        )

        # Outside the failures the send helpers catch themselves.
        with (
            mock.patch.object(
                EmailService,
                "send_email",
                autospec=True,
                side_effect=RuntimeError("unexpected"),
            ) as send_email,
            TestCase.captureOnCommitCallbacks(execute=True),
        ):
            resp = self._upload(api_client, invoice)

        assert resp.status_code == 200
        assert send_email.call_count == 2
        invoice.refresh_from_db()
        assert invoice.has_been_sent_to_reseller_at is None
        assert invoice.has_been_sent_to_accounting_at is None

    def test_successful_sends_keep_their_stamps(
        self, api_client, tenant, reseller_with_email, accounting_email_config
    ):
        from django.test import TestCase

        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email, is_finalized=True
        )

        with (
            mock.patch.object(
                EmailService, "send_email", autospec=True, return_value=True
            ) as send_email,
            TestCase.captureOnCommitCallbacks(execute=True),
        ):
            resp = self._upload(api_client, invoice)

        assert resp.status_code == 200
        assert send_email.call_count == 2
        invoice.refresh_from_db()
        assert invoice.has_been_sent_to_reseller_at is not None
        assert invoice.has_been_sent_to_accounting_at is not None


@pytest.mark.django_db
class TestSendClaimed:
    CLAIMED_AT = datetime.datetime(2026, 6, 2, 10, 0, tzinfo=datetime.UTC)

    def _stamp(self, invoice, value):
        invoice.has_been_sent_to_reseller_at = value
        invoice.save(update_fields=["has_been_sent_to_reseller_at"])

    def _fail(self, invoice):
        return InvoiceService.send_claimed(
            invoice,
            lambda _invoice: False,
            timestamp_field="has_been_sent_to_reseller_at",
            claimed_at=self.CLAIMED_AT,
        )

    def test_a_failed_send_releases_its_own_claim(
        self, tenant, finalized_invoice_with_pdf
    ):
        self._stamp(finalized_invoice_with_pdf, self.CLAIMED_AT)

        assert self._fail(finalized_invoice_with_pdf) is False

        finalized_invoice_with_pdf.refresh_from_db()
        assert finalized_invoice_with_pdf.has_been_sent_to_reseller_at is None

    def test_a_newer_stamp_survives_the_release(
        self, tenant, finalized_invoice_with_pdf
    ):
        # A send that succeeded meanwhile stamped its own time.
        newer = datetime.datetime(2026, 6, 2, 10, 5, tzinfo=datetime.UTC)
        self._stamp(finalized_invoice_with_pdf, newer)

        self._fail(finalized_invoice_with_pdf)

        finalized_invoice_with_pdf.refresh_from_db()
        assert finalized_invoice_with_pdf.has_been_sent_to_reseller_at == newer


# ---------------------------------------------------------------------------
# The office's send / send-again actions
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestInvoiceSendActions:
    @staticmethod
    def _post(client, invoice, action: str):
        from django.urls import reverse

        return client.post(reverse(f"invoices-{action}", kwargs={"pk": invoice.pk}))

    def test_sends_to_the_reseller(
        self, api_client, tenant, finalized_invoice_with_pdf
    ):
        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ):
            resp = self._post(
                api_client, finalized_invoice_with_pdf, "send-to-reseller"
            )

        assert resp.status_code == 200
        assert resp.data["sent"] is True
        assert resp.data["has_been_sent_to_reseller_at"] is not None

    def test_reports_a_refused_send_without_stamping(
        self, api_client, tenant, finalized_invoice_with_pdf
    ):
        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=False
        ):
            resp = self._post(
                api_client, finalized_invoice_with_pdf, "send-to-reseller"
            )

        assert resp.status_code == 200
        assert resp.data == {"sent": False, "has_been_sent_to_reseller_at": None}

    def test_sends_to_accounting(
        self, api_client, tenant, finalized_invoice_with_pdf, accounting_email_config
    ):
        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            resp = self._post(
                api_client, finalized_invoice_with_pdf, "send-to-accounting"
            )

        assert resp.status_code == 200
        assert resp.data["sent"] is True
        assert resp.data["has_been_sent_to_accounting_at"] is not None
        assert send_email.call_args.kwargs["to_emails"] == ["datev@coop.de"]

    def test_refuses_an_unfinalized_invoice(
        self, api_client, tenant, reseller_with_email
    ):
        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email, is_finalized=False
        )

        resp = self._post(api_client, invoice, "send-to-reseller")

        assert resp.status_code == 400
        assert resp.data["code"] == "document.not_finalized"

    def test_refuses_without_a_pdf(self, api_client, tenant, reseller_with_email):
        invoice = InvoiceResellerFactory(
            reseller=reseller_with_email, is_finalized=True
        )

        resp = self._post(api_client, invoice, "send-to-accounting")

        assert resp.status_code == 400
        assert resp.data["code"] == "document.pdf_missing"

    @pytest.mark.parametrize(
        ("reseller_kwargs", "code"),
        [
            ({"invoice_email": None}, "reseller.email_missing"),
            (
                {"invoice_email": "reseller@example.org", "invoice_via_email": False},
                "reseller.invoice_email_disabled",
            ),
        ],
        ids=["no-address", "paper-only"],
    )
    def test_refuses_a_reseller_it_cannot_email(
        self, api_client, tenant, reseller_kwargs, code
    ):
        invoice = InvoiceResellerFactory(
            reseller=ResellerFactory(**reseller_kwargs), is_finalized=True
        )
        _attach_pdf(invoice)

        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            resp = self._post(api_client, invoice, "send-to-reseller")

        assert resp.status_code == 400
        assert resp.data["code"] == code
        assert not send_email.called

    def test_refuses_accounting_without_an_address(
        self, api_client, tenant, finalized_invoice_with_pdf
    ):
        resp = self._post(api_client, finalized_invoice_with_pdf, "send-to-accounting")

        assert resp.status_code == 400
        assert resp.data["code"] == "accounting.email_missing"

    def test_is_office_only(self, tenant, member_user, finalized_invoice_with_pdf):
        from rest_framework.test import APIClient

        client = APIClient()
        client.force_authenticate(user=member_user)

        with mock.patch.object(
            EmailService, "send_email", autospec=True, return_value=True
        ) as send_email:
            for action in ("send-to-reseller", "send-to-accounting"):
                resp = self._post(client, finalized_invoice_with_pdf, action)
                assert resp.status_code == 403

        assert not send_email.called
