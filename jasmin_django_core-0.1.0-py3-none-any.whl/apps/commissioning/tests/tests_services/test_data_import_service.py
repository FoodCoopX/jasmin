"""Tests for the CSV → model import service.

The service is pure logic — no HTTP. Most of its bulk is small helpers
(``_normalize_cell``, ``_parse_bool_cell``, ``_decode_csv``, ...) that
together drive a single orchestrator (``import_rows_from_csv``). The
orchestrator's most important property is **per-row isolation**: one bad
row never aborts the import.

Crate is the simplest registered model (just ``name`` + ``number``
required) so it's used for the round-trip happy paths.
"""

from __future__ import annotations

import csv
import datetime
from unittest.mock import patch

import pytest
from django.db import DatabaseError
from django.utils import timezone

from apps.commissioning.errors import DataImportInvalid
from apps.commissioning.models import (
    Crate,
    DeliveryStation,
    Member,
    Reseller,
    ShareArticle,
)
from apps.commissioning.models.choices import UnitOptions
from apps.commissioning.serializers import CrateSerializer, ShareArticleSerializer
from apps.commissioning.services.data_import import (
    _MAX_IMPORT_ROWS,
    DataImportResult,
    ImportOptions,
    _collect_bool_fields,
    _CsvLine,
    _decode_csv,
    _flatten_drf_errors,
    _normalize_cell,
    _parse_bool_cell,
    _read_csv_rows,
    _row_to_payload,
    _split_template_rows,
    get_serializer_for_model,
    import_rows_from_csv,
)
from apps.commissioning.tests.factories import JasminUserFactory
from apps.shared.tenants.models import RateLimitedAction
from apps.shared.tenants.rate_limits import remaining_weekly_quota


@pytest.fixture
def restore_overrides(tenant):
    # ``tenant`` is one object for the whole session; an override set in a test
    # must not reach later ones.
    original = tenant.action_rate_limit_overrides
    yield
    tenant.action_rate_limit_overrides = original


# ---------------------------------------------------------------------------
# Pure helpers — no DB, no fixtures needed
# ---------------------------------------------------------------------------


class TestNormalizeCell:
    @pytest.mark.parametrize(
        "value, expected",
        [
            (None, None),
            ("", None),
            ("   ", None),
            ("none", None),
            ("NULL", None),
            ("NaN", None),
            ("hello", "hello"),
            ("  trimmed  ", "trimmed"),
            ("0", "0"),  # zero is NOT empty
            ("false", "false"),  # bool sentinel stays — handled separately
        ],
    )
    def test_empty_sentinels_become_none(self, value, expected):
        assert _normalize_cell(value) == expected


class TestParseBoolCell:
    @pytest.mark.parametrize(
        "value, expected",
        [
            ("true", True),
            ("True", True),
            ("1", True),
            ("yes", True),
            ("ja", True),
            ("wahr", True),
            ("false", False),
            ("0", False),
            ("no", False),
            ("nein", False),
            ("falsch", False),
        ],
    )
    def test_canonical_values_coerce(self, value, expected):
        assert _parse_bool_cell(value) is expected

    def test_unknown_values_pass_through(self):
        """Service hands non-canonical strings to DRF, which rejects them
        per-row instead of crashing the whole import."""
        assert _parse_bool_cell("maybe") == "maybe"
        assert _parse_bool_cell("2") == "2"


class TestRowToPayload:
    def test_builds_payload_from_headers_and_cells(self):
        payload = _row_to_payload(
            headers=["name", "number"],
            cells=["EuroBox", "42"],
            bool_fields=set(),
        )
        assert payload == {"name": "EuroBox", "number": "42"}

    def test_empty_header_columns_are_skipped(self):
        """Trailing/blank headers in the template (often left over from
        spreadsheets) must not pollute the payload with empty keys."""
        payload = _row_to_payload(
            headers=["name", "", "number"],
            cells=["EuroBox", "ignored", "42"],
            bool_fields=set(),
        )
        assert payload == {"name": "EuroBox", "number": "42"}

    def test_empty_cell_sentinels_dropped(self):
        payload = _row_to_payload(
            headers=["name", "short_name"],
            cells=["EuroBox", "  null  "],
            bool_fields=set(),
        )
        assert payload == {"name": "EuroBox"}

    def test_bool_fields_get_coerced(self):
        payload = _row_to_payload(
            headers=["name", "is_active"],
            cells=["X", "ja"],
            bool_fields={"is_active"},
        )
        assert payload == {"name": "X", "is_active": True}

    def test_non_bool_fields_stay_strings(self):
        payload = _row_to_payload(
            headers=["name", "tag"],
            cells=["X", "true"],
            bool_fields=set(),
        )
        assert payload == {"name": "X", "tag": "true"}


class TestCollectBoolFields:
    def test_returns_boolean_field_names(self):
        """``CrateSerializer.Meta = {fields: __all__}`` exposes
        ``is_active`` (Crate model has it as ``BooleanField``)."""
        names = _collect_bool_fields(CrateSerializer)
        assert "is_active" in names
        assert "name" not in names

    def test_other_serializers_have_their_own_bool_set(self):
        """Sanity-check: ShareArticleSerializer carries its own bool fields,
        not Crate's. Avoids accidental cross-contamination of the
        bool-field cache during refactors."""
        sa_bools = _collect_bool_fields(ShareArticleSerializer)
        # ShareArticle has is_active, is_purchased, is_sold_to_resellers,
        # for_markets — at least one must be present.
        assert sa_bools  # non-empty
        assert "name" not in sa_bools


class TestFlattenDrfErrors:
    def test_string(self):
        assert _flatten_drf_errors("simple") == "simple"

    def test_list_of_strings(self):
        assert _flatten_drf_errors(["a", "b"]) == "a, b"

    def test_dict_of_lists(self):
        out = _flatten_drf_errors({"name": ["required"], "number": ["int"]})
        # Order isn't guaranteed in older Pythons but dicts preserve
        # insertion order since 3.7 — assert both segments present.
        assert "name: required" in out
        assert "number: int" in out

    def test_nested_dict(self):
        out = _flatten_drf_errors({"nested": {"key": ["bad"]}})
        assert "key: bad" in out


class TestDecodeCsv:
    def test_utf8(self):
        assert _decode_csv(b"hello") == "hello"

    def test_utf8_with_bom(self):
        """Excel exports often start with a UTF-8 BOM. The ``utf-8-sig``
        codec consumes it so the first column header doesn't end up with
        a leading ``\\ufeff``."""
        bom = b"\xef\xbb\xbf"
        decoded = _decode_csv(bom + b"name,number")
        assert decoded == "name,number"

    def test_latin1_fallback(self):
        """Older Excel exports default to Latin-1. The fallback lets us
        accept those without forcing the user to re-export."""
        # \xe4 is "ä" in Latin-1, invalid as standalone UTF-8 byte.
        decoded = _decode_csv(b"M\xe4rchen")
        assert decoded == "Märchen"


class TestSplitTemplateRows:
    def test_three_row_template_uses_row1_as_headers(self):
        """The downloadable template is title / dataIndex / type-hint, then
        data rows. ``_split_template_rows`` must pick row 1 (the dataIndex
        row) as the schema and skip the type-hint row at index 2."""
        all_lines = [
            _CsvLine(["Name", "Number"]),  # row 0: human title
            _CsvLine(["name", "number"]),  # row 1: dataIndex (the schema)
            _CsvLine(["text", "int"]),  # row 2: type hint
            _CsvLine(["EuroBox", "42"]),  # data row
        ]
        headers, data_lines, first_data_row_number = _split_template_rows(all_lines)
        assert headers == ["name", "number"]
        assert [line.cells for line in data_lines] == [["EuroBox", "42"]]
        assert first_data_row_number == 4

    def test_two_row_hand_rolled_csv_uses_row0_as_headers(self):
        all_lines = [
            _CsvLine(["name", "number"]),
            _CsvLine(["EuroBox", "42"]),
        ]
        headers, data_lines, first_data_row_number = _split_template_rows(all_lines)
        assert headers == ["name", "number"]
        assert [line.cells for line in data_lines] == [["EuroBox", "42"]]
        assert first_data_row_number == 2

    def test_unreadable_schema_row_is_a_whole_file_failure(self):
        """No field names means no schema to validate the data rows against."""
        all_lines = [
            _CsvLine(["Name", "Number"]),
            _CsvLine(parse_error="field larger than field limit (131072)"),
            _CsvLine(["text", "int"]),
            _CsvLine(["EuroBox", "42"]),
        ]
        with pytest.raises(DataImportInvalid) as exc_info:
            _split_template_rows(all_lines)
        assert "header row could not be read" in str(exc_info.value)


class TestGetSerializerForModel:
    def test_known_model(self):
        assert get_serializer_for_model("crate") is CrateSerializer

    def test_unknown_model_raises(self):
        with pytest.raises(DataImportInvalid) as exc_info:
            get_serializer_for_model("not-a-model")
        assert "not-a-model" in str(exc_info.value)
        assert "Allowed" in str(exc_info.value)


# ---------------------------------------------------------------------------
# DataImportResult — small dataclass, easy locks
# ---------------------------------------------------------------------------


class TestDataImportResult:
    def test_counts_default_to_zero(self):
        r = DataImportResult(model_name="crate")
        assert r.successful == 0
        assert r.failed == 0
        assert r.total_rows == 0

    def test_to_dict_shape(self):
        r = DataImportResult(model_name="crate")
        r.results.append({"row": 2, "id": "abc"})
        r.errors.append({"row": 3, "error": "boom", "data": {}})
        out = r.to_dict()
        assert out == {
            "model_name": "crate",
            "total_rows": 2,
            "successful": 1,
            "failed": 1,
            "results": [{"row": 2, "id": "abc"}],
            "errors": [{"row": 3, "error": "boom", "data": {}}],
        }


# ---------------------------------------------------------------------------
# import_rows_from_csv — the orchestrator
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestImportRowsFromCsv:
    def test_two_row_csv_creates_rows(self, tenant):
        """Happy path: hand-rolled 2-row CSV → one Crate created."""
        csv_bytes = b"name,number\nEuroBox,42\n"
        result = import_rows_from_csv("crate", csv_bytes)

        assert result.successful == 1
        assert result.failed == 0
        assert Crate.objects.filter(name="EuroBox").exists()
        # Row number for the data row should be 2 in the 2-row variant
        # (header row + 1).
        assert result.results[0]["row"] == 2

    def test_member_import_over_weekly_cap_is_refused_up_front(
        self, tenant, restore_overrides
    ):
        """A member CSV whose size would blow the weekly MEMBER_CREATION cap is
        refused before any row is written (the import must not partially apply),
        closing the bulk-import bypass of the interactive create cap."""
        from apps.commissioning.models import Member
        from apps.shared.tenants.errors import ActionRateLimitExceeded

        # Platform-owned override; connection.tenant is this fixture object.
        tenant.action_rate_limit_overrides = {"member_creation": {"weekly": 2}}
        # 3-row download-template shape (titles / dataIndex / type hints) + 3
        # data rows → 3 member creations, over the weekly cap of 2.
        csv_bytes = (
            b"First Name,Last Name\n"  # row 0: titles
            b"first_name,last_name\n"  # row 1: dataIndex
            b"text,text\n"  # row 2: type hints
            b"A,One\n"
            b"B,Two\n"
            b"C,Three\n"
        )

        with pytest.raises(ActionRateLimitExceeded) as exc:
            import_rows_from_csv("member", csv_bytes)
        assert exc.value.details["action"] == "member_creation"
        assert not Member.objects.filter(last_name__in=["One", "Two", "Three"]).exists()

    def test_three_row_template_skips_type_hint_row(self, tenant):
        """The downloadable template's type-hint row (row 2) is NOT a
        data row — the import must skip it, not try to create a crate
        named ``text``."""
        csv_bytes = (
            b"Name,Number\n"  # row 0: titles
            b"name,number\n"  # row 1: dataIndex
            b"text,int\n"  # row 2: type hints
            b"EuroBox,42\n"  # row 3: first data row → row_number 4
        )
        result = import_rows_from_csv("crate", csv_bytes)

        assert result.successful == 1
        assert result.failed == 0
        assert result.results[0]["row"] == 4
        # Did NOT create a crate named "text" from the type-hint row.
        assert not Crate.objects.filter(name="text").exists()

    def test_per_row_isolation_one_bad_row_does_not_abort(self, tenant):
        """One row failing validation must not block the others — the
        whole point of the per-row try/except in the orchestrator.

        Uses the **template format** (3 preamble rows + data) because
        any CSV with ``len(all_rows) >= 3`` is interpreted that way —
        otherwise a 4-row hand-rolled file would parse row 1 as the
        dataIndex schema and the test would assert against garbage.
        """
        csv_bytes = (
            b"Name,Number\n"  # row 0: human title
            b"name,number\n"  # row 1: dataIndex (schema)
            b"text,int\n"  # row 2: type hint
            b"GoodOne,1\n"  # row 3 → row_number 4 (OK)
            b",2\n"  # row 4 → row_number 5 (missing ``name`` → error)
            b"GoodTwo,3\n"  # row 5 → row_number 6 (OK)
        )
        result = import_rows_from_csv("crate", csv_bytes)

        assert result.successful == 2
        assert result.failed == 1
        assert Crate.objects.filter(name__in=["GoodOne", "GoodTwo"]).count() == 2
        # The bad row's payload + row number is reported back so the
        # frontend can show it in an error table. Bad row is at template
        # position 4 (0-indexed) → 1-indexed row_number 5.
        assert result.errors[0]["row"] == 5
        assert "data" in result.errors[0]

    def test_empty_payload_rows_silently_skipped(self, tenant):
        """A data row whose cells all normalize to ``None`` (Excel "none" /
        "null" placeholders) yields an empty payload → the orchestrator's
        ``if not payload: continue`` branch. Must NOT become an error row.

        Note: truly-blank lines (``" , "``) get filtered out earlier by
        the ``any(cell.strip()...)`` guard before splitting — they never
        reach the data-row loop. This test exercises the loop's own skip.
        """
        csv_bytes = (
            b"Name,Number\n"  # row 0: title
            b"name,number\n"  # row 1: dataIndex
            b"text,int\n"  # row 2: type hint
            b"GoodOne,1\n"  # row 3: OK
            b"none,null\n"  # row 4: both sentinels → empty payload → skip
            b"GoodTwo,2\n"  # row 5: OK
        )
        result = import_rows_from_csv("crate", csv_bytes)

        assert result.failed == 0
        assert result.successful == 2
        assert Crate.objects.filter(name__in=["GoodOne", "GoodTwo"]).count() == 2

    def test_empty_file_raises_data_import_error(self, tenant):
        """No data row at all → DataImportInvalid (400 via the global
        handler)."""
        with pytest.raises(DataImportInvalid) as exc_info:
            import_rows_from_csv("crate", b"name,number\n")
        assert "at least a header row and one data row" in str(exc_info.value)

    def test_unknown_model_raises(self, tenant):
        with pytest.raises(DataImportInvalid):
            import_rows_from_csv("not-a-real-model", b"name\nx\n")

    def test_bool_field_coerced_from_german_truthy(self, tenant):
        """Crate.is_active is a BooleanField. The German ``ja`` must
        coerce to True instead of failing serializer validation."""
        csv_bytes = b"name,number,is_active\nActiveCrate,7,ja\n"
        result = import_rows_from_csv("crate", csv_bytes)

        assert result.failed == 0
        crate = Crate.objects.get(name="ActiveCrate")
        assert crate.is_active is True

    def test_member_link_failure_rolls_back_the_row(self, tenant):
        """A member whose email matches an existing (linkable) user goes through
        ``link_to_user`` AFTER ``ser.save()``. If that later step fails, the
        per-row ``transaction.atomic()`` must roll the member insert back — no
        orphaned member that is nonetheless reported as failed (and would then
        duplicate on a re-run of the "failed" file)."""
        JasminUserFactory(email="linkme@example.com")
        csv_bytes = (
            b"First,Last,Email\n"  # titles
            b"first_name,last_name,email\n"  # dataIndex
            b"text,text,email\n"  # type hints
            b"Link,Me,linkme@example.com\n"
        )
        with patch(
            "apps.commissioning.services.member_service.MemberService.link_to_user",
            side_effect=DatabaseError("simulated link failure"),
        ):
            result = import_rows_from_csv("member", csv_bytes)

        assert result.successful == 0
        assert result.failed == 1
        # Atomic per-row: the save() was rolled back, so no orphan remains.
        assert not Member.objects.filter(email="linkme@example.com").exists()

    def test_latin1_csv_decodes(self, tenant):
        """Excel-default Latin-1 exports must round-trip — German tenants
        upload these regularly."""
        # "Märchenkiste" in Latin-1.
        csv_bytes = b"name,number\nM\xe4rchenkiste,5\n"
        result = import_rows_from_csv("crate", csv_bytes)

        assert result.successful == 1
        assert Crate.objects.filter(name="Märchenkiste").exists()


# ---------------------------------------------------------------------------
# member_number on the onboarding import (MemberImportSerializer)
# ---------------------------------------------------------------------------


def _member_csv(*rows: str, extra_headers: str = "") -> bytes:
    """3-row download-template CSV (titles / dataIndex / type hints) + data."""
    header = "first_name,last_name,email,member_number,is_trial" + extra_headers
    return (
        "First,Last,Email,Member no.,Trial\n"
        f"{header}\n"
        "text,text,email,integer,boolean\n" + "".join(f"{row}\n" for row in rows)
    ).encode("utf-8")


@pytest.mark.django_db
class TestMemberNumberImport:
    """A tenant onboarding its EXISTING members brings their Mitgliedsnummern
    with it — the office grid keeps the column read-only, but the import path
    accepts it (``MemberImportSerializer``). Every follow-up onboarding import
    (subscriptions, coop shares, SEPA mandates) resolves its member by that
    number, so it has to survive the import verbatim."""

    def test_member_number_is_imported(self, tenant):
        result = import_rows_from_csv(
            "member", _member_csv("Ada,Lovelace,ada@example.org,1001,false")
        )

        assert result.failed == 0, result.errors
        assert Member.objects.get(email="ada@example.org").member_number == 1001

    def test_imported_number_survives_admin_confirmation(self, tenant):
        """``_post_confirm`` only generates a number when none is set — the
        imported one must NOT be overwritten, or the whole Mitgliederliste is
        renumbered out from under the tenant's paperwork."""
        import_rows_from_csv(
            "member", _member_csv("Ada,Lovelace,ada@example.org,1001,false")
        )
        member = Member.objects.get(email="ada@example.org")
        admin = JasminUserFactory(email="office@example.org")

        member.confirm(admin)
        member.refresh_from_db()

        assert member.member_number == 1001

    def test_next_generated_number_continues_above_the_imported_block(self, tenant):
        """The generator is ``Max(member_number) + 1``, so a member confirmed
        AFTER the import lands above the imported range instead of colliding
        with it."""
        import_rows_from_csv(
            "member", _member_csv("Ada,Lovelace,ada@example.org,1001,false")
        )
        fresh = Member.objects.create(
            first_name="New", last_name="Joiner", email="new@example.org"
        )
        admin = JasminUserFactory(email="office2@example.org")

        fresh.confirm(admin)
        fresh.refresh_from_db()

        assert fresh.member_number == 1002

    def test_blank_number_still_imports(self, tenant):
        """Leaving the column empty keeps the default behaviour: no number
        until the office confirms the member."""
        result = import_rows_from_csv(
            "member", _member_csv("Grace,Hopper,grace@example.org,,false")
        )

        assert result.failed == 0, result.errors
        assert Member.objects.get(email="grace@example.org").member_number is None

    def test_duplicate_number_is_a_clean_per_row_error(self, tenant):
        """Making the field writable attaches DRF's UniqueValidator, so a
        collision within the same file is a per-row error — not an
        IntegrityError that takes the batch with it."""
        result = import_rows_from_csv(
            "member",
            _member_csv(
                "Ada,Lovelace,ada@example.org,1001,false",
                "Alan,Turing,alan@example.org,1001,false",
            ),
        )

        assert result.successful == 1
        assert result.failed == 1
        assert result.errors[0]["row"] == 5
        assert "member_number" in result.errors[0]["error"]
        assert Member.objects.get(member_number=1001).email == "ada@example.org"

    def test_trial_row_with_a_number_is_rejected(self, tenant):
        """Trial members are not Mitglieder under GenG — no Mitgliedsnummer.
        ``_post_confirm`` would leave an imported one in place forever."""
        result = import_rows_from_csv(
            "member", _member_csv("Try,Me,try@example.org,1001,true")
        )

        assert result.successful == 0
        assert result.failed == 1
        assert "number_not_allowed_for_trial" in result.errors[0]["error"] or (
            "member number" in result.errors[0]["error"]
        )
        assert not Member.objects.filter(email="try@example.org").exists()

    def test_office_grid_patch_still_cannot_set_a_number(self, tenant):
        """The unlock is import-only: the serializer the office grid PATCHes
        through keeps ``member_number`` read-only."""
        from apps.commissioning.serializers import MemberSerializer

        member = Member.objects.create(
            first_name="Read", last_name="Only", email="ro@example.org"
        )
        ser = MemberSerializer(member, data={"member_number": 9999}, partial=True)

        assert ser.is_valid(), ser.errors
        ser.save()
        member.refresh_from_db()

        assert member.member_number is None


@pytest.mark.django_db
class TestMemberExitDateImport:
    """Austrittsdatum (GenG §30) on the onboarding import.

    A tenant migrating off another system brings DEPARTED members over too —
    the Mitgliederliste has to retain them. The office has one date on paper
    (the exit date), so that is the only column the template offers; the
    serializer derives ``cancelled_at`` so the pair can never disagree.
    """

    @staticmethod
    def _csv(*rows: str) -> bytes:
        header = "first_name,last_name,email,entry_date,cancelled_effective_at"
        return (
            "First,Last,Email,Entry,Exit\n"
            f"{header}\n"
            "text,text,email,date,date\n" + "".join(f"{row}\n" for row in rows)
        ).encode("utf-8")

    def test_exit_date_is_imported(self, tenant):
        result = import_rows_from_csv(
            "member", self._csv("Ex,Member,ex@example.org,2019-04-01,2023-12-31")
        )

        assert result.failed == 0, result.errors
        member = Member.objects.get(email="ex@example.org")
        assert member.cancelled_effective_at == datetime.date(2023, 12, 31)

    def test_cancelled_at_is_derived_so_the_row_reads_as_departed(self, tenant):
        """``cancelled_at`` is what marks a member departed (the statistics
        cancelled-count, the ``MemberAlreadyCancelled`` guard, the grid's
        struck-through row), while the GenG retention sweep keys off
        ``cancelled_effective_at``. An exit date on its own would leave a member
        retention already targets while they still read as current."""
        import_rows_from_csv(
            "member", self._csv("Ex,Member,ex@example.org,2019-04-01,2023-12-31")
        )

        member = Member.objects.get(email="ex@example.org")
        assert member.cancelled_at is not None
        assert timezone.localtime(member.cancelled_at).date() == datetime.date(
            2023, 12, 31
        )
        # The active-member filter used across the viewsets must exclude them.
        assert not Member.objects.filter(
            email="ex@example.org", cancelled_at__isnull=True
        ).exists()

    def test_blank_exit_date_leaves_an_active_member(self, tenant):
        result = import_rows_from_csv(
            "member", self._csv("Still,Here,here@example.org,2019-04-01,")
        )

        assert result.failed == 0, result.errors
        member = Member.objects.get(email="here@example.org")
        assert member.cancelled_effective_at is None
        assert member.cancelled_at is None

    def test_exit_before_entry_is_a_clean_row_error(self, tenant):
        """``member_cancelled_effective_after_entry`` — you cannot leave before
        you joined. Must surface as a per-row error, not abort the batch."""
        result = import_rows_from_csv(
            "member", self._csv("Bad,Dates,bad@example.org,2023-01-01,2019-04-01")
        )

        assert result.successful == 0
        assert result.failed == 1
        assert not Member.objects.filter(email="bad@example.org").exists()

    def test_office_grid_patch_still_cannot_stamp_an_exit_date(self, tenant):
        """The unlock is import-only. A live member's exit must keep going
        through the cancel flow, which also cascades to their coop shares and
        snapshots each share's payback due date (GenG §31)."""
        from apps.commissioning.serializers import MemberSerializer

        member = Member.objects.create(
            first_name="Live", last_name="Member", email="live@example.org"
        )
        ser = MemberSerializer(
            member, data={"cancelled_effective_at": "2024-01-31"}, partial=True
        )

        assert ser.is_valid(), ser.errors
        ser.save()
        member.refresh_from_db()

        assert member.cancelled_effective_at is None
        assert member.cancelled_at is None


@pytest.mark.django_db
class TestSharedEmailImport:
    """``Member.email`` is deliberately NOT unique — two members legitimately
    share one inbox (an elderly couple with a single address). What cannot be
    shared is a LOGIN: ``JasminUser.email`` is the USERNAME_FIELD."""

    @staticmethod
    def _csv(*rows: str) -> bytes:
        return (
            "First,Last,Email\nfirst_name,last_name,email\ntext,text,email\n"
            + "".join(f"{row}\n" for row in rows)
        ).encode("utf-8")

    def test_two_members_may_share_an_email(self, tenant):
        result = import_rows_from_csv(
            "member",
            self._csv(
                "Anna,Mueller,shared@example.org",
                "Hans,Mueller,shared@example.org",
            ),
        )

        assert result.failed == 0, result.errors
        assert Member.objects.filter(email="shared@example.org").count() == 2

    def test_dry_run_agrees_with_the_real_run(self, tenant):
        """The preview must PREDICT the real run. Rolling every row back
        individually would hide row 1 from row 2, so an intra-file collision
        would preview green then fail for real."""
        csv = self._csv(
            "Anna,Mueller,shared@example.org", "Hans,Mueller,shared@example.org"
        )

        dry = import_rows_from_csv("member", csv, dry_run=True)
        assert Member.objects.count() == 0, "dry run must persist nothing"

        real = import_rows_from_csv("member", csv)
        assert (dry.successful, dry.failed) == (real.successful, real.failed)

    def test_dry_run_still_catches_a_duplicate_member_number(self, tenant):
        """The relaxation is email-only — ``member_number`` is still unique, and
        a collision WITHIN the file must surface in the preview."""
        csv = (
            b"First,Last,Email,No\n"
            b"first_name,last_name,email,member_number\n"
            b"text,text,email,integer\n"
            b"A,One,a@example.org,900\n"
            b"B,Two,b@example.org,900\n"
        )

        dry = import_rows_from_csv("member", csv, dry_run=True)

        assert dry.successful == 1
        assert dry.failed == 1
        assert "member_number" in dry.errors[0]["error"]
        assert Member.objects.count() == 0, "dry run must persist nothing"

    def test_second_member_on_a_taken_login_imports_unlinked(self, tenant):
        """The address's login belongs to another member. Import the member
        anyway — dropping a real Mitglied over an account they were never going
        to have would be worse."""
        user = JasminUserFactory(email="shared@example.org")
        first = Member.objects.create(
            first_name="Anna", last_name="M", email="shared@example.org", user=user
        )

        result = import_rows_from_csv(
            "member", self._csv("Hans,Mueller,shared@example.org")
        )

        assert result.failed == 0, result.errors
        second = Member.objects.get(first_name="Hans")
        assert second.user_id is None, "must not steal the other member's login"
        first.refresh_from_db()
        assert first.user_id == user.pk, "existing link must be untouched"


@pytest.mark.django_db
class TestInviteOnASharedEmail:
    """Inviting the SECOND member on a shared inbox must fail cleanly.

    Without the guard the shared invitation helper would reuse the other
    member's ``pending_invitation`` / ``inactive`` user: roll THIS member's name
    onto it, reset its status, cancel its open invite — and only then trip the
    ``Member.user`` OneToOne. All inside one atomic block, so nothing persists,
    but the office would see a constraint error instead of the reason.
    """

    def _members_sharing(self, holder_status="active"):
        user = JasminUserFactory(email="shared@example.org")
        user.account_status = holder_status
        user.save(update_fields=["account_status"])
        holder = Member.objects.create(
            first_name="Anna",
            last_name="Mueller",
            email="shared@example.org",
            member_number=501,
            user=user,
        )
        partner = Member.objects.create(
            first_name="Hans", last_name="Mueller", email="shared@example.org"
        )
        return holder, partner

    def test_raises_and_names_the_holder(self, tenant):
        from apps.commissioning.errors import MemberEmailAlreadyHasUser
        from apps.commissioning.services.member_service import MemberService

        holder, partner = self._members_sharing()
        admin = JasminUserFactory(email="office@example.org")

        with pytest.raises(MemberEmailAlreadyHasUser) as excinfo:
            MemberService().send_invitation(partner, admin_user=admin)

        details = excinfo.value.details
        assert details["holder_name"] == "Anna Mueller"
        assert details["holder_member_number"] == 501
        assert details["context"] == "named_numbered"
        assert excinfo.value.code == "member.email_already_has_user"

    def test_the_holders_account_is_left_untouched(self, tenant):
        """A pending holder is the dangerous case — that is the branch the
        helper would have reused and rewritten."""
        holder, partner = self._members_sharing(holder_status="pending_invitation")
        admin = JasminUserFactory(email="office2@example.org")
        from apps.commissioning.errors import MemberEmailAlreadyHasUser
        from apps.commissioning.services.member_service import MemberService

        # Snapshot what the helper would have overwritten. (The user's own name
        # comes from the factory and is unrelated to the member's — compare
        # against the captured value, not a literal.)
        before = {
            "first_name": holder.user.first_name,
            "last_name": holder.user.last_name,
            "account_status": holder.user.account_status,
        }

        with pytest.raises(MemberEmailAlreadyHasUser):
            MemberService().send_invitation(partner, admin_user=admin)

        holder.user.refresh_from_db()
        assert holder.user.first_name == before["first_name"], "name was rewritten"
        assert holder.user.last_name == before["last_name"], "name was rewritten"
        assert holder.user.account_status == before["account_status"]
        partner.refresh_from_db()
        assert partner.user_id is None, "partner must not have claimed the login"

    def test_the_holder_themselves_can_still_be_invited(self, tenant):
        """The guard keys on a DIFFERENT member — it must not block the person
        the account actually belongs to."""
        from apps.commissioning.services.member_service import MemberService

        holder, _partner = self._members_sharing(holder_status="pending_invitation")
        admin = JasminUserFactory(email="office3@example.org")

        MemberService().send_invitation(holder, admin_user=admin)

        holder.refresh_from_db()
        assert holder.user is not None


# ---------------------------------------------------------------------------
# Lines the CSV parser itself refuses, and the row cap
# ---------------------------------------------------------------------------


def _oversized_quoted_cell() -> bytes:
    """A quoted cell ``csv`` refuses: longer than its field-size limit.

    The office's version of this is a stray quote that swallows the rest of a
    big file into one field. Either way the parser gives up on that line and
    reads on at the next one.
    """
    return b'"' + b"x" * (csv.field_size_limit() + 10) + b'"'


class TestReadCsvRows:
    def test_reading_stops_at_max_lines(self):
        """The row cap is enforced while reading — an oversized upload is never
        parsed in full just to be refused afterwards."""
        lines = _read_csv_rows(b"a,b\n" * 50, max_lines=5)
        assert len(lines) == 5

    def test_blank_lines_are_dropped(self):
        lines = _read_csv_rows(b"a,b\n \n,\nc,d\n", max_lines=10)
        assert [line.cells for line in lines] == [["a", "b"], ["c", "d"]]

    def test_unreadable_line_is_kept_with_its_reason(self):
        lines = _read_csv_rows(
            b"".join(
                [
                    b"name,number\n",
                    b"Good,1\n",
                    _oversized_quoted_cell() + b",2\n",
                    b"Good2,3\n",
                ]
            ),
            max_lines=10,
        )
        assert [line.parse_error is None for line in lines] == [
            True,
            True,
            False,
            True,
        ]
        assert "field larger than field limit" in lines[2].parse_error


@pytest.mark.django_db
class TestUnreadableRowsAreReported:
    def test_malformed_cell_is_one_failed_row_not_a_crash(self, tenant):
        csv_bytes = b"".join(
            [
                b"Name,Number\n",  # row 0: titles
                b"name,number\n",  # row 1: dataIndex
                b"text,int\n",  # row 2: type hints
                b"GoodOne,1\n",  # row 3 → row_number 4
                _oversized_quoted_cell() + b",2\n",  # row 4 → row_number 5
                b"GoodTwo,3\n",  # row 5 → row_number 6
            ]
        )

        result = import_rows_from_csv("crate", csv_bytes)

        assert result.successful == 2
        assert result.failed == 1
        assert Crate.objects.filter(name__in=["GoodOne", "GoodTwo"]).count() == 2
        bad_row = result.errors[0]
        assert bad_row["row"] == 5
        assert "could not be read" in bad_row["error"]
        assert bad_row["data"] == {}

    def test_unreadable_schema_row_fails_the_whole_file(self, tenant):
        csv_bytes = b"".join(
            [
                b"Name,Number\n",
                _oversized_quoted_cell() + b",number\n",
                b"text,int\n",
                b"GoodOne,1\n",
            ]
        )

        with pytest.raises(DataImportInvalid) as exc_info:
            import_rows_from_csv("crate", csv_bytes)

        assert "header row could not be read" in str(exc_info.value)
        assert not Crate.objects.exists()


@pytest.mark.django_db
class TestRowCap:
    def test_over_cap_file_is_refused_before_anything_is_written(self, tenant):
        csv_bytes = b"".join(
            [b"Name,Number\n", b"name,number\n", b"text,int\n"]
            + [f"Crate{i},{i}\n".encode() for i in range(_MAX_IMPORT_ROWS + 1)]
        )

        with pytest.raises(DataImportInvalid) as exc_info:
            import_rows_from_csv("crate", csv_bytes)

        assert exc_info.value.code == "data_import.too_many_rows"
        assert exc_info.value.details == {"max_rows": _MAX_IMPORT_ROWS}
        assert not Crate.objects.exists()

    def test_an_over_cap_member_file_past_the_weekly_budget_is_not_told_to_split(
        self, tenant, restore_overrides
    ):
        # Every part of a split file draws on the same weekly member budget, so
        # with less than a file's worth left, splitting can't get it in.
        tenant.action_rate_limit_overrides = {"member_creation": {"weekly": 1000}}
        remaining = remaining_weekly_quota(RateLimitedAction.MEMBER_CREATION)

        with pytest.raises(DataImportInvalid) as exc_info:
            import_rows_from_csv("member", _oversized_member_csv())

        assert exc_info.value.code == "data_import.over_member_limit"
        assert exc_info.value.details == {
            "max_rows": _MAX_IMPORT_ROWS,
            "remaining": remaining,
        }
        assert not Member.objects.filter(last_name="Oversized").exists()

    def test_an_over_cap_member_file_within_a_raised_budget_is_told_to_split(
        self, tenant, restore_overrides
    ):
        tenant.action_rate_limit_overrides = {"member_creation": {"weekly": 20000}}

        with pytest.raises(DataImportInvalid) as exc_info:
            import_rows_from_csv("member", _oversized_member_csv())

        assert exc_info.value.code == "data_import.too_many_rows"


def _oversized_member_csv() -> bytes:
    return _member_csv(
        *(
            f"Member{i},Oversized,member{i}@example.org,{i + 1},false"
            for i in range(_MAX_IMPORT_ROWS + 1)
        )
    )


# ---------------------------------------------------------------------------
# Models whose address block lives on a linked ContactEntity
# ---------------------------------------------------------------------------

_RESELLER_CSV = b"".join(
    [
        b"Company,First name,Last name,Email,Address,ZIP,City,Country,"
        b"Reseller,Also delivery station,Customer number\n",
        b"company_name,first_name,last_name,email,address,zip_code,city,country,"
        b"is_reseller,is_also_delivery_station,customer_number\n",
        b"string,string,string,string,string,string,string,string,"
        b"true|false,true|false,integer\n",
        b"Kern Farm Shop,Anna,Kern,shop@example.org,4 Market Lane,8010,Graz,AT,"
        b"true,false,4711\n",
        b"Valley Grocers,Bruno,Vale,valley@example.org,9 Hill Road,8020,Graz,AT,"
        b"true,true,4712\n",
    ]
)

_DELIVERY_STATION_CSV = b"".join(
    [
        b"Active,Also reseller,#,Short name,Company,Address,ZIP,City,Email,Info\n",
        b"is_active,is_also_reseller,number,short_name,company_name,address,"
        b"zip_code,city,email,info\n",
        b"true|false,true|false,integer,string,string,string,string,string,"
        b"string,string\n",
        b"true,false,7,CENTER,Community Center,12 Main Street,8020,Graz,"
        b"center@example.org,Pickup in the back yard\n",
        b"true,true,8,FARMSHOP,Kern Farm Shop,4 Market Lane,8010,Graz,"
        b"shop@example.org,Pickup during shop hours\n",
    ]
)


@pytest.mark.django_db
class TestResellerAndDeliveryStationImport:
    """Both serializers flatten the linked ``ContactEntity``'s columns onto
    themselves, so these two models persist through
    ``ResellerAndDeliveryStationService`` — the path the office create endpoints
    use, and the only one that splits the contact block back off.
    """

    def test_reseller_rows_create_the_reseller_and_its_contact(self, tenant):
        result = import_rows_from_csv("reseller", _RESELLER_CSV)

        assert result.failed == 0, result.errors
        assert result.successful == 2
        shop = Reseller.objects.get(customer_number=4711)
        assert shop.is_reseller is True
        assert shop.contact.company_name == "Kern Farm Shop"
        assert shop.contact.address == "4 Market Lane"
        assert shop.contact.zip_code == "8010"
        # The service pre-fills the invoice block from the contact.
        assert shop.invoice_name == "Kern Farm Shop"
        assert shop.invoice_city == "Graz"

    def test_is_also_delivery_station_links_a_station(self, tenant):
        import_rows_from_csv("reseller", _RESELLER_CSV)

        linked = Reseller.objects.get(customer_number=4712)
        station = DeliveryStation.objects.get(linked_reseller=linked)
        assert station.contact_id == linked.contact_id
        assert not DeliveryStation.objects.filter(
            linked_reseller__customer_number=4711
        ).exists()

    def test_delivery_station_rows_create_the_station_and_its_contact(self, tenant):
        result = import_rows_from_csv("delivery_station", _DELIVERY_STATION_CSV)

        assert result.failed == 0, result.errors
        assert result.successful == 2
        center = DeliveryStation.objects.get(short_name="CENTER")
        assert center.contact.company_name == "Community Center"
        assert center.contact.city == "Graz"
        assert center.info == "Pickup in the back yard"
        assert center.linked_reseller is None

    def test_is_also_reseller_links_a_reseller(self, tenant):
        import_rows_from_csv("delivery_station", _DELIVERY_STATION_CSV)

        shop = DeliveryStation.objects.get(short_name="FARMSHOP")
        assert shop.linked_reseller is not None
        assert shop.linked_reseller.contact_id == shop.contact_id

    def test_a_row_missing_a_required_contact_column_fails_alone(self, tenant):
        csv_bytes = b"".join(
            [
                b"Short name,Company,Address,ZIP,City\n",
                b"short_name,company_name,address,zip_code,city\n",
                b"string,string,string,string,string\n",
                b"NOCITY,Nowhere Depot,1 Empty Street,8030,\n",
                b"CENTER,Community Center,12 Main Street,8020,Graz\n",
            ]
        )

        result = import_rows_from_csv("delivery_station", csv_bytes)

        assert result.successful == 1
        assert result.failed == 1
        assert result.errors[0]["row"] == 4
        assert "city" in result.errors[0]["error"]
        assert not DeliveryStation.objects.filter(short_name="NOCITY").exists()


# The template the extra articles page hands out: the grid locks the unit and
# never shows ``is_extra``, so neither is a column; the page sends both as
# fixed values instead.
_EXTRA_ARTICLE_CSV = b"".join(
    [
        b"Active,Article number,Name,Description\n",
        b"is_active,article_number,name,description\n",
        b"true|false,string,string,string\n",
        b"true,X-100,Gardening course,Two afternoons\n",
        b"\n",
        b"true,X-101,Tractor hire,\n",
    ]
)
_EXTRA_ARTICLE_VALUES = {"is_extra": True, "default_movement_unit": "PCS"}


@pytest.mark.django_db
class TestImportFixedValues:
    def test_template_rows_become_extra_articles_in_pieces(self, tenant):
        result = import_rows_from_csv(
            "share_article",
            _EXTRA_ARTICLE_CSV,
            options=ImportOptions(fixed_values=_EXTRA_ARTICLE_VALUES),
        )

        assert result.failed == 0, result.errors
        assert result.successful == 2
        course = ShareArticle.objects.get(article_number="X-100")
        assert course.is_extra is True
        assert course.default_movement_unit == UnitOptions.PCS
        assert course.description == "Two afternoons"
        assert ShareArticle.objects.get(article_number="X-101").is_extra is True

    def test_fixed_values_win_over_the_files_own_cells(self, tenant):
        csv_bytes = (
            b"name,article_number,is_extra,default_movement_unit\n"
            b"Seed workshop,X-102,false,KG\n"
        )

        result = import_rows_from_csv(
            "share_article",
            csv_bytes,
            options=ImportOptions(fixed_values=_EXTRA_ARTICLE_VALUES),
        )

        assert result.failed == 0, result.errors
        workshop = ShareArticle.objects.get(article_number="X-102")
        assert workshop.is_extra is True
        assert workshop.default_movement_unit == UnitOptions.PCS

    def test_the_dry_run_previews_the_same_rows_and_saves_nothing(self, tenant):
        result = import_rows_from_csv(
            "share_article",
            _EXTRA_ARTICLE_CSV,
            dry_run=True,
            options=ImportOptions(fixed_values=_EXTRA_ARTICLE_VALUES),
        )

        assert result.failed == 0, result.errors
        assert result.successful == 2
        assert not ShareArticle.objects.filter(
            article_number__in=["X-100", "X-101"]
        ).exists()

    @pytest.mark.parametrize("field", ["no_such_field", "can_be_deleted"])
    def test_a_field_the_import_cannot_write_is_refused(self, tenant, field):
        with pytest.raises(DataImportInvalid):
            import_rows_from_csv(
                "share_article",
                _EXTRA_ARTICLE_CSV,
                options=ImportOptions(fixed_values={field: True}),
            )

        assert not ShareArticle.objects.filter(article_number="X-100").exists()

    def test_without_fixed_values_the_share_article_import_is_unchanged(self, tenant):
        csv_bytes = (
            b"Name,Article number,Unit\n"
            b"name,article_number,default_movement_unit\n"
            b"string,string,KG|PCS\n"
            b"Carrots,SA-200,KG\n"
            b"Leeks,SA-201,\n"
        )

        result = import_rows_from_csv("share_article", csv_bytes)

        assert result.successful == 1
        assert result.failed == 1
        assert "default_movement_unit" in result.errors[0]["error"]
        carrots = ShareArticle.objects.get(article_number="SA-200")
        assert carrots.is_extra is False
        assert carrots.default_movement_unit == UnitOptions.KG
