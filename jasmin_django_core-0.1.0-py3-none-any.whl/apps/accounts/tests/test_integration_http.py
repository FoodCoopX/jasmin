"""HTTP-level integration tests for accounts.

These tests exercise the wiring between URLs, views, services, signals,
and JWT/cookie machinery — catching breakage that pure-service tests
would miss.

Endpoints covered:
- POST /api/auth/login/
- POST /api/auth/refresh/
- POST /api/auth/logout/
- POST /api/auth/register/
- GET  /api/auth/invitations/<token>/
- POST /api/auth/invitations/accept/
- GET   /api/auth/admin/users/
- POST  /api/auth/admin/users/
- PATCH /api/auth/admin/users/<id>/
- POST  /api/auth/admin/users/<id>/resend-invitation/

End-to-end flows:
1. Self-registration → office confirms → login succeeds.
2. Admin invite → verify token → accept → login succeeds.
3. Cross-tenant access token replay rejected.
4. Refresh rotates the cookie.
5. Permission gating: non-admin → 403, admin → 200.
"""

from __future__ import annotations

import datetime
from unittest.mock import patch

import pytest
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APIClient

from apps.accounts.models import JasminUser
from apps.authz.roles import Role
from apps.commissioning.models import UserInvitation
from apps.commissioning.tests.factories import JasminUserFactory
from apps.shared.auth_cookies import (
    TENANT_REFRESH_COOKIE,
    TENANT_REFRESH_COOKIE_PATH,
)
from apps.shared.tenants.models import TenantSettings

pytestmark = pytest.mark.django_db


@pytest.fixture
def _self_registration_enabled(tenant):
    """Opt this tenant into public self-registration (the default is off).

    The register endpoints are gated by the ``SelfRegistrationEnabled``
    permission, so the register-flow tests must enable the setting for the
    tenant or every register call 403s with ``auth.self_registration_disabled``.
    """
    TenantSettings.objects.create(
        tenant=tenant,
        valid_from=timezone.now() - datetime.timedelta(seconds=1),
        allows_self_registration=True,
    )
    return tenant


# --------------------------------------------------------------------------- #
# Helpers                                                                      #
# --------------------------------------------------------------------------- #


def _set_password(user, raw):
    user.set_password(raw)
    user.save(update_fields=["password"])


def _login(client, email, password):
    return client.post(
        "/api/auth/login/",
        data={"email": email, "password": password},
        format="json",
    )


# --------------------------------------------------------------------------- #
# /login/                                                                      #
# --------------------------------------------------------------------------- #


class TestLoginEndpoint:
    def test_active_login_sets_refresh_cookie(self, tenant):
        u = JasminUserFactory(email="login@example.com")
        _set_password(u, "Z3rgRushIsScary!42")
        client = APIClient()
        resp = _login(client, "login@example.com", "Z3rgRushIsScary!42")
        assert resp.status_code == status.HTTP_200_OK, resp.data
        assert resp.data["access"]
        assert resp.data["user"]["email"] == "login@example.com"
        assert resp.data["tenant"]["schema_name"] == tenant.schema_name
        cookie = resp.cookies.get(TENANT_REFRESH_COOKIE)
        assert cookie is not None
        assert cookie["httponly"]
        assert cookie["path"] == TENANT_REFRESH_COOKIE_PATH

    def test_login_stamps_last_login(self, tenant):
        # The custom login flow mints tokens directly instead of
        # going through SimpleJWT's TokenObtainPairSerializer, so
        # ``SIMPLE_JWT["UPDATE_LAST_LOGIN"]`` never fires. ``last_login`` must be
        # stamped explicitly on success — otherwise the admin user list shows
        # "never" for everyone.
        u = JasminUserFactory(email="stamp@example.com")
        _set_password(u, "Z3rgRushIsScary!42")
        assert u.last_login is None
        client = APIClient()
        resp = _login(client, "stamp@example.com", "Z3rgRushIsScary!42")
        assert resp.status_code == status.HTTP_200_OK, resp.data
        u.refresh_from_db()
        assert u.last_login is not None

    def test_missing_fields_returns_400(self, tenant):
        client = APIClient()
        resp = client.post("/api/auth/login/", data={}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_non_email_email_returns_400(self, tenant):
        # LoginRequestSerializer.email is an EmailField — a non-email is a
        # serializer 400. (Assert the canonical body, not the German message.)
        resp = APIClient().post(
            "/api/auth/login/",
            data={"email": "not-an-email", "password": "whatever123"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "email" in resp.data["details"]

    def test_missing_password_returns_400(self, tenant):
        resp = APIClient().post(
            "/api/auth/login/", data={"email": "a@b.com"}, format="json"
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "password" in resp.data["details"]

    def test_wrong_password_returns_400(self, tenant):
        u = JasminUserFactory(email="bp@example.com")
        _set_password(u, "GoodPass!42xyz")
        resp = _login(APIClient(), "bp@example.com", "WrongPass!42xyz")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_inactive_user_returns_403_with_helpful_message(self, tenant):
        u = JasminUserFactory(account_status="inactive", email="off@example.com")
        _set_password(u, "Off!Pass42xyz")
        resp = _login(APIClient(), "off@example.com", "Off!Pass42xyz")
        assert resp.status_code == status.HTTP_403_FORBIDDEN
        assert "deactivated" in resp.data["message"].lower()

    def test_pending_approval_returns_403(self, tenant):
        u = JasminUserFactory(account_status="pending_approval")
        _set_password(u, "Pending!42xyzabc")
        resp = _login(APIClient(), u.email, "Pending!42xyzabc")
        assert resp.status_code == status.HTTP_403_FORBIDDEN
        assert "approval" in resp.data["message"].lower()


# --------------------------------------------------------------------------- #
# /refresh/                                                                    #
# --------------------------------------------------------------------------- #


class TestRefreshEndpoint:
    def test_no_cookie_returns_401(self, tenant):
        resp = APIClient().post("/api/auth/refresh/", data={}, format="json")
        assert resp.status_code == status.HTTP_401_UNAUTHORIZED

    def test_cookie_rotation(self, tenant):
        u = JasminUserFactory(email="rot@example.com")
        _set_password(u, "Rotate!42xyzabc")
        client = APIClient()
        login_resp = _login(client, "rot@example.com", "Rotate!42xyzabc")
        assert login_resp.status_code == 200
        old_cookie = client.cookies.get(TENANT_REFRESH_COOKIE).value

        # The refresh endpoint reads from cookies on the client.
        resp = client.post("/api/auth/refresh/", data={}, format="json")
        assert resp.status_code == status.HTTP_200_OK, resp.data
        assert resp.data["access"]
        new_cookie = resp.cookies.get(TENANT_REFRESH_COOKIE)
        assert new_cookie is not None
        assert new_cookie.value != old_cookie  # rotated

    def test_garbage_refresh_returns_401(self, tenant):
        client = APIClient()
        client.cookies[TENANT_REFRESH_COOKIE] = "not-a-jwt"
        resp = client.post("/api/auth/refresh/", data={}, format="json")
        assert resp.status_code == status.HTTP_401_UNAUTHORIZED


# --------------------------------------------------------------------------- #
# /logout/                                                                     #
# --------------------------------------------------------------------------- #


class TestLogoutEndpoint:
    def test_clears_cookie(self, tenant):
        u = JasminUserFactory(email="bye@example.com")
        _set_password(u, "Bye!42xyzabc")
        client = APIClient()
        _login(client, "bye@example.com", "Bye!42xyzabc")
        assert client.cookies.get(TENANT_REFRESH_COOKIE).value
        resp = client.post("/api/auth/logout/", data={}, format="json")
        assert resp.status_code == status.HTTP_200_OK
        # Cleared cookie has empty value + Max-Age 0.
        cleared = resp.cookies.get(TENANT_REFRESH_COOKIE)
        assert cleared is not None
        assert cleared.value == ""

    def test_logout_without_cookie_still_succeeds(self, tenant):
        resp = APIClient().post("/api/auth/logout/", data={}, format="json")
        assert resp.status_code == status.HTTP_200_OK


# --------------------------------------------------------------------------- #
# /register/ + invitation flow                                                 #
# --------------------------------------------------------------------------- #


class TestRegisterEndpoint:
    payload = {
        "first_name": "Reggie",
        "last_name": "Strant",
        "email": "reg@example.com",
        "user_language": "en",
    }

    @pytest.fixture(autouse=True)
    def _email_verified(self, _self_registration_enabled):
        # The final register step requires the email to have passed the code
        # check (register/verify_code/). That flow is tested separately; stub
        # it verified here so these tests focus on the register endpoint.
        with patch(
            "apps.accounts.services.email_verification_service.is_email_verified",
            return_value=True,
        ):
            yield

    def test_self_register_creates_pending_invitation_user(self, tenant):
        resp = APIClient().post("/api/auth/register/", data=self.payload, format="json")
        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        u = JasminUser.objects.get(email="reg@example.com")
        # Created without a usable password; activates via the set-password link.
        assert u.account_status == "pending_invitation"
        assert u.has_usable_password() is False

    def test_register_returns_field_error_on_collision(self, tenant):
        JasminUserFactory(email="dupreg@example.com")
        bad = {**self.payload, "email": "dupreg@example.com"}
        resp = APIClient().post("/api/auth/register/", data=bad, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_register_bad_typed_field_returns_400(self, tenant):
        # is_valid runs before the service: a non-int coop_shares_count 400s.
        bad = {**self.payload, "coop_shares_count": "not-a-number"}
        resp = APIClient().post("/api/auth/register/", data=bad, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "coop_shares_count" in resp.data["details"]


class TestRegistrationEmailVerification:
    """The pre-account email-ownership code flow: send_code / verify_code, and
    the register step's requirement that the email was verified first."""

    @pytest.fixture(autouse=True)
    def _enable_self_registration(self, _self_registration_enabled):
        pass

    def test_send_code_emails_a_code_for_a_new_address(self, tenant):
        with patch("apps.accounts.views.auth_views.schedule_deferred_email") as sched:
            resp = APIClient().post(
                "/api/auth/register/send_code/",
                data={"email": "fresh@example.com", "first_name": "Fresh"},
                format="json",
            )
        assert resp.status_code == status.HTTP_200_OK
        assert sched.called  # a code was actually scheduled

    def test_send_code_skips_existing_user_but_returns_same_body(self, tenant):
        JasminUserFactory(email="taken@example.com")
        with patch("apps.accounts.views.auth_views.schedule_deferred_email") as sched:
            resp = APIClient().post(
                "/api/auth/register/send_code/",
                data={"email": "taken@example.com"},
                format="json",
            )
        # Anti-enumeration: identical 200, but no code emailed to an address
        # that already has an account.
        assert resp.status_code == status.HTTP_200_OK
        assert not sched.called

    def test_verify_code_rejects_a_wrong_code(self, tenant):
        from apps.accounts.services import email_verification_service

        email_verification_service.generate_and_store_code("wrong@example.com")
        resp = APIClient().post(
            "/api/auth/register/verify_code/",
            data={"email": "wrong@example.com", "code": "000000"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "registration.invalid_code"

    def test_correct_code_verifies_and_unblocks_register(self, tenant):
        from apps.accounts.services import email_verification_service

        code = email_verification_service.generate_and_store_code("ok@example.com")
        verify = APIClient().post(
            "/api/auth/register/verify_code/",
            data={"email": "ok@example.com", "code": code},
            format="json",
        )
        assert verify.status_code == status.HTTP_200_OK
        assert verify.data["verified"] is True

        # With the email verified, register succeeds (no is_email_verified stub).
        with patch("apps.shared.invitations._send_invitation_email"):
            reg = APIClient().post(
                "/api/auth/register/",
                data={
                    "first_name": "Ok",
                    "last_name": "Person",
                    "email": "ok@example.com",
                    "user_language": "en",
                },
                format="json",
            )
        assert reg.status_code == status.HTTP_201_CREATED, reg.data

    def test_register_without_a_verified_email_is_rejected(self, tenant):
        resp = APIClient().post(
            "/api/auth/register/",
            data={
                "first_name": "Unverified",
                "last_name": "Person",
                "email": "unverified@example.com",
                "user_language": "en",
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "registration.email_not_verified"


class TestInvitationVerify:
    def test_invalid_token_returns_404(self, tenant):
        # Use a well-formed UUID that doesn't exist as an invitation,
        # so the URL resolves to the view (not the URL-level 404 path).
        resp = APIClient().get(
            "/api/auth/invitations/00000000-0000-0000-0000-000000000000/"
        )
        assert resp.status_code == status.HTTP_404_NOT_FOUND


class TestInvitationAccept:
    def test_missing_fields_returns_400(self, tenant):
        resp = APIClient().post("/api/auth/invitations/accept/", data={}, format="json")
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_invalid_token_returns_400(self, tenant):
        resp = APIClient().post(
            "/api/auth/invitations/accept/",
            data={"token": "00000000-0000-0000-0000-000000000000", "password": "x"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_missing_token_returns_validation_error(self, tenant):
        resp = APIClient().post(
            "/api/auth/invitations/accept/",
            data={"password": "Whatever!Pass42x"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "token" in resp.data["details"]


# --------------------------------------------------------------------------- #
# /admin/users/* — IsAdmin gating                                              #
# --------------------------------------------------------------------------- #


def _step_up_client(user) -> APIClient:
    """Authenticated client whose access token carries a fresh
    ``step_up_verified_at`` claim. ``create`` / ``partial_update`` are step-up
    gated whenever the payload carries a privilege-bearing key — ``roles``,
    ``account_status`` or ``reseller_id`` — so those flows need this rather
    than a bare ``force_authenticate``.
    """
    import time

    from rest_framework_simplejwt.tokens import AccessToken

    token = AccessToken.for_user(user)
    token["step_up_verified_at"] = int(time.time())
    client = APIClient()
    client.force_authenticate(user=user, token=token)
    return client


class TestAdminUsersGating:
    def test_unauthenticated_list_returns_401_or_403(self, tenant):
        resp = APIClient().get("/api/auth/admin/users/")
        assert resp.status_code in (
            status.HTTP_401_UNAUTHORIZED,
            status.HTTP_403_FORBIDDEN,
        )

    def test_non_admin_list_returns_403(self, tenant):
        u = JasminUserFactory(roles=[Role.OFFICE])
        client = APIClient()
        client.force_authenticate(user=u)
        resp = client.get("/api/auth/admin/users/")
        assert resp.status_code == status.HTTP_403_FORBIDDEN

    def test_admin_list_returns_200(self, tenant):
        u = JasminUserFactory(roles=[Role.ADMIN])
        client = APIClient()
        client.force_authenticate(user=u)
        resp = client.get("/api/auth/admin/users/")
        assert resp.status_code == status.HTTP_200_OK
        assert isinstance(resp.data, list)

    def test_admin_create_user(self, tenant, email_config):
        admin = JasminUserFactory(roles=[Role.ADMIN])
        # roles in the payload → step-up gated.
        client = _step_up_client(admin)
        with patch("apps.shared.invitations._send_invitation_email"):
            resp = client.post(
                "/api/auth/admin/users/",
                data={
                    "first_name": "New",
                    "last_name": "User",
                    "email": "newadmin@example.com",
                    "roles": [Role.STAFF],
                },
                format="json",
            )
        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert resp.data["account_status"] == "pending_invitation"

    def test_admin_create_coerces_non_string_name(self, tenant, email_config):
        """``create`` hands the service ``validated_data``, not the raw body.

        The service calls ``.strip()`` on the name fields, so a JSON number
        reached str-only code uncoerced; DRF's CharField now coerces it first.
        """
        admin = JasminUserFactory(roles=[Role.ADMIN])
        client = _step_up_client(admin)
        with patch("apps.shared.invitations._send_invitation_email"):
            resp = client.post(
                "/api/auth/admin/users/",
                data={
                    "first_name": 5,
                    "last_name": "Numeric",
                    "email": "numeric-name@example.com",
                    "roles": [Role.STAFF],
                },
                format="json",
            )
        assert resp.status_code == status.HTTP_201_CREATED, resp.data
        assert resp.data["first_name"] == "5"

    def test_admin_create_missing_email_returns_400(self, tenant):
        admin = JasminUserFactory(roles=[Role.ADMIN])
        client = APIClient()
        client.force_authenticate(user=admin)
        resp = client.post(
            "/api/auth/admin/users/",
            data={"first_name": "New", "last_name": "User"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "email" in resp.data["details"]

    def test_admin_partial_update_empty_body_returns_200(self, tenant):
        # partial=True: an empty PATCH is a valid no-op (200), not a 400.
        admin = JasminUserFactory(roles=[Role.ADMIN])
        target = JasminUserFactory(account_status="active")
        client = APIClient()
        client.force_authenticate(user=admin)
        resp = client.patch(
            f"/api/auth/admin/users/{target.id}/", data={}, format="json"
        )
        assert resp.status_code == status.HTTP_200_OK, resp.data
        assert resp.data["id"] == target.id

    def test_admin_partial_update_renames_user(self, tenant):
        admin = JasminUserFactory(roles=[Role.ADMIN])
        target = JasminUserFactory(account_status="active")
        client = APIClient()
        client.force_authenticate(user=admin)
        resp = client.patch(
            f"/api/auth/admin/users/{target.id}/",
            data={"first_name": "Renamed"},
            format="json",
        )
        assert resp.status_code == status.HTTP_200_OK, resp.data
        assert resp.data["first_name"] == "Renamed"

    def test_admin_partial_update_invalid_choice_returns_400(self, tenant):
        # account_status is a ChoiceField — an invalid choice is rejected by
        # is_valid (which runs on a REAL user id; a bad id would 404 first).
        # It is also privilege-bearing, so the payload is step-up gated and
        # permissions run before validation: without a fresh claim this would
        # 403 before the choice is ever checked.
        admin = JasminUserFactory(roles=[Role.ADMIN])
        target = JasminUserFactory(account_status="active")
        client = _step_up_client(admin)
        resp = client.patch(
            f"/api/auth/admin/users/{target.id}/",
            data={"account_status": "banana"},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "account_status" in resp.data["details"]

    def test_resend_invitation_only_for_pending(self, tenant):
        admin = JasminUserFactory(roles=[Role.ADMIN])
        active_user = JasminUserFactory(account_status="active")
        client = APIClient()
        client.force_authenticate(user=admin)
        resp = client.post(
            f"/api/auth/admin/users/{active_user.id}/resend-invitation/",
            data={},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST

    def test_create_refused_without_the_tenants_smtp(self, tenant):
        """The invitation email is the point of the call; without an SMTP host
        of the tenant's own nothing is created."""
        admin = JasminUserFactory(roles=[Role.ADMIN])
        client = _step_up_client(admin)
        resp = client.post(
            "/api/auth/admin/users/",
            data={
                "first_name": "New",
                "last_name": "User",
                "email": "no-smtp@example.com",
                "roles": [Role.STAFF],
            },
            format="json",
        )
        assert resp.status_code == status.HTTP_409_CONFLICT, resp.data
        assert resp.data["code"] == "email_config.sending_not_set_up"
        assert not JasminUser.objects.filter(email="no-smtp@example.com").exists()

    def test_resend_refused_without_the_tenants_smtp(self, tenant):
        from apps.shared.invitations import create_user_with_invitation

        admin = JasminUserFactory(roles=[Role.ADMIN])
        with patch("apps.shared.invitations._send_invitation_email"):
            pending, invitation = create_user_with_invitation(
                email="pending-staff@example.com",
                first_name="Pat",
                last_name="Pending",
                roles=[Role.STAFF],
            )
        client = APIClient()
        client.force_authenticate(user=admin)
        resp = client.post(
            f"/api/auth/admin/users/{pending.id}/resend-invitation/",
            data={},
            format="json",
        )
        assert resp.status_code == status.HTTP_409_CONFLICT, resp.data
        assert resp.data["code"] == "email_config.sending_not_set_up"
        assert list(UserInvitation.objects.filter(user=pending)) == [invitation]


# --------------------------------------------------------------------------- #
# End-to-end flows                                                             #
# --------------------------------------------------------------------------- #


class TestEndToEndSelfRegistration:
    @pytest.fixture(autouse=True)
    def _enable_self_registration(self, _self_registration_enabled):
        pass

    def test_full_flow(self, tenant):
        from apps.commissioning.models import UserInvitation

        client = APIClient()
        # 1. Self-register (email already proven via the code step; the
        #    account is created WITHOUT a password + a set-password link is
        #    emailed). Patch the send so the test doesn't hit the mail stack.
        with (
            patch(
                "apps.accounts.services.email_verification_service.is_email_verified",
                return_value=True,
            ),
            patch("apps.shared.invitations._send_invitation_email"),
        ):
            reg = client.post(
                "/api/auth/register/",
                data={
                    "first_name": "E2E",
                    "last_name": "Reg",
                    "email": "e2e_reg@example.com",
                    "user_language": "en",
                },
                format="json",
            )
        assert reg.status_code == status.HTTP_201_CREATED, reg.data
        user = JasminUser.objects.get(email="e2e_reg@example.com")
        assert user.account_status == "pending_invitation"

        # 2. Login is blocked until the applicant sets a password. With no
        #    usable password yet the credential check fails first (400), which
        #    also avoids leaking that the address exists.
        blocked = _login(client, "e2e_reg@example.com", "not-set-yet-xyz")
        assert blocked.status_code == status.HTTP_400_BAD_REQUEST

        # 3. Applicant sets their password via the emailed invitation link.
        invitation = UserInvitation.objects.get(user=user)
        accept = client.post(
            "/api/auth/invitations/accept/",
            data={"token": str(invitation.token), "password": "E2EReg!42xyzabc"},
            format="json",
        )
        assert accept.status_code == status.HTTP_200_OK, accept.data

        # 4. Login now succeeds.
        ok = _login(client, "e2e_reg@example.com", "E2EReg!42xyzabc")
        assert ok.status_code == status.HTTP_200_OK, ok.data
        assert ok.data["access"]


class TestEndToEndInvitation:
    def test_full_flow(self, tenant, email_config):
        admin = JasminUserFactory(roles=[Role.ADMIN])
        # roles in the create payload → step-up gated.
        admin_client = _step_up_client(admin)

        # 1. Admin creates the user (which mints an invitation).
        with patch("apps.shared.invitations._send_invitation_email"):
            create_resp = admin_client.post(
                "/api/auth/admin/users/",
                data={
                    "first_name": "E2E",
                    "last_name": "Inv",
                    "email": "e2e_inv@example.com",
                    "roles": [Role.OFFICE],
                },
                format="json",
            )
        assert create_resp.status_code == 201, create_resp.data

        invitation = UserInvitation.objects.get(email="e2e_inv@example.com")

        # 2. Anonymous client verifies the token.
        anon = APIClient()
        verify = anon.get(f"/api/auth/invitations/{invitation.token}/")
        assert verify.status_code == status.HTTP_200_OK
        assert verify.data["email"] == "e2e_inv@example.com"

        # 3. Anonymous client posts a new password.
        accept = anon.post(
            "/api/auth/invitations/accept/",
            data={
                "token": str(invitation.token),
                "password": "InvE2E!42xyzabc",
            },
            format="json",
        )
        assert accept.status_code == status.HTTP_200_OK, accept.data

        # 4. The user can now log in.
        login = _login(anon, "e2e_inv@example.com", "InvE2E!42xyzabc")
        assert login.status_code == status.HTTP_200_OK, login.data


class TestCrossTenantTokenRejection:
    def test_token_for_other_tenant_is_rejected(self, tenant):
        """Mint an access token with a foreign tenant_id claim and confirm
        the JWT auth class refuses it on a protected endpoint."""
        admin = JasminUserFactory(roles=[Role.ADMIN])
        from rest_framework_simplejwt.tokens import AccessToken

        token = AccessToken.for_user(admin)
        token["tenant_id"] = "some-other-tenant"
        client = APIClient()
        client.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
        resp = client.get("/api/auth/admin/users/")
        # TenantBoundJWTAuthentication raises InvalidToken → 401.
        assert resp.status_code == status.HTTP_401_UNAUTHORIZED

    def test_token_for_correct_tenant_passes(self, tenant):
        admin = JasminUserFactory(roles=[Role.ADMIN])
        from rest_framework_simplejwt.tokens import AccessToken

        token = AccessToken.for_user(admin)
        token["tenant_id"] = tenant.schema_name
        client = APIClient()
        client.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
        resp = client.get("/api/auth/admin/users/")
        assert resp.status_code == status.HTTP_200_OK


class TestRefreshCookieRotation:
    def test_old_refresh_blacklisted_after_rotation(self, tenant):
        u = JasminUserFactory(email="rotbl@example.com")
        _set_password(u, "RotBL!42xyzabc")
        client = APIClient()
        login = _login(client, "rotbl@example.com", "RotBL!42xyzabc")
        assert login.status_code == 200
        old_cookie = client.cookies.get(TENANT_REFRESH_COOKIE).value

        # First refresh: rotates and blacklists the old cookie.
        first = client.post("/api/auth/refresh/", data={}, format="json")
        assert first.status_code == 200
        new_cookie = client.cookies.get(TENANT_REFRESH_COOKIE).value
        assert new_cookie != old_cookie

        # Replaying the OLD refresh should now fail.
        replay_client = APIClient()
        replay_client.cookies[TENANT_REFRESH_COOKIE] = old_cookie
        replay = replay_client.post("/api/auth/refresh/", data={}, format="json")
        assert replay.status_code == status.HTTP_401_UNAUTHORIZED


# --------------------------------------------------------------------------- #
# PATCH /api/auth/<user_id>/ — self profile update                             #
# --------------------------------------------------------------------------- #


class TestProfileUpdateEndpoint:
    def test_update_own_profile_returns_200(self, tenant):
        user = JasminUserFactory(roles=[Role.OFFICE])
        client = APIClient()
        client.force_authenticate(user=user)
        resp = client.patch(
            f"/api/auth/{user.id}/", data={"first_name": "Renamed"}, format="json"
        )
        assert resp.status_code == status.HTTP_200_OK, resp.data
        assert resp.data["first_name"] == "Renamed"

    def test_bad_typed_field_returns_400(self, tenant):
        # All profile fields are optional, so the serializer 400 is a wrong type
        # (a list where a CharField is expected).
        user = JasminUserFactory(roles=[Role.OFFICE])
        client = APIClient()
        client.force_authenticate(user=user)
        resp = client.patch(
            f"/api/auth/{user.id}/",
            data={"user_language": ["de", "en"]},
            format="json",
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "user_language" in resp.data["details"]

    def test_editing_other_user_returns_403(self, tenant):
        # The own-id permission check runs ABOVE serializer validation.
        user = JasminUserFactory(roles=[Role.OFFICE])
        other = JasminUserFactory(roles=[Role.OFFICE])
        client = APIClient()
        client.force_authenticate(user=user)
        resp = client.patch(
            f"/api/auth/{other.id}/", data={"first_name": "X"}, format="json"
        )
        assert resp.status_code == status.HTTP_403_FORBIDDEN

    def test_over_long_name_returns_400_naming_the_field(self, tenant):
        # The serializer bounds the field to its column width, so the refusal
        # is a per-field validation error and the value never reaches Postgres.
        user = JasminUserFactory(roles=[Role.OFFICE])
        client = APIClient()
        client.force_authenticate(user=user)
        long_name = "N" * 300
        resp = client.patch(
            f"/api/auth/{user.id}/", data={"first_name": long_name}, format="json"
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert resp.data["code"] == "validation_error"
        assert "first_name" in resp.data["details"]
        assert long_name not in str(resp.data)
        assert "varying" not in str(resp.data)

    def test_name_at_the_column_limit_is_accepted(self, tenant):
        # The bound matches the column exactly — a 255-char name must still save.
        user = JasminUserFactory(roles=[Role.OFFICE])
        client = APIClient()
        client.force_authenticate(user=user)
        resp = client.patch(
            f"/api/auth/{user.id}/", data={"first_name": "N" * 255}, format="json"
        )
        assert resp.status_code == status.HTTP_200_OK, resp.data
