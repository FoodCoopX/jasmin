"""ViewSets for the accounts app.

The auth-flow RPC endpoints (login, refresh, logout, password reset,
invitation accept, self-register, step-up, 2FA) live in the ``views``
package. The endpoints here all operate on the same "tenant user"
resource and benefit from the standard ViewSet shape — including the
``RolePermissionsMixin`` read/write split.
"""

from __future__ import annotations

from drf_spectacular.utils import extend_schema
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.viewsets import ViewSet

from apps.authz.permissions import IsAdmin, RolePermissionsMixin
from apps.shared.request_utils import auth_user
from core.serializers import ErrorResponseSerializer

from .errors import UserNotFound, UserNotPendingInvitation
from .models import JasminUser
from .permissions import RequiresStepUp
from .serializers import (
    AdminUserCreateRequestSerializer,
    AdminUserRowSerializer,
    AdminUserUpdateRequestSerializer,
)
from .services import (
    create_user_with_invite,
    list_active_users,
    serialize_user_row,
    update_user_admin,
)


class AdminUserViewSet(RolePermissionsMixin, ViewSet):
    """Admin endpoints for managing tenant users.

    All operations require the ``admin`` role. Wired into ``/admin/users/``
    by ``apps.accounts.urls`` via ``DefaultRouter``.
    """

    read_permission = IsAdmin
    write_permission = IsAdmin

    # Payload keys that change what a user can do, each of which must cost a
    # fresh password. ``roles`` assigns any role, ``admin`` included. A
    # deactivated account keeps its role list, so ``account_status`` back to
    # ``active`` restores whatever privilege the row already held — the same
    # grant as writing ``roles``, reached without the key. ``reseller_id``
    # binds a customer login to a reseller's data.
    _PRIVILEGE_FIELDS = frozenset({"roles", "account_status", "reseller_id"})

    def get_permissions(self):
        """Step-up-gate privilege grants. ``create`` / ``partial_update`` route
        into ``create_user_with_invite`` / ``update_user_admin``, which can
        escalate through any key in ``_PRIVILEGE_FIELDS`` — something a stolen
        session token alone must not be able to fire (mirrors the super-admin
        ``TenantManagementViewSet.update_user_roles`` gate). Edits touching
        none of those keys (name, contact, …) pass through unprompted.
        Inspected on ``request.data`` rather than via
        ``requires_step_up_for_fields`` because this is a plain ``ViewSet`` —
        it never calls ``check_object_permissions``, so an object-level gate
        would silently never fire.
        """
        perms = super().get_permissions()
        data = getattr(self.request, "data", None) or {}
        if self.action in {"create", "partial_update"} and any(
            field in data for field in self._PRIVILEGE_FIELDS
        ):
            perms.append(RequiresStepUp())
        return perms

    @extend_schema(
        summary="List tenant users (admin)",
        responses={
            200: AdminUserRowSerializer(many=True),
            401: ErrorResponseSerializer,
            403: ErrorResponseSerializer,
        },
    )
    def list(self, request: Request) -> Response:
        return Response(list_active_users())

    @extend_schema(
        summary="Create a tenant user and send invitation email (admin)",
        request=AdminUserCreateRequestSerializer,
        responses={
            201: AdminUserRowSerializer,
            400: ErrorResponseSerializer,
            401: ErrorResponseSerializer,
            403: ErrorResponseSerializer,
            # ``EmailSendingNotSetUp``: the tenant has no SMTP host of its own.
            409: ErrorResponseSerializer,
        },
    )
    def create(self, request: Request) -> Response:
        from apps.shared.tenants.email_service import assert_tenant_can_send_email

        serializer = AdminUserCreateRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        # The invitation email is the point of this call; without the tenant's
        # own SMTP it would be skipped and the pending login left waiting.
        assert_tenant_can_send_email()
        # Hand the service validated_data, as partial_update does: the service
        # reads by key and calls ``.strip()`` on the name fields, so a raw
        # ``{"first_name": 5}`` would reach str-only code uncoerced. The
        # business rules (role combinations, member-role guard,
        # reseller/customer coupling) stay in the service; this only guarantees
        # the values it reads are the coerced ones.
        payload = create_user_with_invite(
            data=serializer.validated_data, created_by=auth_user(request)
        )
        return Response(payload, status=status.HTTP_201_CREATED)

    @extend_schema(
        summary="Update a tenant user (admin)",
        request=AdminUserUpdateRequestSerializer,
        responses={
            200: AdminUserRowSerializer,
            400: ErrorResponseSerializer,
            401: ErrorResponseSerializer,
            403: ErrorResponseSerializer,
            404: ErrorResponseSerializer,
        },
    )
    def partial_update(self, request: Request, pk: str | None = None) -> Response:
        try:
            user = JasminUser.objects.get(id=pk)
        except JasminUser.DoesNotExist as exc:
            raise UserNotFound("User not found") from exc
        serializer = AdminUserUpdateRequestSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        # validated_data preserves the absent-vs-null membership the service
        # relies on (absent key → field untouched; null → unlink).
        payload = update_user_admin(
            user=user, data=serializer.validated_data, actor=auth_user(request)
        )
        return Response(payload)

    @extend_schema(
        summary="Re-send invitation email to a user still in pending_invitation",
        description=(
            "Cancels the user's open invitation, creates a new one and emails "
            "it. For a member's portal login (no internal and no customer "
            "role) the invitation is a member email: refused with 409 while "
            "the tenant's onboarding mode is on, before any invitation is "
            "created or quota is used, as members/{id}/send_invitation is. "
            "Every resend is refused with 409 while the tenant has no SMTP "
            "host of its own."
        ),
        request=None,
        responses={
            200: AdminUserRowSerializer,
            400: ErrorResponseSerializer,
            401: ErrorResponseSerializer,
            403: ErrorResponseSerializer,
            404: ErrorResponseSerializer,
            # ``EmailActionBlockedInOnboardingMode`` or ``EmailSendingNotSetUp``.
            409: ErrorResponseSerializer,
        },
    )
    @action(detail=True, methods=["post"], url_path="resend-invitation")
    def resend_invitation(self, request: Request, pk: str | None = None) -> Response:
        from apps.authz.roles import is_member_portal_login
        from apps.commissioning.services.onboarding_policy import (
            assert_member_email_action_allowed,
        )
        from apps.shared.invitations import resend_invitation
        from apps.shared.tenants.email_service import assert_tenant_can_send_email
        from apps.shared.tenants.onboarding_emails import EmailCategory

        try:
            user = JasminUser.objects.get(id=pk)
        except JasminUser.DoesNotExist as exc:
            raise UserNotFound("User not found") from exc
        if user.account_status != "pending_invitation":
            raise UserNotPendingInvitation("User is not waiting for an invitation.")
        member_portal_login = is_member_portal_login(user.roles)
        if member_portal_login:
            # Onboarding mode, then the tenant's SMTP.
            assert_member_email_action_allowed()
        else:
            assert_tenant_can_send_email()
        resend_invitation(
            user=user,
            created_by=auth_user(request),
            email_category=(
                EmailCategory.MEMBER_LIFECYCLE
                if member_portal_login
                else EmailCategory.GENERAL
            ),
        )
        return Response(serialize_user_row(user))

    @extend_schema(
        summary="Cancel a pending invitation (admin)",
        description=(
            "Revokes the outstanding invitation link for a user who has not "
            "accepted yet. The account row is kept, so a cancellation made in "
            "error is undone by resending rather than by re-provisioning."
        ),
        request=None,
        responses={
            200: AdminUserRowSerializer,
            400: ErrorResponseSerializer,
            401: ErrorResponseSerializer,
            403: ErrorResponseSerializer,
            404: ErrorResponseSerializer,
        },
    )
    @action(detail=True, methods=["post"], url_path="cancel-invitation")
    def cancel_invitation(self, request: Request, pk: str | None = None) -> Response:
        from apps.shared.invitations import cancel_invitation

        try:
            user = JasminUser.objects.get(id=pk)
        except JasminUser.DoesNotExist as exc:
            raise UserNotFound("User not found") from exc
        if user.account_status != "pending_invitation":
            raise UserNotPendingInvitation("User is not waiting for an invitation.")
        cancel_invitation(user=user, cancelled_by=auth_user(request))
        return Response(serialize_user_row(user))
