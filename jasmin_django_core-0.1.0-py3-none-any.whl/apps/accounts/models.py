import logging
import uuid
from typing import Any

from django.contrib.auth.models import (
    AbstractBaseUser,
    BaseUserManager,
    PermissionsMixin,
)
from django.core.exceptions import ValidationError
from django.db import IntegrityError, models
from django.db.models import F, Q
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from nanoid import generate

from apps.authz.roles import VALID_ROLES, Role
from apps.shared.languages import LanguageChoices
from .choices import ThemeChoices
from .constants import ID_LENGTH, JASMIN_ID_ALPHABET

logger = logging.getLogger(__name__)


def generate_jasmin_id() -> str:
    return generate(alphabet=JASMIN_ID_ALPHABET, size=ID_LENGTH)


def _clean_role_list(roles) -> tuple[list[str], list[str]]:
    """Split ``roles`` into ``(known, unknown)``, de-duplicated, order kept.

    A non-sequence yields nothing known. That guard is load-bearing rather
    than defensive: every membership test here is ``in``-based, so a bare
    string would be matched a character at a time — ``roles="superadmin"``
    would satisfy a check for ``"admin"``.
    """
    if not isinstance(roles, (list, tuple, set, frozenset)):
        return [], []
    known: list[str] = []
    unknown: list[str] = []
    for role in roles:
        bucket = known if role in VALID_ROLES else unknown
        if role not in bucket:
            bucket.append(role)
    return known, unknown


class JasminModel(models.Model):
    id = models.CharField(
        "ID",
        max_length=ID_LENGTH,
        unique=True,
        primary_key=True,
        default=generate_jasmin_id,
        editable=False,
    )

    class Meta:
        abstract = True

    def save(self, *args: Any, **kwargs: Any) -> None:
        """Save with retry logic for primary-key (nanoid) collision.

        Detects PK collisions specifically by inspecting the failing
        constraint, instead of substring-matching on the error message
        (which could swallow other unique-constraint failures that happen to
        mention the word "id").
        """
        max_retries = 5
        for attempt in range(max_retries):
            try:
                super().save(*args, **kwargs)
                return
            except IntegrityError as e:
                if self._is_pk_collision(e) and attempt < max_retries - 1:
                    self.id = generate_jasmin_id()
                else:
                    raise

    def _is_pk_collision(self, exc: IntegrityError) -> bool:
        """Return True iff the IntegrityError is a duplicate on the PK.

        Uses the psycopg constraint name when available
        (PostgreSQL convention: ``<table>_pkey``) and falls back to a
        narrower string match.
        """
        cause = exc.__cause__
        constraint_name = getattr(getattr(cause, "diag", None), "constraint_name", None)
        if constraint_name:
            return constraint_name.endswith("_pkey")
        # Fallback for non-PG backends or when diag is unavailable.
        msg = str(exc).lower()
        return "_pkey" in msg

    def get_display_id(self) -> str:
        """
        Convert the nanoid to a human-readable format.
        Examples:
            'aBc123XyZ' -> 'ABC-123-XYZ'
            'xK9mP2nQ4' -> 'XK9-MP2-NQ4'
        """
        if not self.id:
            return ""

        # Convert to uppercase for better readability
        readable_id = self.id.upper()

        # Split into groups of 3 characters with dashes
        CHUNK_SIZE = 3
        chunks = [
            readable_id[i : i + CHUNK_SIZE]
            for i in range(0, len(readable_id), CHUNK_SIZE)
        ]

        return "-".join(chunks)


# =========================================================================== #
# Account-status state machine                                                 #
#                                                                              #
# - "pending_invitation": user provisioned by an admin invitation; password    #
#   not set yet. Cannot log in until they accept and set a password.           #
# - "pending_approval":   user self-registered (always with a Member row);     #
#   password is set but admin has not yet confirmed the linked Member. Cannot  #
#   log in until office confirms the member.                                   #
# - "active":             allowed to log in.                                   #
# - "inactive":           blocked. Reachable only via admin action.            #
#                                                                              #
# `is_active` is DERIVED from `account_status` in `JasminUser.save()`. Never    #
# set it by hand.                                                              #
# =========================================================================== #
ACCOUNT_STATUS_CHOICES = [
    ("active", "Active"),
    ("pending_approval", "Pending Admin Approval"),
    ("pending_invitation", "Pending Invitation"),
    ("inactive", "Inactive"),
]





class JasminUserManager(BaseUserManager):
    def create_user(self, first_name, last_name, email, password=None, **kwargs):
        if first_name is None:
            raise TypeError(_("Users must have a first name."))
        if last_name is None:
            raise TypeError(_("Users must have a last name."))
        if email is None:
            raise TypeError(_("Users must have an email address."))
        if password is None:
            raise TypeError("User must have a password.")

        kwargs["first_name"] = first_name
        kwargs["last_name"] = last_name
        kwargs["email"] = self.normalize_email(email)
        kwargs.setdefault("username", kwargs["email"].lower())

        user = self.model(**kwargs)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, first_name, last_name, email, password=None, **kwargs):
        kwargs.setdefault("account_status", "active")
        kwargs.setdefault("roles", [Role.ADMIN])
        user = self.create_user(first_name, last_name, email, password, **kwargs)
        user.is_superuser = True
        user.save(using=self._db)
        return user


class JasminUser(JasminModel, AbstractBaseUser, PermissionsMixin):
    """Custom user model. Each user exists globally per tenant schema."""

    public_id = models.UUIDField(
        db_index=True, unique=True, default=uuid.uuid4, editable=False
    )
    username = models.CharField(db_index=True, max_length=255, unique=True)

    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.EmailField(db_index=True, unique=True)
    avatar = models.ImageField(upload_to="avatars/", blank=True, null=True)

    account_status = models.CharField(
        max_length=20,
        choices=ACCOUNT_STATUS_CHOICES,
        default="pending_invitation",
    )
    # NOTE: derived from `account_status` in `save()`. Do not set by hand.
    # Kept as a separate column because Django auth, the admin site, password
    # reset views and SimpleJWT all read `is_active`.
    is_active = models.BooleanField(default=False)

    user_language = models.CharField(
        max_length=3,
        choices=LanguageChoices.choices,
        default=LanguageChoices.EN,
    )
    sidebar_collapsed = models.BooleanField(default=False)
    theme = models.CharField(
        max_length=10,
        choices=ThemeChoices.choices,
        default=ThemeChoices.SYSTEM,
    )
    edit_mode = models.CharField(
        max_length=10,
        choices=[("inline", "Inline Editing"), ("modal", "Modal Editing")],
        default="inline",
    )
    roles = models.JSONField(
        default=list, blank=True, null=True, help_text="List of roles this user has"
    )

    date_joined = models.DateTimeField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_login_ip = models.GenericIPAddressField(blank=True, null=True)

    # Server-side session cut-off: any refresh token minted before this instant
    # is rejected by ``refresh_access_token``. Stamped on password
    # reset and "log out everywhere" so a stolen refresh token can't be
    # rotated forward indefinitely past a credential change. NULL = never
    # revoked. Robust against rotation (which mints new JTIs outside
    # ``OutstandingToken``); the token's ``iat`` is what's compared.
    sessions_revoked_at = models.DateTimeField(blank=True, null=True, editable=False)

    # Status-transition timestamps. Maintained by ``save()`` whenever
    # ``account_status`` flips. Both can be None for legacy rows that
    # existed before these columns were added.
    activated_at = models.DateTimeField(blank=True, null=True)
    inactivated_at = models.DateTimeField(blank=True, null=True)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["first_name", "last_name"]

    objects = JasminUserManager()

    class Meta:
        indexes = [
            models.Index(fields=["public_id"]),
            models.Index(fields=["email"]),
        ]
        constraints = [
            # A user can only be activated on/after they joined. NULL-tolerant:
            # a stamp that has never been set imposes no ordering.
            #
            # NOTE: there is intentionally NO inactivated_at >= activated_at
            # constraint. ``activated_at`` / ``inactivated_at`` track the *most
            # recent* activation and the *most recent* inactivation
            # independently. Re-activation (the allowed inactive -> active
            # transition) legitimately stamps a new ``activated_at`` that is
            # later than a prior ``inactivated_at``, so their relative order is
            # not an invariant.
            models.CheckConstraint(
                condition=(
                    Q(activated_at__isnull=True)
                    | Q(date_joined__isnull=True)
                    | Q(activated_at__gte=F("date_joined"))
                ),
                name="jasminuser_activated_after_joined",
            ),
        ]

    def __str__(self) -> str:
        # Not the username, which is the email address: django-auditlog keeps
        # ``str()`` of every logged user as the entry's label, out of reach of
        # the field masking, for as long as the entry exists.
        return f"User {self.pk}"

    # ------------------------------------------------------------------ #
    # Invariants                                                          #
    # ------------------------------------------------------------------ #

    def clean(self):
        super().clean()
        _known, invalid = _clean_role_list(self.roles)
        if invalid:
            raise ValidationError(
                {
                    "roles": ValidationError(
                        "Invalid role(s): %(invalid)s",
                        code="invalid_roles",
                        params={"invalid": ", ".join(invalid)},
                    )
                }
            )

        # Activation stamp must not predate the join date. NULL-tolerant: only
        # enforced when both ends of the pair are set.
        #
        # There is intentionally no inactivated_at-vs-activated_at check: those
        # two stamps track the most recent activation / inactivation
        # independently, and re-activation legitimately makes activated_at the
        # later of the two.
        if (
            self.activated_at is not None
            and self.date_joined is not None
            and self.activated_at < self.date_joined
        ):
            raise ValidationError(
                {
                    "activated_at": ValidationError(
                        "Activation cannot be before the join date.",
                        code="activated_before_joined",
                    )
                }
            )

    def save(self, *args, **kwargs):
        # Single source of truth: is_active is derived from account_status.
        self.is_active = self.account_status == "active"

        # Normalise roles on EVERY write, so the invariant holds for plain
        # ``user.roles = [...]`` assignments rather than only the paths that
        # remember to call ``set_roles``. Drop-and-log instead of raising: a
        # row that already holds an illegal value has to stay saveable, or
        # nobody — including an admin trying to fix the roles — could write to
        # it at all. ``update_fields`` is deliberately left alone; persisting a
        # column the caller never listed could clobber a concurrent change.
        known_roles, unknown_roles = _clean_role_list(self.roles)
        if unknown_roles:
            logger.warning(
                "jasmin_user.unknown_roles_dropped user=%s dropped=%s",
                self.pk,
                sorted(unknown_roles),
            )
        if known_roles != (self.roles or []):
            self.roles = known_roles

        # Track status-transition timestamps. We only stamp the
        # ``activated_at`` / ``inactivated_at`` fields when the status
        # actually changes (or on the first save with a terminal status).
        update_fields = kwargs.get("update_fields")
        previous_status: str | None = (
            type(self)
            .objects.filter(pk=self.pk)
            .values_list("account_status", flat=True)
            .first()
        )
        now = timezone.now()
        stamped: list[str] = []
        if self.account_status == "active" and previous_status != "active":
            self.activated_at = now
            stamped.append("activated_at")
        if self.account_status == "inactive" and previous_status != "inactive":
            self.inactivated_at = now
            stamped.append("inactivated_at")

        if update_fields is not None:
            extra = {"is_active"}
            if "account_status" in update_fields:
                extra.update(stamped)
            kwargs["update_fields"] = list({*update_fields, *extra})
        super().save(*args, **kwargs)

    # ------------------------------------------------------------------ #
    # Convenience accessors                                               #
    # ------------------------------------------------------------------ #

    @property
    def name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()

    def get_full_name(self) -> str:
        return self.name

    def has_any_role(self, roles) -> bool:
        # ``save()`` normalises, but an unsaved instance can hold anything, and
        # a bare string would turn this into a substring test — see
        # ``_clean_role_list``.
        own = self.roles if isinstance(self.roles, (list, tuple)) else []
        return any(r in own for r in roles)

    # ------------------------------------------------------------------ #
    # Role mutators                                                       #
    # ------------------------------------------------------------------ #

    def set_roles(self, roles) -> None:
        """Validate, de-duplicate, assign.

        Raises on an unknown role, unlike ``save()`` which drops and logs: a
        caller reaching for this method is stating the roles explicitly, so a
        typo should be refused rather than quietly discarded.
        """
        known, invalid = _clean_role_list(roles)
        if invalid:
            raise ValidationError(
                "Invalid role(s): %(invalid)s",
                code="invalid_roles",
                params={"invalid": ", ".join(invalid)},
            )
        self.roles = known
