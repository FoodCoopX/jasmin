from __future__ import annotations

import datetime
from collections import defaultdict
from collections.abc import Callable
from decimal import Decimal
from typing import Any

from django.db import transaction
from django.db.models import QuerySet
from django.utils import timezone
from isoweek import Week

from apps.shared.money import round_money

from ..errors import (
    CommissioningError,
    DefaultShareContentNoRunningWeek,
    RequiredFieldMissing,
    ResellerNotFound,
    ShareArticleNotFound,
)
from ..models import (
    DefaultShareContent,
    DeliveryStationDay,
    MovementShareArticle,
    Reseller,
    Share,
    ShareArticle,
    ShareContent,
    SharesDeliveryDay,
    ShareTypeVariation,
)
from ..utils.composite_id_utils import compose_slot_id
from ..utils.dynamic_keys import (
    SCAFFOLD_VALUES,
    extract_amounts_from_keys,
    parse_amount_cell,
)
from .planning_slots import in_share_option, refuse_variations_outside
from .planning_subscriber_counts import (
    subscriber_counts_by_variation,
)

# Share lookup key: (year, delivery_week, delivery_day_id, share_type_variation_id)
_ShareKey = tuple[int, int, int, str]


class DefaultShareContentService:
    # ──────────────────────────────────────────────
    # Private helpers
    # ──────────────────────────────────────────────

    @staticmethod
    def _filter_weeks(
        week_range: range,
        *,
        only_odd: bool = False,
        only_even: bool = False,
        only_every_three: bool = False,
    ) -> list[int]:
        """Apply odd/even/every-three-week filters to a range of weeks."""
        filtered: list[int] = []
        for i, week in enumerate(week_range):
            if only_odd and week % 2 == 0:
                continue
            if only_even and week % 2 != 0:
                continue
            if only_every_three and i % 3 != 0:
                continue
            filtered.append(week)
        return filtered

    @staticmethod
    def _get_future_weeks(
        year: int,
        weeks: list[int],
        current_date: datetime.date,
    ) -> list[tuple[int, datetime.date]]:
        """Return (week_number, monday_date) pairs for weeks on or after current_date."""
        result: list[tuple[int, datetime.date]] = []
        for week in weeks:
            monday = Week(year, week).monday()
            if monday >= current_date:
                result.append((week, monday))
        return result

    @staticmethod
    def _prefetch_delivery_data(
        future_weeks: list[tuple[int, datetime.date]],
    ) -> tuple[
        dict[datetime.date, list],
        dict[tuple[datetime.date, Any], list],
    ]:
        """Prefetch delivery days and station relationships for future weeks.

        Returns:
            (delivery_days_by_date, delivery_station_days) — the stations keyed
            by (the week's Monday, delivery day id).
        """
        # A farm has a handful of delivery days: one query, matched per week.
        all_days = list(SharesDeliveryDay.objects.all())
        delivery_days_by_date: dict[datetime.date, list] = {
            date: days
            for _week, date in future_weeks
            if (days := [day for day in all_days if day.is_active_at(date)])
        }

        # Each day's stations per week: the station-days running that week, of
        # stations still delivering.
        day_ids_by_date = {
            date: {day.id for day in days}
            for date, days in delivery_days_by_date.items()
        }
        delivery_station_days: dict[tuple[datetime.date, Any], list] = defaultdict(list)
        for station_day in DeliveryStationDay.objects.filter(
            delivery_day_id__in=set().union(*day_ids_by_date.values()),
            delivery_station__is_active=True,
        ).select_related("delivery_station"):
            for date, day_ids in day_ids_by_date.items():
                if station_day.delivery_day_id in day_ids and station_day.is_active_at(
                    date
                ):
                    key = (date, station_day.delivery_day_id)
                    delivery_station_days[key].append(station_day.delivery_station)

        return delivery_days_by_date, dict(delivery_station_days)

    @staticmethod
    def _prefetch_existing_shares(
        year: int,
        week_range: range,
        variations: list[ShareTypeVariation],
        delivery_days: list,
    ) -> dict[_ShareKey, Share]:
        """Build a lookup dict of existing Share objects."""
        if not variations or not delivery_days:
            return {}

        existing: dict[_ShareKey, Share] = {}
        for share in Share.objects.filter(
            year=year,
            delivery_week__in=week_range,
            share_type_variation__in=variations,
            delivery_day__in=delivery_days,
        ).select_related("delivery_day"):
            key = (
                share.year,
                share.delivery_week,
                share.delivery_day_id,
                share.share_type_variation_id,
            )
            existing[key] = share

        # Self-heal reused shares that an earlier bulk_create left with NULL
        # day fields — otherwise the ShareContent we attach to them would be
        # planned without its theoretical amounts (see ``DAY_FIELD_DEFAULTS``).
        Share.heal_day_fields(existing.values())
        return existing

    @staticmethod
    def _detect_week_pattern(
        weeks: list[int],
        range_1: int,
        range_2: int,
        running_weeks: set[int] | None = None,
    ) -> tuple[bool, bool, bool]:
        """Detect whether weeks follow odd / even / every-three-weeks patterns.

        ``running_weeks`` are the weeks a slot's sizes run in, the only ones a
        size gets rows for; a pattern is read against them and the weeks the
        slot already has rows in.

        Returns:
            (only_odd_weeks, only_even_weeks, only_every_three_weeks)
        """
        weeks_set = set(weeks)
        allowed = None if running_weeks is None else running_weeks | weeks_set

        def expected(keep: Callable[[int], bool]) -> set[int]:
            return {
                week
                for week in range(range_1, range_2 + 1)
                if keep(week) and (allowed is None or week in allowed)
            }

        only_odd = weeks_set == expected(lambda week: week % 2 != 0)
        only_even = weeks_set == expected(lambda week: week % 2 == 0)
        only_every_three = len(weeks) >= 2 and weeks_set == expected(
            lambda week: (week - range_1) % 3 == 0
        )

        return only_odd, only_even, only_every_three

    # ──────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────

    @staticmethod
    def _validate_create_input(
        validated_data: dict[str, Any],
    ) -> dict[str, str]:
        """Validate the create payload and return the parsed amounts map.

        Raises ``CommissioningError`` when no amounts are provided and
        ``RequiredFieldMissing`` for any missing required field.
        """
        amounts = extract_amounts_from_keys(validated_data, "amount_")
        if not amounts:
            raise CommissioningError(
                "No share type variation amounts provided",
                code="default_share_content.no_amounts",
            )

        required_fields = [
            "year",
            "share_article",
            "share_option",
            "range_1",
            "range_2",
            "unit",
            "size",
        ]
        for field in required_fields:
            if not validated_data.get(field):
                raise RequiredFieldMissing(
                    f"Missing required field: {field}",
                    field=field,
                )

        return amounts

    @staticmethod
    def _resolve_create_variations(
        validated_data: dict[str, Any],
        amounts: dict[str, str],
    ) -> tuple[ShareArticle, dict[str, ShareTypeVariation], Reseller | None]:
        """Resolve the ShareArticle, all requested ShareTypeVariations and the
        optional Reseller referenced by the payload.

        Raises ``ShareArticleNotFound`` / ``ResellerNotFound`` for unknown FKs
        and ``CommissioningError`` when any requested variation id is missing.
        """
        try:
            share_article = ShareArticle.objects.get(id=validated_data["share_article"])
        except ShareArticle.DoesNotExist as exc:
            raise ShareArticleNotFound(
                f"ShareArticle with id {validated_data['share_article']} does not exist",
                details={"share_article_id": validated_data["share_article"]},
            ) from exc

        # Bulk-fetch all share type variations
        variation_ids = list(amounts.keys())
        share_type_variations: dict[str, ShareTypeVariation] = {
            str(var.id): var
            for var in ShareTypeVariation.objects.filter(id__in=variation_ids)
        }
        missing = set(variation_ids) - set(share_type_variations.keys())
        if missing:
            raise CommissioningError(
                f"ShareTypeVariations with ids {missing} do not exist",
                code="share_type_variation.missing_bulk",
                details={"missing_ids": sorted(missing)},
            )

        seller = None
        seller_id = validated_data.get("seller")
        if seller_id:
            try:
                seller = Reseller.objects.get(id=seller_id)
            except Reseller.DoesNotExist as exc:
                raise ResellerNotFound(
                    f"Reseller with id {seller_id} does not exist",
                    details={"seller_id": seller_id},
                ) from exc

        return share_article, share_type_variations, seller

    @staticmethod
    def _build_create_objects(
        validated_data: dict[str, Any],
        amounts: dict[str, str],
        share_article: ShareArticle,
        share_type_variations: dict[str, ShareTypeVariation],
        seller: Reseller | None,
    ) -> tuple[
        list[DefaultShareContent],
        list[Share],
        list[tuple[ShareContent, Share, Any, Any]],
        dict[_ShareKey, Share],
    ]:
        """Resolve the week/delivery layout and build the in-memory objects.

        Returns ``(all_default_contents, shares_to_create, all_share_contents,
        existing_shares)`` for the persist phase. ``existing_shares`` seeds the
        Share lookup with the prefetched + newly-built (unsaved) shares.
        """
        year: int = validated_data["year"]
        unit: str = validated_data["unit"]
        size: str = validated_data["size"]

        # Week filtering
        week_range = range(
            int(validated_data["range_1"]), int(validated_data["range_2"]) + 1
        )
        filtered_weeks = DefaultShareContentService._filter_weeks(
            week_range,
            only_odd=validated_data.get("only_odd_weeks", False),
            only_even=validated_data.get("only_even_weeks", False),
            only_every_three=validated_data.get("only_every_three_weeks", False),
        )

        current_date = timezone.localdate()
        future_weeks = DefaultShareContentService._get_future_weeks(
            year, filtered_weeks, current_date
        )

        # Pre-compute a set of future week numbers for fast lookups
        future_week_dates: dict[int, datetime.date] = {
            wk: dt for wk, dt in future_weeks
        }

        # Prefetch delivery/station data
        (
            delivery_days_by_date,
            delivery_station_days,
        ) = DefaultShareContentService._prefetch_delivery_data(future_weeks)

        all_delivery_days_flat = [
            delivery_day
            for delivery_day_list in delivery_days_by_date.values()
            for delivery_day in delivery_day_list
        ]
        existing_shares = DefaultShareContentService._prefetch_existing_shares(
            year,
            week_range,
            list(share_type_variations.values()),
            all_delivery_days_flat,
        )

        # Build objects in memory
        all_default_contents: list[DefaultShareContent] = []
        shares_to_create: list[Share] = []
        all_share_contents: list[tuple[ShareContent, Share, Any, Any]] = []

        note = validated_data.get("note")

        for variation_id, amount in amounts.items():
            if amount in SCAFFOLD_VALUES:
                continue

            variation = share_type_variations[variation_id]
            decimal_amount = parse_amount_cell(amount, field=f"amount_{variation_id}")
            # A zero amount is scaffold, not a real plan — same as
            # HarvestSharePlanning: don't persist a zero-quantity default row.
            if decimal_amount == 0:
                continue

            # A size gets plan rows only for the weeks it runs: a size
            # replaced during the year hands its weeks to its successor.
            running_weeks = [
                week
                for week in filtered_weeks
                if variation.is_active_at(Week(year, week).monday())
            ]
            for week in running_weeks:
                all_default_contents.append(
                    DefaultShareContent(
                        year=year,
                        delivery_week=week,
                        share_type_variation=variation,
                        share_article=share_article,
                        amount=decimal_amount,
                        unit=unit,
                        size=size,
                        note=note,
                        seller=seller,
                    )
                )

                # Only create Share/ShareContent for future weeks
                monday = future_week_dates.get(week)
                if monday is None:
                    continue

                delivery_days = delivery_days_by_date.get(monday, [])

                for delivery_day in delivery_days:
                    share_key: _ShareKey = (
                        year,
                        week,
                        delivery_day.id,
                        variation.id,
                    )

                    if share_key in existing_shares:
                        share = existing_shares[share_key]
                    else:
                        # ``bulk_create`` below bypasses ``Share.save()``,
                        # which is where ALL day fields (harvesting / packing /
                        # washing / cleaning / get_current_stock) are defaulted
                        # from the delivery day. Apply them in memory via the
                        # model's own helper (driven by ``DAY_FIELD_DEFAULTS``,
                        # the single source of truth) so none are missed — a
                        # NULL day field costs the share its theoretical
                        # amounts (see ``DAY_FIELD_DEFAULTS``).
                        share = Share(
                            year=year,
                            delivery_week=week,
                            delivery_day=delivery_day,
                            share_type_variation=variation,
                        )
                        share._apply_default_day_fields()
                        shares_to_create.append(share)
                        existing_shares[share_key] = share

                    for station in delivery_station_days.get(
                        (monday, delivery_day.id), []
                    ):
                        share_content = ShareContent(
                            share=share,
                            share_article=share_article,
                            size=size,
                            unit=unit,
                            delivery_station=station,
                            amount=decimal_amount,
                            seller=seller,
                        )
                        all_share_contents.append(
                            (share_content, share, delivery_day, station)
                        )

        return (
            all_default_contents,
            shares_to_create,
            all_share_contents,
            existing_shares,
        )

    @staticmethod
    def _persist_create_objects(
        year: int,
        all_default_contents: list[DefaultShareContent],
        shares_to_create: list[Share],
        all_share_contents: list[tuple[ShareContent, Share, Any, Any]],
        existing_shares: dict[_ShareKey, Share],
    ) -> set[Any]:
        """Bulk-persist the built objects and resolve the ShareContent rows'
        Shares; return the ids of the shares that got contents."""
        # Bulk create
        if all_default_contents:
            DefaultShareContent.objects.bulk_create(
                all_default_contents, ignore_conflicts=True
            )

        if shares_to_create:
            Share.objects.bulk_create(shares_to_create, ignore_conflicts=True)

            # Re-fetch to get IDs assigned by the database
            for share in Share.objects.filter(
                year=year,
                delivery_week__in=[s.delivery_week for s in shares_to_create],
                share_type_variation__in=[
                    s.share_type_variation for s in shares_to_create
                ],
            ):
                key: _ShareKey = (
                    share.year,
                    share.delivery_week,
                    share.delivery_day_id,
                    share.share_type_variation_id,
                )
                existing_shares[key] = share

        # Resolve Share references and bulk-create ShareContent
        final_share_contents: list[ShareContent] = []
        for share_content, original_share, delivery_day, _station in all_share_contents:
            key = (
                original_share.year,
                original_share.delivery_week,
                delivery_day.id,
                original_share.share_type_variation_id,
            )
            resolved = existing_shares.get(key)
            if resolved:
                share_content.share = resolved
                final_share_contents.append(share_content)

        if final_share_contents:
            ShareContent.objects.bulk_create(
                final_share_contents, ignore_conflicts=True
            )
        return {share_content.share_id for share_content in final_share_contents}

    @staticmethod
    @transaction.atomic
    def create_default_share_content(
        validated_data: dict[str, Any],
        *,
        collect_movements: list[MovementShareArticle] | None = None,
        replaced_movements: list[MovementShareArticle] | None = None,
    ) -> list[DefaultShareContent]:
        """Create multiple DefaultShareContent objects from validated data, and
        the shares' contents; ``collect_movements`` and ``replaced_movements``
        (an update's deleted ones) go to their recompute (``recompute_shares``)."""
        amounts = DefaultShareContentService._validate_create_input(validated_data)

        (
            share_article,
            share_type_variations,
            seller,
        ) = DefaultShareContentService._resolve_create_variations(
            validated_data, amounts
        )

        (
            all_default_contents,
            shares_to_create,
            all_share_contents,
            existing_shares,
        ) = DefaultShareContentService._build_create_objects(
            validated_data,
            amounts,
            share_article,
            share_type_variations,
            seller,
        )

        if not all_default_contents and any(
            amount not in SCAFFOLD_VALUES
            and parse_amount_cell(amount, field=f"amount_{variation_id}") != 0
            for variation_id, amount in amounts.items()
        ):
            raise DefaultShareContentNoRunningWeek(
                "None of the sizes with an amount runs in the planned weeks.",
                field="range_1",
            )

        share_ids = DefaultShareContentService._persist_create_objects(
            validated_data["year"],
            all_default_contents,
            shares_to_create,
            all_share_contents,
            existing_shares,
        )
        from .recompute import recompute_shares

        recompute_shares(
            share_ids,
            collect_movements=collect_movements,
            replaced_movements=replaced_movements,
        )

        return all_default_contents

    @staticmethod
    def _rows_of_running_sizes() -> list[DefaultShareContent]:
        """The long-term plan rows whose size runs in their week; a row for a
        week its size doesn't run in plans no delivery."""
        return [
            default
            for default in DefaultShareContent.objects.select_related(
                "share_type_variation"
            )
            if default.share_type_variation.is_active_at(
                Week(default.year, default.delivery_week).monday()
            )
        ]

    @staticmethod
    @transaction.atomic
    def materialize_for_new_station_day(station_day: DeliveryStationDay) -> int:
        """Fan the existing long-term ``DefaultShareContent`` plan out to a
        newly added ``DeliveryStationDay``.

        When a station starts delivering mid-season, the office expects the
        already-planned shares (honey, etc.) to be "theoretically delivered"
        at the new station too — without re-running long-term planning by
        hand. This materializes the missing ``ShareContent`` for just that
        station, for **future weeks only** (past deliveries already happened).

        Idempotent: ``bulk_create(ignore_conflicts=True)`` skips rows that
        already exist (ShareContent is unique per
        ``share / article / station / unit / size``), so re-firing is safe.

        Returns the number of ShareContent rows created.
        """
        delivery_day = station_day.delivery_day
        station = station_day.delivery_station
        current_date = timezone.localdate()

        defaults = DefaultShareContentService._rows_of_running_sizes()
        if not defaults:
            return 0

        def _active_at(obj: Any, on_date: datetime.date) -> bool:
            if obj.valid_from > on_date:
                return False
            return obj.valid_until is None or obj.valid_until >= on_date

        # Future weeks where BOTH the delivery day and the new station-day are
        # active. Resolved once per (year, week).
        active_weeks: set[tuple[int, int]] = set()
        checked: set[tuple[int, int]] = set()
        for default in defaults:
            key = (default.year, default.delivery_week)
            if key in checked:
                continue
            checked.add(key)
            monday = Week(default.year, default.delivery_week).monday()
            if (
                monday >= current_date
                and _active_at(delivery_day, monday)
                and _active_at(station_day, monday)
            ):
                active_weeks.add(key)

        if not active_weeks:
            return 0

        # Resolve every Share for the active defaults in a bounded number of
        # queries rather than one get_or_create per default (the same
        # (year, week, variation) recurs across a variation's share_articles).
        share_keys = {
            (default.year, default.delivery_week, default.share_type_variation_id)
            for default in defaults
            if (default.year, default.delivery_week) in active_weeks
        }
        years = {key[0] for key in share_keys}
        weeks = {key[1] for key in share_keys}
        variation_ids = {key[2] for key in share_keys}

        def _fetch_shares() -> dict[tuple[int, int, str], Share]:
            return {
                (share.year, share.delivery_week, share.share_type_variation_id): share
                for share in Share.objects.filter(
                    delivery_day=delivery_day,
                    year__in=years,
                    delivery_week__in=weeks,
                    share_type_variation_id__in=variation_ids,
                )
            }

        shares_by_key = _fetch_shares()
        missing = [
            Share.build_for_delivery(
                year=year,
                delivery_week=week,
                delivery_day=delivery_day,
                share_type_variation_id=variation_id,
            )
            for (year, week, variation_id) in share_keys
            if (year, week, variation_id) not in shares_by_key
        ]
        if missing:
            Share.objects.bulk_create(missing, ignore_conflicts=True)
            # Re-fetch so the map holds PK-bearing rows for everything just
            # created (and anything a concurrent writer inserted meanwhile).
            shares_by_key = _fetch_shares()

        # Heal any reused row whose day fields are NULL — a no-op (no write)
        # for the common case where they're already populated.
        for share in shares_by_key.values():
            share.ensure_day_fields()

        contents: list[ShareContent] = []
        for default in defaults:
            if (default.year, default.delivery_week) not in active_weeks:
                continue
            share = shares_by_key[
                (
                    default.year,
                    default.delivery_week,
                    default.share_type_variation_id,
                )
            ]
            contents.append(
                ShareContent(
                    share=share,
                    share_article_id=default.share_article_id,
                    delivery_station=station,
                    unit=default.unit,
                    size=default.size,
                    amount=default.amount,
                    seller_id=default.seller_id,
                )
            )

        if not contents:
            return 0

        ShareContent.objects.bulk_create(contents, ignore_conflicts=True)

        from .recompute import recompute_shares

        recompute_shares({share_content.share_id for share_content in contents})
        return len(contents)

    @staticmethod
    def get_default_share_content(
        year: int,
        share_article_id: str,
        unit: str,
        size: str,
        share_option: str | None = None,
    ) -> dict[str, Any] | None:
        """The planning row of one year/share_article/unit/size slot: of
        ``share_option``'s contents, or of every option's for ``None``."""
        if not ShareArticle.objects.filter(id=share_article_id).exists():
            raise ShareArticleNotFound(
                f"ShareArticle with id {share_article_id} does not exist",
                details={"share_article_id": share_article_id},
            )

        rows = DefaultShareContentService._slot_rows(
            DefaultShareContent.objects.filter(
                year=year, share_article_id=share_article_id, unit=unit, size=size
            ),
            year,
            share_option,
        )
        return rows[0] if rows else None

    @staticmethod
    def get_default_share_content_list(
        year: int, share_option: str | None = None
    ) -> list[dict[str, Any]]:
        """The year's planning rows, one per share_article/unit/size slot: of
        ``share_option``'s contents, or grouped across every option for
        ``None``."""
        return DefaultShareContentService._slot_rows(
            DefaultShareContent.objects.filter(year=year), year, share_option
        )

    @staticmethod
    def _running_weeks(
        contents: list[DefaultShareContent], year: int, range_1: int, range_2: int
    ) -> set[int]:
        """The weeks of ``range_1…range_2`` in which any size of ``contents``
        runs."""
        variations = {
            content.share_type_variation_id: content.share_type_variation
            for content in contents
        }.values()
        return {
            week
            for week in range(range_1, range_2 + 1)
            if any(
                variation.is_active_at(Week(year, week).monday())
                for variation in variations
            )
        }

    @staticmethod
    def _slot_rows(
        contents: QuerySet[DefaultShareContent], year: int, share_option: str | None
    ) -> list[dict[str, Any]]:
        """The planning rows of ``contents``, one per share_article/unit/size.

        With ``share_option`` only that option's contents count, and a row's
        id names the slot with its option; an article can belong to three.
        """
        # One query for every content. ``share_article`` covers the per-row
        # name/unit lookups the serializer touches; without it the response
        # fans out to one query per group on a 100s-row page.
        grouped: dict[tuple, list[DefaultShareContent]] = {}
        variation_ids: set[str] = set()
        for content in (
            in_share_option(contents, share_option, variation="share_type_variation")
            .select_related(
                "share_type_variation",
                "share_type_variation__share_type",
                "share_article",
                "seller",
            )
            .order_by("share_article_id", "unit", "size", "delivery_week")
        ):
            key = (content.share_article_id, content.unit, content.size)
            grouped.setdefault(key, []).append(content)
            variation_ids.add(str(content.share_type_variation_id))

        # Active-subscriber counts once for every variation on the page; the
        # snapshot date is the same for every group.
        subscriber_counts = subscriber_counts_by_variation(
            variation_ids, timezone.localdate()
        )

        results: list[dict[str, Any]] = []
        for (sa_id, unit_val, size_val), contents_list in grouped.items():
            first = contents_list[0]
            weeks = [c.delivery_week for c in contents_list]
            range_1 = min(weeks)
            range_2 = max(weeks)

            (
                only_odd,
                only_even,
                only_every_three,
            ) = DefaultShareContentService._detect_week_pattern(
                weeks,
                range_1,
                range_2,
                DefaultShareContentService._running_weeks(
                    contents_list, year, range_1, range_2
                ),
            )

            amounts_dict: dict[str, str] = {}
            for content in contents_list:
                amount_key = f"amount_{content.share_type_variation_id}"
                if amount_key not in amounts_dict:
                    amounts_dict[amount_key] = str(content.amount)

            # A rough total over the planned timespan, at today's subscriber
            # counts for every week. Each row is one week of one size, so a
            # size counts only for the weeks it runs.
            needed_amount = str(
                round_money(
                    sum(
                        (
                            content.amount
                            * subscriber_counts.get(
                                str(content.share_type_variation_id), Decimal(0)
                            )
                            for content in contents_list
                        ),
                        Decimal(0),
                    )
                )
            )

            row: dict[str, Any] = {
                "id": compose_slot_id(
                    year, sa_id, unit_val, size_val, share_option=share_option
                ),
                "year": year,
                "share_article": sa_id,
                "share_option": first.share_type_variation.share_type.share_option,
                "range_1": range_1,
                "range_2": range_2,
                "unit": unit_val,
                "size": size_val,
                "note": first.note,
                "only_odd_weeks": only_odd,
                "only_even_weeks": only_even,
                "only_every_three_weeks": only_every_three,
                "needed_amount": needed_amount,
                "seller": str(first.seller_id) if first.seller_id else None,
                "seller_name": str(first.seller) if first.seller_id else None,
            }
            row.update(amounts_dict)
            results.append(row)

        return results

    @staticmethod
    @transaction.atomic
    def update_default_share_content(
        year: int,
        share_article_id: str,
        validated_data: dict[str, Any],
        share_option: str | None = None,
    ) -> list[DefaultShareContent]:
        """Update DefaultShareContent: deletes the slot's rows — only
        ``share_option``'s, when given — and creates new from validated_data."""
        try:
            share_article = ShareArticle.objects.get(id=share_article_id)
        except ShareArticle.DoesNotExist as exc:
            raise ShareArticleNotFound(
                f"ShareArticle with id {share_article_id} does not exist",
                details={"share_article_id": share_article_id},
            ) from exc

        unit = validated_data.get("unit")
        size = validated_data.get("size")

        week_range = range(
            int(validated_data["range_1"]), int(validated_data["range_2"]) + 1
        )
        current_date = timezone.localdate()
        future_weeks = [
            week for week in week_range if Week(year, week).monday() >= current_date
        ]

        refuse_variations_outside(
            share_option, extract_amounts_from_keys(validated_data, "amount_")
        )
        in_share_option(
            DefaultShareContent.objects.filter(
                year=year, share_article=share_article, unit=unit, size=size
            ),
            share_option,
            variation="share_type_variation",
        ).delete()

        # Capture what the ShareContent delete cascades away before it runs:
        # its movements (FK on_delete=CASCADE) and the parent Share ids. Planned
        # amounts can be non-zero, so the snapshots and INVENTORY balances would
        # stay stale without the cascade below.
        affected_movements: list[MovementShareArticle] = []
        emptied_share_ids: set[Any] = set()
        if future_weeks:
            share_contents_to_delete = in_share_option(
                ShareContent.objects.filter(
                    share__year=year,
                    share__delivery_week__in=future_weeks,
                    share_article=share_article,
                    unit=unit,
                    size=size,
                ),
                share_option,
                variation="share__share_type_variation",
            )
            emptied_share_ids = set(
                share_contents_to_delete.values_list("share_id", flat=True)
            )
            # Both movement halves: the SHARECONTENT rows and the theoretical_*
            # ones (share_content=NULL, cascading away with the ShareContent),
            # else their stock contribution misses the recompute and the
            # snapshot stays too high.
            affected_movements = list(
                MovementShareArticle.objects.for_share_contents(
                    share_contents_to_delete
                )
            )
            share_contents_to_delete.delete()

        # The create's recompute re-derives the deleted rows' corrections first.
        deferred_movements: list[MovementShareArticle] = []
        result = DefaultShareContentService.create_default_share_content(
            validated_data,
            collect_movements=deferred_movements,
            replaced_movements=affected_movements,
        )

        # The create recomputes only the shares it refills; a week the new
        # range, week pattern or station set no longer covers stays emptied, so
        # its shares are rebuilt here, and the removed movements' corrections
        # re-derived (a create refilling no share leaves them to the caller).
        # All of it cascades once: one sorted ``current_balance:*`` lock pass,
        # since two passes could AB/BA-deadlock against an overlapping acquirer.
        if emptied_share_ids:
            from .recompute import recompute_shares

            recompute_shares(emptied_share_ids, collect_movements=deferred_movements)
        if affected_movements:
            from .theoretical_objects import recalculate_actual_corrections

            deferred_movements.extend(affected_movements)
            recalculate_actual_corrections(
                affected_movements, collect_movements=deferred_movements
            )
        if deferred_movements:
            from .snapshot_service import SnapshotService

            SnapshotService.cascade_for_movements(deferred_movements)

        return result

    @staticmethod
    @transaction.atomic
    def delete_default_share_content_bulk(
        year: int,
        share_article: ShareArticle | None = None,
        unit: str | None = None,
        size: str | None = None,
        share_option: str | None = None,
    ) -> int:
        """Delete multiple DefaultShareContent objects by criteria — only
        ``share_option``'s, when given — and cascade the deletion to the future
        ShareContent they materialised.

        ShareContent from **current ISO week + 2** onward is removed; the next
        two weeks are already in the packing pipeline, so those slots (and all
        past weeks) are left intact. Mirrors ``update_default_share_content``'s
        cascade: capture the affected Shares + MovementShareArticle rows BEFORE
        deleting, then recompute the emptied Shares and cascade stock snapshots
        so downstream balances stay correct.
        """
        queryset = in_share_option(
            DefaultShareContent.objects.filter(year=year),
            share_option,
            variation="share_type_variation",
        )

        if share_article:
            queryset = queryset.filter(share_article=share_article)
        if unit:
            queryset = queryset.filter(unit=unit)
        if size:
            queryset = queryset.filter(size=size)

        count = queryset.count()

        # Cascade to the future ShareContent these defaults materialised, scoped
        # to the SAME article/unit/size so another article's slots are never
        # touched. Only meaningful when an article is given (the URL always
        # supplies one); a whole-year wipe without an article is left as a plain
        # DefaultShareContent delete.
        emptied_share_ids: set[Any] = set()
        affected_movements: list[MovementShareArticle] = []

        # Roll the cutoff via ``isoweek.Week`` so "current ISO week + 2"
        # crosses 52/53-week year boundaries correctly: near year end the
        # pipeline weeks live in the NEXT ISO year (e.g. week 52 + 2 → weeks
        # 1-2 of the following year), which a bare ``current_week + 2``
        # comparison would wrongly treat as deletable.
        iso = timezone.localdate().isocalendar()
        cutoff = Week(iso[0], iso[1]) + 2
        cutoff_year, cutoff_week = cutoff.year, cutoff.week

        if share_article is not None and year >= cutoff_year:
            share_contents_to_delete = in_share_option(
                ShareContent.objects.filter(
                    share__year=year, share_article=share_article
                ),
                share_option,
                variation="share__share_type_variation",
            )
            if unit:
                share_contents_to_delete = share_contents_to_delete.filter(unit=unit)
            if size:
                share_contents_to_delete = share_contents_to_delete.filter(size=size)
            # A year past the cutoff year is entirely ahead of the cutoff;
            # only the cutoff year itself needs the week threshold.
            if year == cutoff_year:
                share_contents_to_delete = share_contents_to_delete.filter(
                    share__delivery_week__gte=cutoff_week
                )

            emptied_share_ids = set(
                share_contents_to_delete.values_list("share_id", flat=True)
            )
            # Wide capture (both movement halves) before the delete — see the
            # matching note in update_default_share_content; the theoretical_*
            # halves must be re-cascaded too or the snapshot stays too high.
            affected_movements = list(
                MovementShareArticle.objects.for_share_contents(
                    share_contents_to_delete
                )
            )
            share_contents_to_delete.delete()

        queryset.delete()

        # ``recompute_shares`` is idempotent and a no-op for fully-emptied
        # Shares; cascade snapshots for the entities whose movements were
        # removed so downstream stock balances stay correct. Folded into ONE
        # union cascade (single sorted advisory-lock pass) — see the matching
        # note in update_default_share_content.
        deferred_movements: list[MovementShareArticle] = []
        if emptied_share_ids:
            from .recompute import recompute_shares

            recompute_shares(emptied_share_ids, collect_movements=deferred_movements)
        if affected_movements:
            from .theoretical_objects import recalculate_actual_corrections

            deferred_movements.extend(affected_movements)
            recalculate_actual_corrections(
                affected_movements, collect_movements=deferred_movements
            )
        if deferred_movements:
            from .snapshot_service import SnapshotService

            SnapshotService.cascade_for_movements(deferred_movements)

        return count
